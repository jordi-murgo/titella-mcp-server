"""Canonical protocol assets shared by the Titella slave implementations."""
from __future__ import annotations

__version__ = "1.3.0"

__all__ = ["__version__"]
