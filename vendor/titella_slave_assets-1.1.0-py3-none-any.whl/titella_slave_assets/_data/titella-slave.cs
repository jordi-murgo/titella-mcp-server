// Entry point and lifecycle of the ephemeral Windows slave agent. Port of
// implementations/python/__main__.py. The public Run method is invoked by
// the loader as
//   exit [Titella.Slave.Agent]::Run(bootstrapDir, linkId, port, hbMs, graceMs)
// so its return value is the process exit code.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using System.Threading;

    /// <summary>Public entry point called from PowerShell Add-Type.</summary>
    public static class Agent
    {
        /// <summary>
        /// Runs one ephemeral slave. Returns 0 on a clean stop or grace
        /// expiry, 2 on invalid arguments and 1 when an unexpected exception
        /// escapes. Terminal failures are logged inside the bootstrap
        /// directory when one was supplied.
        /// </summary>
        public static int Run(string bootstrapDirectory, string linkId, string port,
                              int heartbeatMilliseconds, int graceMilliseconds)
        {
            // Detach from the loader console: closing it must not stop the
            // agent, and the agent writes only to its own diagnostic file.
            try
            {
                NativeMethods.FreeConsole();
            }
            catch (Exception)
            {
                // Detaching is best effort; a missing console is not fatal.
            }

            string logPath = null;
            if (!string.IsNullOrEmpty(bootstrapDirectory))
            {
                try
                {
                    Directory.CreateDirectory(bootstrapDirectory);
                    logPath = Path.Combine(bootstrapDirectory, "agent.log");
                }
                catch (Exception)
                {
                    logPath = null;
                }
            }

            if (!string.IsNullOrEmpty(bootstrapDirectory))
            {
                try
                {
                    // Ownership marker of this bootstrap directory: the
                    // loader writes it with the console pid, the agent takes
                    // it over here, and the next bootstrap's sweep deletes
                    // the tombstone once this pid is gone.
                    File.WriteAllText(
                        Path.Combine(bootstrapDirectory, "owner.json"),
                        string.Format(
                            CultureInfo.InvariantCulture,
                            "{{\"session_id\":\"{0}\",\"pid\":{1}}}",
                            linkId, ProcessId),
                        new UTF8Encoding(false));
                }
                catch (Exception)
                {
                    // A marker that cannot be written never blocks the run.
                }
            }

            if (!WireConstants.IsLinkId(linkId))
            {
                Log(logPath, "invalid link_id: 32 lowercase hexadecimal characters are required");
                return 2;
            }
            // The window rig renders the CLIPBOARD sentinel instead of a COM
            // port: the same protocol then runs over the shared clipboard.
            // Native USB rigs render HID:<serial> instead: the same protocol
            // then runs over the vendor data collection of that device.
            bool clipboardPort = ClipboardTransport.IsClipboardPort(port);
            bool hidPort = HidTransport.IsHidBinding(port);
            if (!clipboardPort && !hidPort && !ComTransport.IsValidPortName(port))
            {
                Log(logPath, string.IsNullOrEmpty(port)
                    ? "cdc_not_provided: the loader must resolve the COM port first"
                    : "invalid cdc port: COM[1-9][0-9]*, CLIPBOARD or HID:<serial> is required");
                return 2;
            }

            int heartbeatMs = Math.Max(1000, heartbeatMilliseconds);
            int graceMs = Math.Max(graceMilliseconds, heartbeatMs);

            SlaveAgent agent = null;
            try
            {
                string resolvedPort = port;
                agent = new SlaveAgent(
                    linkId,
                    delegate()
                    {
                        if (clipboardPort)
                        {
                            ClipboardTransport clipboard = new ClipboardTransport(linkId);
                            clipboard.Open();
                            return clipboard;
                        }
                        if (hidPort)
                        {
                            HidTransport hid = new HidTransport(resolvedPort);
                            hid.Open();
                            return hid;
                        }
                        ComTransport transport = new ComTransport(resolvedPort);
                        transport.Open();
                        return transport;
                    },
                    bootstrapDirectory,
                    heartbeatMs,
                    graceMs);
                agent.Run();
                return 0;
            }
            catch (Exception error)
            {
                Log(logPath, error.ToString());
                return 1;
            }
            finally
            {
                if (agent != null)
                {
                    agent.Cleanup(true);
                }
            }
        }

        private static void Log(string logPath, string message)
        {
            if (string.IsNullOrEmpty(logPath))
            {
                return;
            }
            try
            {
                string line = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture) +
                    " " + message + Environment.NewLine;
                File.AppendAllText(logPath, line, new UTF8Encoding(false));
            }
            catch (Exception)
            {
                // A diagnostic log that cannot be written never masks the
                // real failure.
            }
        }

        private static int ProcessId
        {
            get
            {
                return System.Diagnostics.Process.GetCurrentProcess().Id;
            }
        }

        /// <summary>
        /// Version of the installed .NET Framework 4.x, read from the registry
        /// value the framework writes (never Environment.Version, which is the
        /// CLR version). Returns null when the key is unreadable.
        /// </summary>
        public static string NdpVersion()
        {
            try
            {
                object value = Microsoft.Win32.Registry.GetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full",
                    "Version",
                    null);
                return value as string;
            }
            catch (Exception)
            {
                return null;
            }
        }
        /// <summary>
        /// Location of the compiled agent executable (agent.exe): job
        /// children are this very image started with --job. When the agent
        /// is hosted in a test process the location is that host, which is
        /// still the image the job children run.
        /// </summary>
        internal static string ExecutableAssembly()
        {
            return typeof(SlaveAgent).Assembly.Location;
        }

    }

    /// <summary>One ephemeral agent: link, dispatch loop and cleanup.</summary>
    internal sealed class SlaveAgent
    {
        private const int BindAttempts = 20;
        private const int BindRetryDelayMs = 50;

        private readonly string _linkId;
        private readonly string _bootstrapDirectory;
        private readonly ManualResetEventSlim _stop = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _cleanupDone = new ManualResetEventSlim(false);
        private readonly object _cleanupLock = new object();
        private readonly Deduplicator _dedup = new Deduplicator();
        private readonly ProcessRegistry _registry = new ProcessRegistry(4);
        private readonly AgentLink _link;
        private readonly JobManager _jobs;
        private readonly TerminalManager _terminals;
        private readonly FileService _files = new FileService();
        private readonly TransferService _transfers;
        // Screenshot blocks in flight. 8 is the transfer channel's default and
        // measured fastest here: a 1.7 MiB stream took 35-55 s at 8 against
        // 48-51 s at 2. Frames lost mid-flight are recovered by the per-block
        // retransmit; the master additionally refuses to publish a payload
        // whose byte count disagrees with the declared size, so a loss it
        // cannot recover surfaces as a retryable screen_capture_failed instead
        // of a corrupt image.
        private const int ScreenWindow = WireConstants.DataWindowDefault;
        private bool _cleaned;
        private bool _bound;
        private ProtocolError _capabilityError;
        private bool _capabilityChecked;

        public SlaveAgent(string linkId, ILinkTransport transport,
                          string bootstrapDirectory, int heartbeatMs, int graceMs)
        {
            _linkId = linkId;
            _bootstrapDirectory = bootstrapDirectory;
            _link = new AgentLink(
                linkId,
                delegate()
                {
                    if (!transport.IsOpen)
                    {
                        throw new LinkLostException(0, "the transport is closed");
                    }
                    return transport;
                },
                heartbeatMs,
                graceMs,
                Hello,
                delegate() { _stop.Set(); });
            _jobs = new JobManager(_link, _registry);
            _terminals = new TerminalManager(_link, _registry);
            _transfers = new TransferService(_link);
        }

        public SlaveAgent(string linkId, Func<ILinkTransport> transportFactory,
                          string bootstrapDirectory, int heartbeatMs, int graceMs)
        {
            _linkId = linkId;
            _bootstrapDirectory = bootstrapDirectory;
            _link = new AgentLink(
                linkId,
                transportFactory,
                heartbeatMs,
                graceMs,
                Hello,
                delegate() { _stop.Set(); });
            _jobs = new JobManager(_link, _registry);
            _terminals = new TerminalManager(_link, _registry);
            _transfers = new TransferService(_link);
        }

        internal ProcessRegistry Registry
        {
            get { return _registry; }
        }

        internal bool Bound
        {
            get { return _bound; }
        }

        private void Hello()
        {
            IDictionary<string, object> runtime = new Dictionary<string, object>();
            runtime["name"] = "dotnet-framework";
            runtime["version"] = Agent.NdpVersion();
            IDictionary<string, object> body = new Dictionary<string, object>();
            body["agent"] = "titella-slave";
            body["python"] = null;
            body["pid"] = System.Diagnostics.Process.GetCurrentProcess().Id;
            body["uid"] = null;
            body["implementation"] = "windows-dotnet";
            body["runtime"] = runtime;
            _link.SendFrame(Wire.BaseFrame(
                _linkId, "control", "hello", "body", body));
        }

        public void Run()
        {
            _link.Start();
            try
            {
                while (!_stop.IsSet && !_link.Expired)
                {
                    IDictionary<string, object> frame;
                    if (!_link.Inbound.TryDequeue(250, out frame))
                    {
                        continue;
                    }
                    Dispatch(frame);
                }
            }
            finally
            {
                Cleanup(true);
            }
        }

        public void Cleanup(bool removePayload)
        {
            lock (_cleanupLock)
            {
                if (_cleaned)
                {
                    _cleanupDone.Wait(30000);
                    return;
                }
                _cleaned = true;
            }
            try
            {
                _jobs.Shutdown();
                _terminals.Shutdown();
                _transfers.Shutdown();
                _link.Close();
                if (removePayload && !string.IsNullOrEmpty(_bootstrapDirectory))
                {
                    RemoveOwnedBootstrap();
                }
            }
            finally
            {
                _cleanupDone.Set();
            }
        }

        /// <summary>
        /// Cleans only this agent's own bootstrap directory: the name must
        /// be a bare 16-hex-digit GUID segment and the parent must be the
        /// user TEMP directory. The running image (not deletable while the
        /// process lives) and owner.json are kept as the tombstone the next
        /// bootstrap's sweep removes; everything else is deleted. Reparse
        /// points are unlinked, never descended into, so a foreign target is
        /// never touched.
        /// </summary>
        private void RemoveOwnedBootstrap()
        {
            try
            {
                string full = Path.GetFullPath(_bootstrapDirectory);
                string name = Path.GetFileName(full);
                string parent = Path.GetDirectoryName(full);
                string temporary = Path.GetFullPath(Path.GetTempPath());
                if (!System.Text.RegularExpressions.Regex.IsMatch(
                        name, "^[0-9a-f]{16}$",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                {
                    return;
                }
                if (!string.Equals(
                        parent.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                        temporary.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                        StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
                string image = typeof(SlaveAgent).Assembly.Location;
                foreach (string entry in Directory.GetFileSystemEntries(full))
                {
                    if (string.Equals(entry, image, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    if (string.Equals(Path.GetFileName(entry), "owner.json",
                                      StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    DeleteTree(entry);
                }
            }
            catch (Exception)
            {
                // Cleanup of the owned directory is best effort.
            }
        }

        private static void DeleteTree(string root)
        {
            FileAttributes attributes = File.GetAttributes(root);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
            {
                if ((attributes & FileAttributes.Directory) != 0)
                {
                    NativeMethods.RemoveDirectoryW(root);
                }
                else
                {
                    File.Delete(root);
                }
                return;
            }
            if ((attributes & FileAttributes.Directory) != 0)
            {
                foreach (string entry in Directory.GetFileSystemEntries(root))
                {
                    DeleteTree(entry);
                }
                Directory.Delete(root, false);
            }
            else
            {
                File.Delete(root);
            }
        }

        private void Dispatch(IDictionary<string, object> frame)
        {
            string kind = frame["type"] as string;
            if (kind == "heartbeat")
            {
                return;
            }
            if (kind == "data")
            {
                Data(frame);
                return;
            }
            if (kind != "request")
            {
                return;
            }
            try
            {
                string channel = frame["channel"] as string;
                if (channel == "control")
                {
                    Control(frame);
                    return;
                }
                if (!_bound)
                {
                    long attempts = Json.GetInt64(frame, "_bind_attempts", 0);
                    if (attempts < BindAttempts)
                    {
                        frame["_bind_attempts"] = attempts + 1;
                        _link.Inbound.TryEnqueue(frame, 1000);
                        Thread.Sleep(BindRetryDelayMs);
                        return;
                    }
                    _link.SendError(frame, "not_bound", "control.bind is mandatory", true);
                    return;
                }
                if (channel == "shell")
                {
                    Shell(frame);
                }
                else if (channel == "fs")
                {
                    Fs(frame);
                }
                else if (channel == "transfer")
                {
                    Transfer(frame);
                }
                else
                {
                    _link.SendError(frame, "unknown_channel", "channel not served", false);
                }
            }
            catch (ProtocolError error)
            {
                SendError(frame, error.Code, error.Message, error.Retryable);
            }
            catch (WireError error)
            {
                SendError(frame, error.Code, error.Detail, false);
            }
            catch (Exception error)
            {
                string message = string.IsNullOrEmpty(error.Message)
                    ? "operation_failed"
                    : error.Message;
                SendError(frame, "operation_failed", message, false);
            }
        }

        private void SendError(IDictionary<string, object> frame, string code,
                               string message, bool retryable)
        {
            try
            {
                _link.SendError(frame, code, message, retryable);
            }
            catch (Exception)
            {
                // The peer may already be gone; the error cannot be delivered.
            }
        }

        private void Control(IDictionary<string, object> frame)
        {
            IDictionary<string, object> body = Body(frame);
            object opValue;
            frame.TryGetValue("op", out opValue);
            string op = opValue as string;
            if (op == "bind")
            {
                object linkValue;
                body.TryGetValue("link_id", out linkValue);
                string requested = linkValue as string;
                if (!string.Equals(requested, _linkId, StringComparison.Ordinal))
                {
                    throw new ProtocolError(
                        "takeover_denied", "link_id does not match", false);
                }
                ProtocolError capabilities = CapabilityGate();
                if (capabilities != null)
                {
                    throw capabilities;
                }
                _bound = true;
                IDictionary<string, object> ready = new Dictionary<string, object>();
                ready["status"] = "ready";
                ready["link_id"] = _linkId;
                _link.Response(frame, ready);
            }
            else if (op == "agent.stop")
            {
                IDictionary<string, object> stopped = new Dictionary<string, object>();
                stopped["status"] = "stopped";
                _link.Response(frame, stopped);
                Thread closer = new Thread(delegate()
                {
                    Thread.Sleep(250);
                    Cleanup(true);
                    _stop.Set();
                });
                closer.IsBackground = true;
                closer.Name = "agent-stop";
                closer.Start();
            }
            else
            {
                throw new ProtocolError(
                    "unknown_op", "unknown control operation", false);
            }
        }

        /// <summary>
        /// A partial platform is reported, never papered over: ready is only
        /// sent when ConPTY exists and kill-on-close jobs are settable.
        /// </summary>
        private ProtocolError CapabilityGate()
        {
            if (!_capabilityChecked)
            {
                _capabilityError = Capabilities.Probe();
                _capabilityChecked = true;
            }
            return _capabilityError;
        }

        private static IDictionary<string, object> Body(IDictionary<string, object> frame)
        {
            object value;
            frame.TryGetValue("body", out value);
            IDictionary<string, object> body = value as IDictionary<string, object>;
            return body ?? new Dictionary<string, object>();
        }

        private static string Op(IDictionary<string, object> frame)
        {
            object value;
            frame.TryGetValue("op", out value);
            return value as string;
        }

        private void Shell(IDictionary<string, object> frame)
        {
            IDictionary<string, object> body = Body(frame);
            string op = Op(frame);
            IDictionary<string, object> result;
            if (op == "job.start")
            {
                result = _jobs.Start(
                    Str(body, "job_id"),
                    StrOrEmpty(body, "cmd"),
                    Json.GetDouble(body, "timeout", 60.0),
                    Str(body, "cwd"));
            }
            else if (op == "job.cancel")
            {
                result = _jobs.Cancel(Str(body, "job_id"));
            }
            else if (op == "terminal.open")
            {
                result = _terminals.Open(
                    Str(body, "cwd"),
                    Str(body, "shell"),
                    Json.GetInt32(body, "rows", 1, 1000, 40),
                    Json.GetInt32(body, "cols", 1, 1000, 120),
                    Json.GetInt32(body, "idle_timeout", 1, 3600, 900));
            }
            else if (op == "terminal.resize")
            {
                result = _terminals.Resize(
                    Str(body, "session_id"),
                    Json.GetInt32(body, "rows", 1, 1000, 40),
                    Json.GetInt32(body, "cols", 1, 1000, 120));
            }
            else if (op == "terminal.close")
            {
                result = _terminals.Close(Str(body, "session_id"));
            }
            else
            {
                throw new ProtocolError("unknown_shell_op", "unknown shell operation", false);
            }
            _link.Response(frame, result);
        }

        private static string Str(IDictionary<string, object> body, string key)
        {
            object value;
            body.TryGetValue(key, out value);
            return value as string;
        }

        private static string StrOrEmpty(IDictionary<string, object> body, string key)
        {
            string value = Str(body, key);
            return value == null ? string.Empty : value;
        }

        private void Fs(IDictionary<string, object> frame)
        {
            IDictionary<string, object> body = Body(frame);
            string op = Op(frame);
            FileService.Result response = _files.Dispatch(op, body);
            string streamId = Str(body, "stream_id");
            if (string.IsNullOrEmpty(streamId))
            {
                streamId = Guid.NewGuid().ToString("N");
            }
            if (response.Payload != null)
            {
                response.Metadata["stream_id"] = streamId;
                response.Metadata["payload_kind"] = "bytes";
                _link.Response(frame, response.Metadata);
                if (op == "screen")
                {
                    // A screenshot is hundreds of KiB: it uses the windowed
                    // sender the transfer channel already proved on this link
                    // instead of stop-and-wait, which measured ~3.5 KiB/s.
                    StartWindowedStream(
                        "fs", streamId, response.Payload, "fs.stream.finished",
                        ScreenWindow);
                }
                else
                {
                    StartStream("fs", streamId, response.Payload, "fs.stream.finished");
                }
                return;
            }
            string json = Json.Serialize(response.Metadata);
            byte[] encoded = new UTF8Encoding(false).GetBytes(json);
            if (encoded.Length > 2048)
            {
                IDictionary<string, object> metadata = new Dictionary<string, object>();
                metadata["stream_id"] = streamId;
                metadata["payload_kind"] = "json";
                metadata["bytes"] = encoded.Length;
                _link.Response(frame, metadata);
                StartStream("fs", streamId, encoded, "fs.stream.finished");
            }
            else
            {
                _link.Response(frame, response.Metadata);
            }
        }

        /// <summary>
        /// Sends a payload with the sliding window of the transfer channel
        /// (per-block ACK, bounded resends) instead of the stop-and-wait used
        /// by the interactive fs streams. Measured on the rig: ~30-45 KiB/s
        /// windowed against ~3.5 KiB/s stop-and-wait, the difference between a
        /// screenshot that arrives inside the master deadline and one that
        /// cannot.
        /// </summary>
        private void StartWindowedStream(string channel, string streamId, byte[] payload,
                                         string finalOp, int window)
        {
            Thread thread = new Thread(delegate()
            {
                try
                {
                    int position = 0;
                    Func<byte[]> readChunk = delegate()
                    {
                        if (position >= payload.Length)
                        {
                            return new byte[0];
                        }
                        int length = Math.Min(
                            WireConstants.DataChunkBytes, payload.Length - position);
                        byte[] chunk = new byte[length];
                        Array.Copy(payload, position, chunk, 0, length);
                        position += length;
                        return chunk;
                    };
                    int sent = _link.StreamData(channel, streamId, readChunk, window, null, null);
                    IDictionary<string, object> body = new Dictionary<string, object>();
                    body["status"] = "finished";
                    body["bytes"] = sent;
                    body["window"] = window;
                    _link.Event(channel, finalOp, streamId, body);
                }
                catch (Exception error)
                {
                    IDictionary<string, object> body = new Dictionary<string, object>();
                    body["status"] = "error";
                    body["code"] = "stream_failed";
                    body["message"] = error.Message;
                    body["retryable"] = true;
                    try
                    {
                        _link.Event(channel, finalOp, streamId, body);
                    }
                    catch (Exception)
                    {
                        // The link may already be closing.
                    }
                }
            });
            thread.IsBackground = true;
            string shortId = streamId.Length <= 8 ? streamId : streamId.Substring(0, 8);
            thread.Name = "fs-window-" + shortId;
            thread.Start();
        }

        private void StartStream(string channel, string streamId, byte[] payload,
                                 string finalOp)
        {
            Thread thread = new Thread(delegate()
            {
                try
                {
                    long sequence = 0;
                    for (int position = 0; position < payload.Length;
                         position += WireConstants.DataChunkBytes)
                    {
                        int length = Math.Min(
                            WireConstants.DataChunkBytes, payload.Length - position);
                        byte[] chunk = new byte[length];
                        Array.Copy(payload, position, chunk, 0, length);
                        _link.SendData(channel, streamId, sequence, chunk, null);
                        sequence++;
                    }
                    IDictionary<string, object> body = new Dictionary<string, object>();
                    body["status"] = "finished";
                    body["bytes"] = payload.Length;
                    _link.Event(channel, finalOp, streamId, body);
                }
                catch (Exception error)
                {
                    IDictionary<string, object> body = new Dictionary<string, object>();
                    body["status"] = "error";
                    body["code"] = "stream_failed";
                    body["message"] = error.Message;
                    body["retryable"] = true;
                    try
                    {
                        _link.Event(channel, finalOp, streamId, body);
                    }
                    catch (Exception)
                    {
                        // The link may already be closing.
                    }
                }
            });
            thread.IsBackground = true;
            string shortId = streamId.Length <= 8 ? streamId : streamId.Substring(0, 8);
            thread.Name = "fs-stream-" + shortId;
            thread.Start();
        }

        private void Transfer(IDictionary<string, object> frame)
        {
            IDictionary<string, object> body = Body(frame);
            string op = Op(frame);
            string transferId = Str(body, "transfer_id");
            IDictionary<string, object> result;
            if (op == "upload.begin")
            {
                result = _transfers.BeginUpload(
                    transferId,
                    Str(body, "path"),
                    Json.GetInt64(body, "size", 0),
                    Str(body, "sha256"));
            }
            else if (op == "upload.commit")
            {
                result = _transfers.CommitUpload(transferId);
            }
            else if (op == "download.begin")
            {
                result = _transfers.BeginDownload(
                    transferId,
                    Str(body, "path"),
                    Str(body, "checksum"),
                    WindowOrDefault(body));
            }
            else if (op == "status")
            {
                result = _transfers.Status(transferId);
            }
            else if (op == "cancel")
            {
                result = _transfers.Cancel(transferId);
            }
            else
            {
                throw new ProtocolError(
                    "unknown_transfer_op", "unknown transfer operation", false);
            }
            _link.Response(frame, result);
        }

        private static int WindowOrDefault(IDictionary<string, object> body)
        {
            object value;
            if (!body.TryGetValue("window", out value) || value == null || value is bool)
            {
                return WireConstants.DataWindowDefault;
            }
            long parsed;
            if (!Json.TryGetInt64(value, out parsed) ||
                parsed < 1 || parsed > WireConstants.DataWindowMax)
            {
                return WireConstants.DataWindowDefault;
            }
            return (int)parsed;
        }

        /// <summary>
        /// Data frames apply exactly once. The dedup key is recorded only
        /// after the frame is accepted, so a rejected gap is never
        /// fake-acknowledged on retransmission.
        /// </summary>
        private void Data(IDictionary<string, object> frame)
        {
            if (!_bound)
            {
                SendError(frame, "not_bound", "control.bind is mandatory", true);
                return;
            }
            string sessionId = Str(frame, "session_id");
            long sequence = Json.GetInt64(frame, "seq", 0);
            DedupKey key = new DedupKey(_linkId, sessionId, sequence);
            if (_dedup.Seen(key))
            {
                _link.Ack(frame["channel"] as string, sessionId, sequence);
                return;
            }
            byte[] data;
            try
            {
                data = Wire.DecodeData(frame);
                string channel = frame["channel"] as string;
                if (channel == "shell")
                {
                    _terminals.Input(sessionId, data);
                }
                else if (channel == "transfer")
                {
                    _transfers.UploadData(sessionId, sequence, data);
                }
                else
                {
                    throw new ProtocolError(
                        "data_channel_denied", "data_channel_denied", false);
                }
            }
            catch (ProtocolError error)
            {
                SendError(frame, error.Code, error.Message, false);
                return;
            }
            catch (WireError error)
            {
                SendError(frame, error.Code, error.Detail, false);
                return;
            }
            _dedup.Add(key);
            _link.Ack(frame["channel"] as string, sessionId, sequence);
        }
    }
}

// Process entry point of the compiled Windows payload. The bootstrap loader
// compiles the concatenated source to agent.exe with csc.exe
// (/main:Titella.Slave.AgentHost), so the agent no longer runs hosted inside a
// powershell.exe child: no classic PowerShell log channel records the
// bootstrap's own script text. With no arguments it reads agent.json (written
// by the loader next to the executable) and runs the agent; with --job it runs
// one piped job exactly like the former LoadFrom child did.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    internal static class AgentHost
    {
        private const string JobArgument = "--job";
        private const string ConfigName = "agent.json";

        public static int Main(string[] args)
        {
            if (args != null && args.Length == 1 && args[0] == JobArgument)
            {
                return JobEntry.Run();
            }
            if (args != null && args.Length == 0)
            {
                return RunAgent();
            }
            Console.Error.WriteLine(
                "titella agent: usage: agent.exe (agent) | agent.exe --job (one job)");
            return 2;
        }

        private static int RunAgent()
        {
            string configPath;
            try
            {
                string directory = Path.GetDirectoryName(
                    Assembly.GetExecutingAssembly().Location);
                if (string.IsNullOrEmpty(directory))
                {
                    Console.Error.WriteLine("titella agent: the executable has no location");
                    return 2;
                }
                configPath = Path.Combine(directory, ConfigName);
            }
            catch (Exception error)
            {
                Console.Error.WriteLine("titella agent: " + error.Message);
                return 2;
            }
            string text;
            try
            {
                text = File.ReadAllText(configPath);
            }
            catch (Exception error)
            {
                Console.Error.WriteLine(
                    "titella agent: agent.json is unreadable: " + error.Message);
                return 2;
            }
            // agent.json carries exactly the arguments the former loader child
            // passed to Agent.Run: {"bootstrap_dir":..., "link_id":...,
            // "port":..., "heartbeat_ms":5000, "grace_ms":30000}. A config
            // missing any field is invalid, never defaulted.
            Dictionary<string, object> config;
            string bootstrapDirectory;
            string linkId;
            string port;
            long heartbeat;
            long grace;
            try
            {
                config = Json.Parse(text) as Dictionary<string, object>;
                if (config == null)
                {
                    throw new WireError("invalid_json", "agent.json is not an object");
                }
                bootstrapDirectory = GetText(config, "bootstrap_dir");
                linkId = GetText(config, "link_id");
                port = GetText(config, "port");
                if (!Json.TryGetInt64(GetOrNull(config, "heartbeat_ms"), out heartbeat) ||
                    !Json.TryGetInt64(GetOrNull(config, "grace_ms"), out grace) ||
                    heartbeat < 0 || heartbeat > int.MaxValue ||
                    grace < 0 || grace > int.MaxValue)
                {
                    throw new WireError(
                        "invalid_json",
                        "agent.json requires heartbeat_ms and grace_ms integers");
                }
            }
            catch (Exception error)
            {
                Console.Error.WriteLine("titella agent: agent.json is invalid: " + error.Message);
                return 2;
            }
            return Agent.Run(bootstrapDirectory, linkId, port,
                             (int)heartbeat, (int)grace);
        }

        private static object GetOrNull(Dictionary<string, object> config, string key)
        {
            object value;
            return config.TryGetValue(key, out value) ? value : null;
        }

        private static string GetText(Dictionary<string, object> config, string key)
        {
            string value = GetOrNull(config, key) as string;
            if (value == null)
            {
                throw new WireError("invalid_json", "agent.json requires " + key);
            }
            return value;
        }
    }
}

// Transport and link of the Windows slave: an exclusive Win32 CDC
// transport, a shared-clipboard transport for agent_protocol = "clipboard",
// an internal Stream seam used by the contract tests, and the AgentLink
// that owns the reader/writer/heartbeat threads, the bounded queues, the
// per-block ACK bookkeeping and the sliding transfer window.
// Port of implementations/python/agent_link.py.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;

    /// <summary>Raised when the transport can no longer carry bytes.</summary>
    internal sealed class LinkLostException : Exception
    {
        private readonly int _error;

        public LinkLostException(int error, string message)
            : base(message)
        {
            _error = error;
        }

        public int Error
        {
            get { return _error; }
        }
    }

    /// <summary>Raised by AgentLink when an operation is refused or timed out.</summary>
    internal sealed class AgentLinkError : Exception
    {
        public AgentLinkError(string code, string message)
            : base(message)
        {
            Code = code;
        }

        public string Code { get; private set; }
    }

    /// <summary>Minimal transport: three verbs plus liveness.</summary>
    internal interface ILinkTransport : IDisposable
    {
        int Read(byte[] buffer, int offset, int count);
        void Write(byte[] buffer, int offset, int count);
        bool IsOpen { get; }
    }

    /// <summary>
    /// Exclusive Win32 CDC. CreateFileW with shareMode 0 reproduces the
    /// Python TIOCEXCL and makes the device single-owner; a NULL security
    /// descriptor makes the handle non-inheritable, which keeps the CDC out
    /// of every CreateProcessW(bInheritHandles: TRUE) launched by the agent.
    /// </summary>
    internal sealed class ComTransport : ILinkTransport
    {
        private readonly string _portName;
        // Reads and writes are independent: each verb holds only its own
        // gate, so a 100 ms read poll never delays a write and a 2 s write
        // never delays a read. Dispose takes both gates in a fixed order, so
        // a handle is never closed while a thread is inside ReadFile or
        // WriteFile with it.
        private readonly object _readGate = new object();
        private readonly object _writeGate = new object();
        private IntPtr _handle;
        private byte[] _readBuffer;
        private byte[] _writeBuffer;

        public ComTransport(string portName)
        {
            if (!IsValidPortName(portName))
            {
                throw new ArgumentException("A CDC port name such as COM7 is required", "portName");
            }
            _portName = portName;
        }

        public static bool IsValidPortName(string value)
        {
            if (value == null || value.Length < 4)
            {
                return false;
            }
            if (!(value[0] == 'C' && value[1] == 'O' && value[2] == 'M'))
            {
                return false;
            }
            if (value[3] < '1' || value[3] > '9')
            {
                return false;
            }
            for (int index = 4; index < value.Length; index++)
            {
                if (value[index] < '0' || value[index] > '9')
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Opens and configures the native USB CDC port: 2,000,000 8N1, no flow
        /// control, with DTR and RTS asserted because Arduino USB CDC reports
        /// itself connected only while both modem lines are high. The
        /// documented COMMTIMEOUTS poll recipe makes ReadFile return with zero
        /// bytes after 100 ms instead of blocking. Firmware disables the
        /// line-state reboot sequence, so asserting both lines cannot reset it.
        /// </summary>
        public void Open()
        {
            IntPtr handle = NativeMethods.CreateFileW(
                @"\\.\" + _portName,
                Win32Constants.GENERIC_READ | Win32Constants.GENERIC_WRITE,
                0u,
                IntPtr.Zero,
                Win32Constants.OPEN_EXISTING,
                Win32Constants.FILE_ATTRIBUTE_NORMAL,
                IntPtr.Zero);
            if (handle == new IntPtr(-1))
            {
                int error = Marshal.GetLastWin32Error();
                throw new LinkLostException(
                    error,
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "CreateFileW({0}) failed with {1}",
                        _portName,
                        error));
            }
            try
            {
                NativeMethods.SetupComm(handle, 8192u, 8192u);

                Win32Structs.DCB dcb = new Win32Structs.DCB();
                dcb.DCBlength = (uint)Marshal.SizeOf(typeof(Win32Structs.DCB));
                if (!NativeMethods.GetCommState(handle, ref dcb))
                {
                    throw new LinkLostException(
                        Marshal.GetLastWin32Error(), "GetCommState failed");
                }
                // Binary mode, DTR and RTS enabled, no parity/flow
                // control/XON/XOFF. DTR_CONTROL_ENABLE occupies bits 4-5;
                // RTS_CONTROL_ENABLE occupies bits 12-13.
                dcb.Flags = 0x00001011u;
                dcb.BaudRate = Win32Constants.CBR_2000000;
                dcb.ByteSize = 8;
                dcb.Parity = (byte)Win32Constants.NOPARITY;
                dcb.StopBits = Win32Constants.ONESTOPBIT;
                if (!NativeMethods.SetCommState(handle, ref dcb))
                {
                    throw new LinkLostException(
                        Marshal.GetLastWin32Error(), "SetCommState failed");
                }
                NativeMethods.EscapeCommFunction(handle, Win32Constants.SETDTR);
                NativeMethods.EscapeCommFunction(handle, Win32Constants.SETRTS);

                Win32Structs.COMMTIMEOUTS timeouts = new Win32Structs.COMMTIMEOUTS();
                timeouts.ReadIntervalTimeout = Win32Constants.MAXDWORD;
                timeouts.ReadTotalTimeoutMultiplier = Win32Constants.MAXDWORD;
                timeouts.ReadTotalTimeoutConstant = Win32Constants.READ_POLL_MS;
                timeouts.WriteTotalTimeoutMultiplier = 0u;
                timeouts.WriteTotalTimeoutConstant = Win32Constants.WRITE_TOTAL_MS;
                if (!NativeMethods.SetCommTimeouts(handle, ref timeouts))
                {
                    throw new LinkLostException(
                        Marshal.GetLastWin32Error(), "SetCommTimeouts failed");
                }

                lock (_readGate)
                {
                    lock (_writeGate)
                    {
                        _handle = handle;
                    }
                }
            }
            catch
            {
                NativeMethods.CloseHandle(handle);
                throw;
            }
        }

        public bool IsOpen
        {
            get
            {
                lock (_readGate)
                {
                    return _handle != IntPtr.Zero;
                }
            }
        }

        public int Read(byte[] buffer, int offset, int count)
        {
            lock (_readGate)
            {
                IntPtr handle = _handle;
                if (handle == IntPtr.Zero)
                {
                    throw new LinkLostException(0, "the transport is closed");
                }
                if (_readBuffer == null || _readBuffer.Length < count)
                {
                    _readBuffer = new byte[Math.Max(count, WireConstants.MaxFrameBytes)];
                }
                uint read;
                if (!NativeMethods.ReadFile(handle, _readBuffer, (uint)count, out read, IntPtr.Zero))
                {
                    throw new LinkLostException(
                        Marshal.GetLastWin32Error(), "ReadFile failed");
                }
                if (read == 0)
                {
                    return 0;
                }
                Array.Copy(_readBuffer, 0, buffer, offset, (int)read);
                return (int)read;
            }
        }

        public void Write(byte[] buffer, int offset, int count)
        {
            lock (_writeGate)
            {
                IntPtr handle = _handle;
                if (handle == IntPtr.Zero)
                {
                    throw new LinkLostException(0, "the transport is closed");
                }
                if (_writeBuffer == null || _writeBuffer.Length < count)
                {
                    _writeBuffer = new byte[Math.Max(count, WireConstants.FrameBufferBytes)];
                }
                Array.Copy(buffer, offset, _writeBuffer, 0, count);
                int sent = 0;
                while (sent < count)
                {
                    uint written;
                    uint remaining = (uint)(count - sent);
                    if (!NativeMethods.WriteFile(
                            handle, _writeBuffer, remaining, out written, IntPtr.Zero))
                    {
                        throw new LinkLostException(
                            Marshal.GetLastWin32Error(), "WriteFile failed");
                    }
                    if (written == 0)
                    {
                        throw new LinkLostException(0, "short write to the CDC");
                    }
                    sent += (int)written;
                    if (sent < count)
                    {
                        // Shift the tail to the front of the reusable buffer.
                        Array.Copy(_writeBuffer, sent, _writeBuffer, 0, count - sent);
                    }
                }
            }
        }

        public void Dispose()
        {
            IntPtr handle;
            lock (_writeGate)
            {
                lock (_readGate)
                {
                    handle = _handle;
                    _handle = IntPtr.Zero;
                }
            }
            if (handle != IntPtr.Zero)
            {
                NativeMethods.CloseHandle(handle);
            }
        }
    }

    /// <summary>
    /// Shared-clipboard transport for the window rig (agent_protocol =
    /// "clipboard"). Frames travel inside TITELLA_S2M/TITELLA_M2S packets
    /// (header "TITELLA_S2M:&lt;link_id&gt;:&lt;pkt_seq&gt;:&lt;ack_seq&gt;" then
    /// newline-delimited JSON v1 lines) written as CF_UNICODETEXT, so the
    /// same protocol runs where a CDC port does not exist. One unacknowledged
    /// outbound packet at a time; a pure acknowledgement reuses packet
    /// sequence 0 so it never requires an acknowledgement of its own.
    ///
    /// The master sends no idle heartbeats over the clipboard, so Read feeds
    /// AgentLink a synthetic local heartbeat while the link is quiet:
    /// AgentLink stays unchanged and its grace clock never expires. Idle
    /// outbound control heartbeats are dropped here for the mirror reason:
    /// a quiet link must never touch the user clipboard. The
    /// ExcludeClipboardContentFromMonitorProcessing and
    /// CanIncludeInClipboardHistory formats keep the packets out of the
    /// Windows clipboard history and sync monitors.
    /// </summary>
    internal sealed class ClipboardTransport : ILinkTransport
    {
        private const int ReadPollMs = 60;
        private const int ReadStepMs = 15;
        private const int AckDelayMs = 10;
        private const int ReassertMs = 150;
        private const int SynthHeartbeatMs = 2000;
        private const int MaxPacketLines = 16;
        private const int MaxReasserts = 40;
        private const int OpenBudgetMs = 300;
        private const int ClipboardRetryMs = 10;
        private const int MaxPartialBytes = WireConstants.FrameBufferBytes * 16;
        private const int MaxClipboardTextBytes = 4 * 1024 * 1024;

        private readonly string _linkId;
        // Read and Write both touch the queues and the sequence counters; a
        // single gate keeps the reader thread, the writer thread and Dispose
        // from racing. Clipboard calls happen under the gate, so the reader
        // thread is never inside an open clipboard while another write runs.
        private readonly object _gate = new object();
        private readonly MemoryStream _rxBuffer = new MemoryStream();
        private readonly List<string> _txLines = new List<string>();
        private readonly MemoryStream _txPartial = new MemoryStream();
        private bool _open;
        private long _lastSeenM2sSeq;
        private long _nextS2mSeq = 1;
        private long _inflightS2mSeq;
        private string _inflightPacketText;
        private long _inflightSentTicks;
        private int _inflightAttempts;
        private bool _ackNeeded;
        private long _ackNeededTicks;
        private long _lastSynthHeartbeatTicks;
        private uint _lastClipboardSeqNo;
        private uint _excludeFormat;
        private uint _historyFormat;

        public ClipboardTransport(string linkId)
        {
            if (!WireConstants.IsLinkId(linkId))
            {
                throw new ArgumentException(
                    "32 lowercase hexadecimal characters are required", "linkId");
            }
            _linkId = linkId;
        }

        /// <summary>True for the sentinel the loader renders for this rig.</summary>
        internal static bool IsClipboardPort(string port)
        {
            return string.Equals(port, "CLIPBOARD", StringComparison.OrdinalIgnoreCase);
        }

        public void Open()
        {
            lock (_gate)
            {
                if (_open)
                {
                    return;
                }
                // Registered formats are process-wide ids; a zero result is
                // an acceptable degradation, never a fatal error.
                _excludeFormat = SafeRegisterFormat(
                    "ExcludeClipboardContentFromMonitorProcessing");
                _historyFormat = SafeRegisterFormat(
                    "CanIncludeInClipboardHistory");
                if (!ClipboardReachable(OpenBudgetMs))
                {
                    throw new LinkLostException(0, "the clipboard is not available");
                }
                _open = true;
                _lastSynthHeartbeatTicks = NowTicks();
                // Zero means "never read": the first poll must inspect whatever
                // the loader or the master left on the clipboard, including a
                // packet written before this agent opened.
                _lastClipboardSeqNo = 0;
            }
        }

        public bool IsOpen
        {
            get
            {
                lock (_gate)
                {
                    return _open;
                }
            }
        }

        /// <summary>
        /// One bounded poll cycle: consume a master packet when the clipboard
        /// sequence number moved, re-assert an unacknowledged packet that was
        /// overwritten, flush pending outbound lines and hand back buffered
        /// frame bytes. A synthetic heartbeat keeps AgentLink alive when the
        /// clipboard stays quiet. The gate is released between steps so the
        /// writer thread never waits on a poll sleep.
        /// </summary>
        public int Read(byte[] buffer, int offset, int count)
        {
            long deadline = NowTicks() + TicksFromMs(ReadPollMs);
            while (true)
            {
                int copied;
                lock (_gate)
                {
                    if (!_open)
                    {
                        throw new LinkLostException(0, "the transport is closed");
                    }
                    copied = DrainRx(buffer, offset, count);
                    if (copied == 0)
                    {
                        PollClipboard();
                        FlushOutbound();
                        copied = DrainRx(buffer, offset, count);
                    }
                    if (copied == 0
                        && ElapsedMs(_lastSynthHeartbeatTicks) >= SynthHeartbeatMs)
                    {
                        EnqueueSynthHeartbeat();
                        copied = DrainRx(buffer, offset, count);
                    }
                    if (copied > 0)
                    {
                        _lastSynthHeartbeatTicks = NowTicks();
                        return copied;
                    }
                }
                if (NowTicks() >= deadline)
                {
                    return 0;
                }
                Thread.Sleep(ReadStepMs);
            }
        }

        /// <summary>
        /// Buffers one encoded frame until its newline arrives. The clipboard
        /// write itself happens in Read, so the writer thread never blocks on
        /// an externally owned clipboard.
        /// </summary>
        public void Write(byte[] buffer, int offset, int count)
        {
            lock (_gate)
            {
                if (!_open)
                {
                    throw new LinkLostException(0, "the transport is closed");
                }
                int end = offset + count;
                for (int position = offset; position < end; position++)
                {
                    byte value = buffer[position];
                    if (value == 0x0A)
                    {
                        string line = Encoding.UTF8.GetString(_txPartial.ToArray());
                        _txPartial.SetLength(0);
                        if (line.Length == 0 || IsIdleHeartbeat(line))
                        {
                            continue;
                        }
                        _txLines.Add(line);
                        continue;
                    }
                    _txPartial.WriteByte(value);
                    if (_txPartial.Length > MaxPartialBytes)
                    {
                        // The wire never splits a line past the frame bound; a
                        // runaway partial is a protocol violation, not a frame.
                        _txPartial.SetLength(0);
                    }
                }
            }
        }

        public void Dispose()
        {
            lock (_gate)
            {
                _open = false;
                _txLines.Clear();
                _txPartial.SetLength(0);
                _rxBuffer.SetLength(0);
                _ackNeeded = false;
                _inflightS2mSeq = 0;
                _inflightPacketText = null;
                _inflightAttempts = 0;
            }
        }

        private void PollClipboard()
        {
            uint sequence = NativeMethods.GetClipboardSequenceNumber();
            bool reassertDue = _inflightS2mSeq != 0
                && ElapsedMs(_inflightSentTicks) >= ReassertMs;
            if (sequence == _lastClipboardSeqNo && !reassertDue)
            {
                return;
            }
            string text;
            if (!TryReadClipboard(out text))
            {
                // The clipboard is held by another process; retry next poll.
                return;
            }
            _lastClipboardSeqNo = sequence;
            ConsumeMasterPacket(text);
            if (!reassertDue || _inflightS2mSeq == 0)
            {
                return;
            }
            if (string.Equals(text ?? string.Empty, _inflightPacketText,
                              StringComparison.Ordinal))
            {
                return;
            }
            if (_inflightAttempts >= MaxReasserts)
            {
                // The peer stopped consuming packets: give the block back to
                // AgentLink (its own ACK timeout retries the frame) instead of
                // overwriting the user clipboard forever.
                _inflightS2mSeq = 0;
                _inflightPacketText = null;
                _inflightAttempts = 0;
                return;
            }
            if (TryWriteClipboard(_inflightPacketText))
            {
                _inflightAttempts++;
                _inflightSentTicks = NowTicks();
                _lastClipboardSeqNo = NativeMethods.GetClipboardSequenceNumber();
            }
        }

        private void ConsumeMasterPacket(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return;
            }
            string prefix = "TITELLA_M2S:" + _linkId + ":";
            if (!text.StartsWith(prefix, StringComparison.Ordinal))
            {
                // User content or another link's traffic; ours never starts
                // with M2S, so nothing to consume.
                return;
            }
            int headerEnd = text.IndexOf('\n');
            if (headerEnd < 0)
            {
                return;
            }
            string header = text.Substring(0, headerEnd).TrimEnd('\r');
            string[] parts = header.Split(':');
            if (parts.Length != 4)
            {
                return;
            }
            long m2sSeq;
            long ackS2m;
            if (!long.TryParse(parts[2], NumberStyles.Integer,
                               CultureInfo.InvariantCulture, out m2sSeq) ||
                !long.TryParse(parts[3], NumberStyles.Integer,
                               CultureInfo.InvariantCulture, out ackS2m))
            {
                return;
            }
            if (_inflightS2mSeq != 0 && ackS2m >= _inflightS2mSeq)
            {
                _inflightS2mSeq = 0;
                _inflightPacketText = null;
                _inflightAttempts = 0;
            }
            if (m2sSeq > _lastSeenM2sSeq)
            {
                _lastSeenM2sSeq = m2sSeq;
                AppendRxLines(headerEnd + 1 < text.Length
                    ? text.Substring(headerEnd + 1)
                    : string.Empty);
                _ackNeeded = true;
                _ackNeededTicks = NowTicks();
                return;
            }
            if (m2sSeq == _lastSeenM2sSeq && m2sSeq > 0)
            {
                // A re-asserted duplicate: its payload is already buffered, but
                // the peer still needs the acknowledgement it missed.
                _ackNeeded = true;
                _ackNeededTicks = NowTicks();
            }
        }

        private void AppendRxLines(string body)
        {
            if (body.Length == 0)
            {
                return;
            }
            string[] lines = body.Split('\n');
            foreach (string raw in lines)
            {
                // A clipboard sync layer may normalize LF to CRLF.
                string line = raw.TrimEnd('\r');
                if (line.Length == 0)
                {
                    continue;
                }
                byte[] bytes = Encoding.UTF8.GetBytes(line + "\n");
                if (bytes.Length > WireConstants.FrameBufferBytes)
                {
                    continue;
                }
                _rxBuffer.Write(bytes, 0, bytes.Length);
            }
        }

        private void FlushOutbound()
        {
            if (!_open || _inflightS2mSeq != 0)
            {
                return;
            }
            if (_txLines.Count > 0)
            {
                int take = Math.Min(MaxPacketLines, _txLines.Count);
                long sequence = _nextS2mSeq;
                StringBuilder packet = new StringBuilder();
                packet.Append("TITELLA_S2M:").Append(_linkId).Append(':')
                    .Append(sequence).Append(':').Append(_lastSeenM2sSeq)
                    .Append('\n');
                for (int index = 0; index < take; index++)
                {
                    packet.Append(_txLines[index]).Append('\n');
                }
                string text = packet.ToString();
                if (!TryWriteClipboard(text))
                {
                    return; // clipboard busy; the next poll retries
                }
                _txLines.RemoveRange(0, take);
                _nextS2mSeq = sequence + 1;
                _inflightS2mSeq = sequence;
                _inflightPacketText = text;
                _inflightSentTicks = NowTicks();
                _inflightAttempts = 0;
                // The packet header already carries the acknowledgement.
                _ackNeeded = false;
                _lastClipboardSeqNo = NativeMethods.GetClipboardSequenceNumber();
                return;
            }
            if (_ackNeeded && ElapsedMs(_ackNeededTicks) >= AckDelayMs)
            {
                // Delay the pure acknowledgement briefly so responses produced
                // by the dispatch thread ride the same packet.
                StringBuilder packet = new StringBuilder();
                packet.Append("TITELLA_S2M:").Append(_linkId).Append(":0:")
                    .Append(_lastSeenM2sSeq).Append('\n');
                if (TryWriteClipboard(packet.ToString()))
                {
                    _ackNeeded = false;
                    _lastClipboardSeqNo = NativeMethods.GetClipboardSequenceNumber();
                }
            }
        }

        private void EnqueueSynthHeartbeat()
        {
            _lastSynthHeartbeatTicks = NowTicks();
            string line = "{\"v\":1,\"channel\":\"control\",\"type\":\"heartbeat\","
                + "\"link_id\":\"" + _linkId + "\"}";
            byte[] bytes = Encoding.UTF8.GetBytes(line + "\n");
            _rxBuffer.Write(bytes, 0, bytes.Length);
        }

        private int DrainRx(byte[] buffer, int offset, int count)
        {
            if (_rxBuffer.Position >= _rxBuffer.Length)
            {
                return 0;
            }
            int available = (int)(_rxBuffer.Length - _rxBuffer.Position);
            int take = Math.Min(count, available);
            _rxBuffer.Read(buffer, offset, take);
            if (_rxBuffer.Position >= _rxBuffer.Length)
            {
                _rxBuffer.SetLength(0);
                _rxBuffer.Position = 0;
            }
            return take;
        }

        private bool TryReadClipboard(out string text)
        {
            text = null;
            long deadline = NowTicks() + TicksFromMs(OpenBudgetMs);
            while (true)
            {
                if (!NativeMethods.OpenClipboard(IntPtr.Zero))
                {
                    if (NowTicks() < deadline)
                    {
                        Thread.Sleep(ClipboardRetryMs);
                        continue;
                    }
                    return false;
                }
                try
                {
                    if (!NativeMethods.IsClipboardFormatAvailable(
                            Win32Constants.CF_UNICODETEXT))
                    {
                        return true;
                    }
                    IntPtr handle = NativeMethods.GetClipboardData(
                        Win32Constants.CF_UNICODETEXT);
                    if (handle == IntPtr.Zero)
                    {
                        return true;
                    }
                    IntPtr locked = NativeMethods.GlobalLock(handle);
                    if (locked == IntPtr.Zero)
                    {
                        return false;
                    }
                    try
                    {
                        long bytes = (long)NativeMethods.GlobalSize(handle).ToUInt64();
                        if (bytes < 2)
                        {
                            text = string.Empty;
                            return true;
                        }
                        if (bytes > MaxClipboardTextBytes)
                        {
                            bytes = MaxClipboardTextBytes;
                        }
                        string raw = Marshal.PtrToStringUni(locked, (int)(bytes / 2));
                        int terminator = raw.IndexOf('\0');
                        text = terminator >= 0 ? raw.Substring(0, terminator) : raw;
                        return true;
                    }
                    finally
                    {
                        NativeMethods.GlobalUnlock(handle);
                    }
                }
                finally
                {
                    NativeMethods.CloseClipboard();
                }
            }
        }

        private bool TryWriteClipboard(string text)
        {
            if (text == null)
            {
                return false;
            }
            long deadline = NowTicks() + TicksFromMs(OpenBudgetMs);
            while (true)
            {
                if (!NativeMethods.OpenClipboard(IntPtr.Zero))
                {
                    if (NowTicks() < deadline)
                    {
                        Thread.Sleep(ClipboardRetryMs);
                        continue;
                    }
                    return false;
                }
                try
                {
                    if (!NativeMethods.EmptyClipboard())
                    {
                        return false;
                    }
                    if (!SetClipboardString(text))
                    {
                        return false;
                    }
                    if (_excludeFormat != 0)
                    {
                        SetClipboardDword(_excludeFormat);
                    }
                    if (_historyFormat != 0)
                    {
                        SetClipboardDword(_historyFormat);
                    }
                    return true;
                }
                finally
                {
                    NativeMethods.CloseClipboard();
                }
            }
        }

        private static bool SetClipboardString(string text)
        {
            int bytes = (text.Length + 1) * 2;
            IntPtr memory = NativeMethods.GlobalAlloc(
                Win32Constants.GMEM_MOVEABLE, (UIntPtr)(uint)bytes);
            if (memory == IntPtr.Zero)
            {
                return false;
            }
            IntPtr locked = NativeMethods.GlobalLock(memory);
            if (locked == IntPtr.Zero)
            {
                NativeMethods.GlobalFree(memory);
                return false;
            }
            try
            {
                char[] chars = text.ToCharArray();
                Marshal.Copy(chars, 0, locked, chars.Length);
                Marshal.WriteInt16(locked, chars.Length * 2, 0);
            }
            finally
            {
                NativeMethods.GlobalUnlock(memory);
            }
            if (NativeMethods.SetClipboardData(Win32Constants.CF_UNICODETEXT, memory)
                == IntPtr.Zero)
            {
                NativeMethods.GlobalFree(memory);
                return false;
            }
            // Ownership transferred to the clipboard on success: never free.
            return true;
        }

        private static bool SetClipboardDword(uint format)
        {
            // GMEM_ZEROINIT supplies the four zero bytes; presence of the
            // format is what monitors read, and a zero DWORD for
            // CanIncludeInClipboardHistory means "do not include".
            IntPtr memory = NativeMethods.GlobalAlloc(
                Win32Constants.GMEM_MOVEABLE | Win32Constants.GMEM_ZEROINIT, (UIntPtr)4u);
            if (memory == IntPtr.Zero)
            {
                return false;
            }
            if (NativeMethods.SetClipboardData(format, memory) == IntPtr.Zero)
            {
                NativeMethods.GlobalFree(memory);
                return false;
            }
            return true;
        }

        private static uint SafeRegisterFormat(string name)
        {
            try
            {
                return NativeMethods.RegisterClipboardFormatW(name);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private static bool ClipboardReachable(int budgetMs)
        {
            long deadline = NowTicks() + TicksFromMs(budgetMs);
            while (true)
            {
                if (NativeMethods.OpenClipboard(IntPtr.Zero))
                {
                    NativeMethods.CloseClipboard();
                    return true;
                }
                if (NowTicks() >= deadline)
                {
                    return false;
                }
                Thread.Sleep(ClipboardRetryMs);
            }
        }

        /// <summary>
        /// Exactly the AgentLink idle heartbeat. Everything else, including a
        /// payload string that happens to mention a heartbeat, is real
        /// traffic: a JSON string escapes its quotes, so this pair of
        /// substrings can only appear as actual frame fields.
        /// </summary>
        private static bool IsIdleHeartbeat(string line)
        {
            return line.IndexOf("\"channel\":\"control\"", StringComparison.Ordinal) >= 0
                && line.IndexOf("\"type\":\"heartbeat\"", StringComparison.Ordinal) >= 0;
        }

        private static long NowTicks()
        {
            return Stopwatch.GetTimestamp();
        }

        private static long TicksFromMs(long milliseconds)
        {
            return (long)(milliseconds / 1000.0 * Stopwatch.Frequency);
        }

        private static long ElapsedMs(long sinceTicks)
        {
            return (long)((NowTicks() - sinceTicks) * 1000.0 / Stopwatch.Frequency);
        }
    }

    /// <summary>
    /// Internal test seam: the same three verbs over a managed Stream. It is
    /// not selectable from the protocol and carries no network code; a
    /// contract test asserts that the type is not public.
    /// </summary>
    internal sealed class StreamTransport : ILinkTransport
    {
        private readonly Stream _readStream;
        private readonly Stream _writeStream;
        private readonly object _lock = new object();
        private bool _open;

        public StreamTransport(Stream stream)
            : this(stream, stream)
        {
        }

        public StreamTransport(Stream readStream, Stream writeStream)
        {
            if (readStream == null)
            {
                throw new ArgumentNullException("readStream");
            }
            if (writeStream == null)
            {
                throw new ArgumentNullException("writeStream");
            }
            _readStream = readStream;
            _writeStream = writeStream;
            _open = true;
        }

        public bool IsOpen
        {
            get
            {
                lock (_lock)
                {
                    return _open;
                }
            }
        }

        public int Read(byte[] buffer, int offset, int count)
        {
            lock (_lock)
            {
                if (!_open)
                {
                    throw new LinkLostException(0, "the stream is closed");
                }
                return _readStream.Read(buffer, offset, count);
            }
        }

        public void Write(byte[] buffer, int offset, int count)
        {
            lock (_lock)
            {
                if (!_open)
                {
                    throw new LinkLostException(0, "the stream is closed");
                }
                _writeStream.Write(buffer, offset, count);
                _writeStream.Flush();
            }
        }

        public void Dispose()
        {
            lock (_lock)
            {
                _open = false;
            }
        }
    }

    /// <summary>
    /// Bounded blocking queue. Enqueue with a timeout; the reader uses it for
    /// inbound frames and terminals for their output blocks.
    /// </summary>
    internal sealed class BoundedQueue<T>
    {
        private readonly Queue<T> _items = new Queue<T>();
        private readonly object _gate = new object();
        private readonly int _capacity;

        public BoundedQueue(int capacity)
        {
            if (capacity < 1)
            {
                throw new ArgumentOutOfRangeException("capacity");
            }
            _capacity = capacity;
        }

        public int Count
        {
            get
            {
                lock (_gate)
                {
                    return _items.Count;
                }
            }
        }

        public bool TryEnqueue(T item, int timeoutMs)
        {
            long deadline = Environment.TickCount + timeoutMs;
            lock (_gate)
            {
                while (_items.Count >= _capacity)
                {
                    int remaining = (int)(deadline - Environment.TickCount);
                    if (remaining <= 0)
                    {
                        return false;
                    }
                    Monitor.Wait(_gate, remaining);
                }
                _items.Enqueue(item);
                Monitor.PulseAll(_gate);
                return true;
            }
        }

        public bool TryDequeue(int timeoutMs, out T item)
        {
            item = default(T);
            long deadline = Environment.TickCount + timeoutMs;
            lock (_gate)
            {
                while (_items.Count == 0)
                {
                    int remaining = (int)(deadline - Environment.TickCount);
                    if (remaining <= 0)
                    {
                        return false;
                    }
                    Monitor.Wait(_gate, remaining);
                }
                item = _items.Dequeue();
                Monitor.PulseAll(_gate);
                return true;
            }
        }
    }

    /// <summary>
    /// Stable outbound queue: ack/heartbeat first, then hello/response/
    /// error/event, then shell, then everything else. FIFO within a level,
    /// which is exactly Python's (priority, order) tuple ordering.
    /// </summary>
    internal sealed class BoundedPriorityQueue
    {
        private readonly Queue<IDictionary<string, object>>[] _levels;
        private readonly object _gate = new object();
        private readonly int _capacity;
        private int _count;

        public BoundedPriorityQueue(int capacity)
        {
            if (capacity < 1)
            {
                throw new ArgumentOutOfRangeException("capacity");
            }
            _capacity = capacity;
            _levels = new Queue<IDictionary<string, object>>[4];
            for (int index = 0; index < _levels.Length; index++)
            {
                _levels[index] = new Queue<IDictionary<string, object>>();
            }
        }

        public static int PriorityOf(IDictionary<string, object> frame)
        {
            string kind = frame["type"] as string;
            if (kind == "ack" || kind == "heartbeat")
            {
                return 0;
            }
            if (kind == "hello" || kind == "response" || kind == "error" || kind == "event")
            {
                return 1;
            }
            if ("shell".Equals(frame["channel"] as string, StringComparison.Ordinal))
            {
                return 2;
            }
            return 3;
        }

        public bool TryEnqueue(IDictionary<string, object> frame, int timeoutMs)
        {
            long deadline = Environment.TickCount + timeoutMs;
            int level = PriorityOf(frame);
            lock (_gate)
            {
                while (_count >= _capacity)
                {
                    int remaining = (int)(deadline - Environment.TickCount);
                    if (remaining <= 0)
                    {
                        return false;
                    }
                    Monitor.Wait(_gate, remaining);
                }
                _levels[level].Enqueue(frame);
                _count++;
                Monitor.PulseAll(_gate);
                return true;
            }
        }

        public bool TryDequeue(int timeoutMs, out IDictionary<string, object> frame)
        {
            frame = null;
            long deadline = Environment.TickCount + timeoutMs;
            lock (_gate)
            {
                while (_count == 0)
                {
                    int remaining = (int)(deadline - Environment.TickCount);
                    if (remaining <= 0)
                    {
                        return false;
                    }
                    Monitor.Wait(_gate, remaining);
                }
                for (int level = 0; level < _levels.Length; level++)
                {
                    if (_levels[level].Count > 0)
                    {
                        frame = _levels[level].Dequeue();
                        _count--;
                        Monitor.PulseAll(_gate);
                        return true;
                    }
                }
                return false;
            }
        }
    }

    /// <summary>(session_id, seq) identity of one data block awaiting its ACK.</summary>
    internal struct AckKey : IEquatable<AckKey>
    {
        private readonly string _sessionId;
        private readonly long _seq;

        public AckKey(string sessionId, long seq)
        {
            _sessionId = sessionId;
            _seq = seq;
        }

        public bool Equals(AckKey other)
        {
            return _seq == other._seq &&
                   string.Equals(_sessionId, other._sessionId, StringComparison.Ordinal);
        }

        public override bool Equals(object obj)
        {
            return obj is AckKey && Equals((AckKey)obj);
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + (_sessionId == null ? 0 : _sessionId.GetHashCode());
            hash = hash * 31 + _seq.GetHashCode();
            return hash;
        }
    }

    /// <summary>
    /// CDC link of the ephemeral agent. One reader, one writer and one
    /// heartbeat thread; bounded inbound/outbound queues; per-block ACK
    /// stop-and-wait for SendData and a sliding window for StreamData.
    /// </summary>
    internal sealed class AgentLink
    {
        private const int AckTimeoutMs = 1000;
        private const int AckRetries = 3;
        private const int QueueTimeoutMs = 1000;

        private static readonly int[] BackoffMs = new int[] { 500, 1000, 2000, 5000 };

        private readonly string _linkId;
        private readonly Func<ILinkTransport> _transportFactory;
        private readonly int _heartbeatMs;
        private readonly int _graceMs;
        private readonly Action _onConnect;
        private readonly Action _onExpired;
        private readonly BoundedQueue<IDictionary<string, object>> _inbound;
        private readonly BoundedPriorityQueue _outbound;
        private readonly ManualResetEventSlim _connected;
        private readonly ManualResetEventSlim _stop;
        private readonly object _ackLock;
        private readonly Dictionary<AckKey, ManualResetEventSlim> _acks;
        private readonly object _dataLock;
        private readonly object _transportLock;
        private readonly List<Thread> _threads;
        private ILinkTransport _transport;
        private long _lastSeenTicks;
        private long _disconnectedSinceTicks;
        private bool _expired;
        private bool _started;

        public AgentLink(string linkId, Func<ILinkTransport> transportFactory,
                         int heartbeatMs, int graceMs,
                         Action onConnect, Action onExpired)
        {
            _linkId = linkId;
            _transportFactory = transportFactory;
            _heartbeatMs = Math.Max(1000, heartbeatMs);
            _graceMs = Math.Max(graceMs, _heartbeatMs);
            _onConnect = onConnect;
            _onExpired = onExpired;
            _inbound = new BoundedQueue<IDictionary<string, object>>(WireConstants.MaxOutboundFrames);
            _outbound = new BoundedPriorityQueue(WireConstants.MaxOutboundFrames);
            _connected = new ManualResetEventSlim(false);
            _stop = new ManualResetEventSlim(false);
            _ackLock = new object();
            _acks = new Dictionary<AckKey, ManualResetEventSlim>();
            _dataLock = new object();
            _transportLock = new object();
            _threads = new List<Thread>();
            _lastSeenTicks = Stopwatch.GetTimestamp();
        }

        public string LinkId
        {
            get { return _linkId; }
        }

        public BoundedQueue<IDictionary<string, object>> Inbound
        {
            get { return _inbound; }
        }

        public bool Expired
        {
            get
            {
                lock (_transportLock)
                {
                    return _expired;
                }
            }
        }

        public bool Connected
        {
            get
            {
                if (!_connected.IsSet)
                {
                    return false;
                }
                ILinkTransport transport = CurrentTransport;
                return transport != null && transport.IsOpen;
            }
        }

        private ILinkTransport CurrentTransport
        {
            get
            {
                lock (_transportLock)
                {
                    return _transport;
                }
            }
        }

        public void Start()
        {
            lock (_transportLock)
            {
                if (_started)
                {
                    return;
                }
                _started = true;
            }
            Thread reader = new Thread(ReaderLoop);
            reader.IsBackground = true;
            reader.Name = "agent-cdc-reader";
            Thread writer = new Thread(WriterLoop);
            writer.IsBackground = true;
            writer.Name = "agent-cdc-writer";
            Thread heartbeat = new Thread(HeartbeatLoop);
            heartbeat.IsBackground = true;
            heartbeat.Name = "agent-heartbeat";
            _threads.Add(reader);
            _threads.Add(writer);
            _threads.Add(heartbeat);
            reader.Start();
            writer.Start();
            heartbeat.Start();
        }

        public void Close()
        {
            _stop.Set();
            _connected.Set();
            DisposeTransport();
            lock (_ackLock)
            {
                foreach (KeyValuePair<AckKey, ManualResetEventSlim> entry in _acks)
                {
                    entry.Value.Set();
                }
                _acks.Clear();
                Monitor.PulseAll(_ackLock);
            }
            foreach (Thread thread in _threads)
            {
                if (thread != Thread.CurrentThread)
                {
                    thread.Join(2000);
                }
            }
        }

        private void DisposeTransport()
        {
            ILinkTransport transport;
            lock (_transportLock)
            {
                transport = _transport;
                _transport = null;
                _connected.Reset();
            }
            if (transport != null)
            {
                try
                {
                    transport.Dispose();
                }
                catch (Exception)
                {
                    // Disposal of an already-dead handle is never fatal.
                }
            }
        }

        private void MarkLost()
        {
            lock (_transportLock)
            {
                if (_disconnectedSinceTicks == 0)
                {
                    _disconnectedSinceTicks = Stopwatch.GetTimestamp();
                }
            }
            DisposeTransport();
        }

        private void OpenTransport()
        {
            ILinkTransport transport = _transportFactory();
            lock (_transportLock)
            {
                _transport = transport;
                // A successful reopen does NOT reset the grace origin: Python
                // keeps counting from the loss moment until a matching frame
                // arrives, so a peer that reopens without sending frames still
                // expires on schedule.
                _connected.Set();
            }
            if (_onConnect != null)
            {
                _onConnect();
            }
        }

        private static long NowTicks()
        {
            return Stopwatch.GetTimestamp();
        }

        private static long MillisecondsToTicks(long milliseconds)
        {
            return (long)(milliseconds / 1000.0 * Stopwatch.Frequency);
        }

        private void ReaderLoop()
        {
            byte[] buffer = new byte[WireConstants.MaxFrameBytes];
            int attempt = 0;
            FrameParser parser = new FrameParser(WireConstants.FirmwareToSlave, true);
            while (!_stop.IsSet)
            {
                ILinkTransport transport = CurrentTransport;
                if (transport == null || !transport.IsOpen)
                {
                    try
                    {
                        OpenTransport();
                        attempt = 0;
                        parser = new FrameParser(WireConstants.FirmwareToSlave, true);
                        transport = CurrentTransport;
                    }
                    catch (Exception)
                    {
                        int delay = BackoffMs[Math.Min(attempt, BackoffMs.Length - 1)];
                        attempt++;
                        if (_stop.Wait(delay))
                        {
                            return;
                        }
                        continue;
                    }
                }
                if (transport == null)
                {
                    continue;
                }
                int count;
                try
                {
                    count = transport.Read(buffer, 0, buffer.Length);
                }
                catch (LinkLostException)
                {
                    MarkLost();
                    continue;
                }
                catch (Exception)
                {
                    MarkLost();
                    continue;
                }
                if (count <= 0)
                {
                    continue;
                }
                IList<IDictionary<string, object>> frames = parser.Feed(buffer, 0, count);
                foreach (IDictionary<string, object> frame in frames)
                {
                    object linkValue;
                    frame.TryGetValue("link_id", out linkValue);
                    if (!string.Equals(linkValue as string, _linkId, StringComparison.Ordinal))
                    {
                        continue;
                    }
                    lock (_transportLock)
                    {
                        _lastSeenTicks = NowTicks();
                        _disconnectedSinceTicks = 0;
                    }
                    string kind = frame["type"] as string;
                    if (kind == "ack")
                    {
                        object sessionValue;
                        object seqValue;
                        frame.TryGetValue("session_id", out sessionValue);
                        frame.TryGetValue("ack_seq", out seqValue);
                        long seq;
                        Json.TryGetInt64(seqValue, out seq);
                        AckKey key = new AckKey(sessionValue as string, seq);
                        lock (_ackLock)
                        {
                            ManualResetEventSlim waiter;
                            if (_acks.TryGetValue(key, out waiter))
                            {
                                waiter.Set();
                            }
                            Monitor.PulseAll(_ackLock);
                        }
                    }
                    else
                    {
                        if (!_inbound.TryEnqueue(frame, QueueTimeoutMs))
                        {
                            SendError(frame, "queue_full", "inbound queue full", true);
                        }
                    }
                }
            }
        }

        public void SendFrame(IDictionary<string, object> frame)
        {
            if (_stop.IsSet)
            {
                throw new AgentLinkError("link_closed", "link closed");
            }
            Wire.EncodeFrame(frame, WireConstants.SlaveToFirmware);
            if (!_outbound.TryEnqueue(frame, QueueTimeoutMs))
            {
                throw new AgentLinkError("queue_full", "outbound queue full");
            }
        }

        private void WriterLoop()
        {
            while (!_stop.IsSet)
            {
                IDictionary<string, object> frame;
                if (!_outbound.TryDequeue(250, out frame))
                {
                    continue;
                }
                byte[] payload = Wire.EncodeFrame(frame, WireConstants.SlaveToFirmware);
                while (!_stop.IsSet)
                {
                    if (!_connected.Wait(250))
                    {
                        continue;
                    }
                    ILinkTransport transport = CurrentTransport;
                    if (transport == null)
                    {
                        continue;
                    }
                    try
                    {
                        transport.Write(payload, 0, payload.Length);
                        break;
                    }
                    catch (LinkLostException)
                    {
                        MarkLost();
                    }
                    catch (Exception)
                    {
                        MarkLost();
                    }
                }
            }
        }

        private void HeartbeatLoop()
        {
            while (!_stop.Wait(_heartbeatMs))
            {
                if (Connected)
                {
                    try
                    {
                        SendFrame(Wire.BaseFrame(
                            _linkId, "control", "heartbeat"));
                    }
                    catch (Exception)
                    {
                        // A heartbeat that cannot be queued is not fatal; the
                        // grace check below still decides expiry.
                    }
                }
                long origin;
                lock (_transportLock)
                {
                    origin = _disconnectedSinceTicks != 0
                        ? _disconnectedSinceTicks
                        : _lastSeenTicks;
                }
                if (origin != 0 &&
                    NowTicks() - origin > MillisecondsToTicks(_graceMs))
                {
                    bool alreadyExpired;
                    lock (_transportLock)
                    {
                        alreadyExpired = _expired;
                        _expired = true;
                    }
                    if (!alreadyExpired)
                    {
                        if (_onExpired != null)
                        {
                            _onExpired();
                        }
                        _stop.Set();
                        DisposeTransport();
                        return;
                    }
                }
            }
        }

        public void Response(IDictionary<string, object> request, IDictionary<string, object> body)
        {
            SendFrame(Wire.BaseFrame(
                _linkId,
                request["channel"] as string,
                "response",
                "request_id", request["request_id"],
                "op", request["op"],
                "body", body));
        }

        public void SendError(IDictionary<string, object> request, string code,
                              string message, bool retryable)
        {
            IDictionary<string, object> body = new Dictionary<string, object>();
            body["code"] = code;
            body["message"] = message;
            body["retryable"] = retryable;
            object requestId;
            request.TryGetValue("request_id", out requestId);
            long parsed;
            object channelValue;
            request.TryGetValue("channel", out channelValue);
            string channel = channelValue as string;
            if (channel == null)
            {
                channel = "control";
            }
            if (requestId != null && Json.TryGetInt64(requestId, out parsed))
            {
                object opValue;
                request.TryGetValue("op", out opValue);
                string op = opValue as string;
                if (op == null)
                {
                    op = "unknown";
                }
                SendFrame(Wire.BaseFrame(
                    _linkId, channel, "error",
                    "request_id", requestId,
                    "op", op,
                    "body", body));
            }
            else
            {
                SendFrame(Wire.BaseFrame(
                    _linkId, channel, "error",
                    "body", body));
            }
        }

        public void Event(string channel, string op, string sessionId, IDictionary<string, object> body)
        {
            SendFrame(Wire.BaseFrame(
                _linkId, channel, "event",
                "op", op,
                "session_id", sessionId,
                "body", body));
        }

        public void Ack(string channel, string sessionId, long sequence)
        {
            SendFrame(Wire.BaseFrame(
                _linkId, channel, "ack",
                "session_id", sessionId,
                "ack_seq", sequence));
        }

        /// <summary>
        /// Stop-and-wait per block under the data lock: 1 + 3 resends, one
        /// second each. A large file never interleaves with terminal bytes.
        /// </summary>
        public void SendData(string channel, string sessionId, long sequence,
                             byte[] data, IDictionary<string, object> extra)
        {
            IDictionary<string, object> frame = BuildDataFrame(channel, sessionId, sequence, data, extra);
            AckKey key = new AckKey(sessionId, sequence);
            lock (_dataLock)
            {
                for (int attempt = 0; attempt < AckRetries + 1; attempt++)
                {
                    ManualResetEventSlim waiter = new ManualResetEventSlim(false);
                    lock (_ackLock)
                    {
                        _acks[key] = waiter;
                    }
                    SendFrame(frame);
                    bool acked = waiter.Wait(AckTimeoutMs);
                    lock (_ackLock)
                    {
                        _acks.Remove(key);
                    }
                    if (acked)
                    {
                        return;
                    }
                }
            }
            throw new AgentLinkError(
                "ack_timeout",
                string.Format(
                    CultureInfo.InvariantCulture,
                    "ACK timeout for {0}:{1}",
                    sessionId,
                    sequence));
        }

        private IDictionary<string, object> BuildDataFrame(
            string channel, string sessionId, long sequence, byte[] data,
            IDictionary<string, object> extra)
        {
            IDictionary<string, object> frame = new Dictionary<string, object>();
            frame["v"] = WireConstants.ProtocolVersion;
            frame["channel"] = channel;
            frame["type"] = "data";
            frame["link_id"] = _linkId;
            frame["session_id"] = sessionId;
            frame["seq"] = sequence;
            frame["data_b64"] = Wire.DataB64(data);
            if (extra != null)
            {
                foreach (KeyValuePair<string, object> entry in extra)
                {
                    frame[entry.Key] = entry.Value;
                }
            }
            return Wire.ValidateFrame(frame, WireConstants.SlaveToFirmware);
        }

        /// <summary>
        /// Sliding window with per-chunk ACK for a data stream. readChunk is
        /// only called while there is room in the window, so read-ahead is
        /// bounded. Expired blocks are resent in sequence order and abandoned
        /// after AckRetries resends. It does not take the data lock: a file
        /// does not block interactive sends.
        /// </summary>
        public int StreamData(string channel, string sessionId,
                              Func<byte[]> readChunk, int window,
                              Action<int> onAck, Func<bool> stopCheck)
        {
            if (window < 1 || window > WireConstants.DataWindowMax)
            {
                throw new ProtocolError("invalid_argument", "window out of range", false);
            }
            Dictionary<long, StreamBlock> pending = new Dictionary<long, StreamBlock>();
            long nextSeq = 0;
            bool eof = false;
            int ackedBytes = 0;
            try
            {
                while (pending.Count > 0 || !eof)
                {
                    if (_stop.IsSet)
                    {
                        throw new AgentLinkError("link_closed", "link closed");
                    }
                    if (stopCheck != null && stopCheck())
                    {
                        throw new AgentLinkError("cancelled", "transfer cancelled");
                    }
                    while (!eof && pending.Count < window)
                    {
                        byte[] chunk = readChunk();
                        if (chunk == null || chunk.Length == 0)
                        {
                            eof = true;
                            break;
                        }
                        if (chunk.Length > WireConstants.DataChunkBytes)
                        {
                            throw new AgentLinkError("chunk_too_large", "chunk above 512 bytes");
                        }
                        long seq = nextSeq;
                        nextSeq++;
                        ManualResetEventSlim waiter = new ManualResetEventSlim(false);
                        lock (_ackLock)
                        {
                            _acks[new AckKey(sessionId, seq)] = waiter;
                        }
                        StreamBlock block = new StreamBlock();
                        block.Data = chunk;
                        block.Waiter = waiter;
                        block.Attempts = 0;
                        block.DeadlineTicks = NowTicks() + MillisecondsToTicks(AckTimeoutMs);
                        pending[seq] = block;
                        SendFrame(BuildDataFrame(channel, sessionId, seq, chunk, null));
                    }
                    if (pending.Count == 0)
                    {
                        break;
                    }
                    long earliestDeadline = long.MaxValue;
                    lock (_ackLock)
                    {
                        while (true)
                        {
                            if (_stop.IsSet)
                            {
                                break;
                            }
                            bool anySet = false;
                            foreach (StreamBlock block in pending.Values)
                            {
                                if (block.Waiter.IsSet)
                                {
                                    anySet = true;
                                    break;
                                }
                            }
                            if (anySet)
                            {
                                break;
                            }
                            earliestDeadline = long.MaxValue;
                            foreach (StreamBlock block in pending.Values)
                            {
                                if (block.DeadlineTicks < earliestDeadline)
                                {
                                    earliestDeadline = block.DeadlineTicks;
                                }
                            }
                            // Stopwatch ticks -> milliseconds. Monitor.Wait
                            // takes milliseconds; passing ticks stalled the
                            // sender for ~10 million ms whenever a pulse was
                            // missed, which is how a 2 MiB download could lose
                            // its transfer.finished event.
                            long remainingTicks = earliestDeadline - NowTicks();
                            if (remainingTicks <= 0)
                            {
                                break;
                            }
                            int remainingMs = (int)Math.Min(
                                remainingTicks * 1000L / Stopwatch.Frequency + 1L,
                                int.MaxValue);
                            Monitor.Wait(_ackLock, remainingMs);
                        }
                    }
                    long now = NowTicks();
                    List<long> acknowledged = new List<long>();
                    foreach (KeyValuePair<long, StreamBlock> entry in pending)
                    {
                        if (entry.Value.Waiter.IsSet)
                        {
                            acknowledged.Add(entry.Key);
                        }
                    }
                    acknowledged.Sort();
                    foreach (long seq in acknowledged)
                    {
                        StreamBlock block = pending[seq];
                        pending.Remove(seq);
                        lock (_ackLock)
                        {
                            _acks.Remove(new AckKey(sessionId, seq));
                        }
                        ackedBytes += block.Data.Length;
                        if (onAck != null)
                        {
                            onAck(ackedBytes);
                        }
                    }
                    List<long> expired = new List<long>();
                    foreach (KeyValuePair<long, StreamBlock> entry in pending)
                    {
                        if (now >= entry.Value.DeadlineTicks)
                        {
                            expired.Add(entry.Key);
                        }
                    }
                    expired.Sort();
                    foreach (long seq in expired)
                    {
                        StreamBlock block = pending[seq];
                        if (block.Attempts >= AckRetries)
                        {
                            throw new AgentLinkError(
                                "ack_timeout",
                                string.Format(
                                    CultureInfo.InvariantCulture,
                                    "ACK timeout for {0}:{1}",
                                    sessionId,
                                    seq));
                        }
                        block.Attempts++;
                        block.DeadlineTicks = now + MillisecondsToTicks(AckTimeoutMs);
                        SendFrame(BuildDataFrame(channel, sessionId, seq, block.Data, null));
                    }
                }
                return ackedBytes;
            }
            finally
            {
                lock (_ackLock)
                {
                    foreach (long seq in new List<long>(pending.Keys))
                    {
                        _acks.Remove(new AckKey(sessionId, seq));
                    }
                }
            }
        }

        private sealed class StreamBlock
        {
            public byte[] Data;
            public ManualResetEventSlim Waiter;
            public int Attempts;
            public long DeadlineTicks;
        }
    }
}

// File operations with the permissions of the current user. Port of
// implementations/python/file_service.py: identical limits, response
// shapes, error codes, ordinal pagination, literal case-sensitive search,
// fnmatch-style find that never descends into reparse points, and atomic
// write-through replace.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography;
    using System.Text;

    internal static class FileLimits
    {
        public const int MaxReadBytes = 64 * 1024;
        public const int DefaultReadBytes = 32 * 1024;
        public const int MaxWriteBytes = 64 * 1024;
        public const int MaxListEntries = 200;
        public const int MaxSearchResults = 200;
        public const int MaxFindResults = 500;
        public const int MaxSearchRead = 4 * 1024 * 1024;
        public const int MaxLineCharacters = 1000;
    }

    /// <summary>File operations and their dispatch table.</summary>
    internal sealed class FileService
    {
        private static readonly DateTime Epoch =
            new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        private readonly ScreenService _screen = new ScreenService();

        /// <summary>Returns (result, payload); payload is non-null only for read and screen.</summary>
        public sealed class Result
        {
            public IDictionary<string, object> Metadata;
            public byte[] Payload;
        }

        public Result Dispatch(string op, IDictionary<string, object> body)
        {
            try
            {
                return DispatchInner(op, body);
            }
            catch (ProtocolError)
            {
                throw;
            }
            catch (FileNotFoundException error)
            {
                throw new ProtocolError("not_found", error.Message, false);
            }
            catch (DirectoryNotFoundException error)
            {
                throw new ProtocolError("not_found", error.Message, false);
            }
            catch (UnauthorizedAccessException error)
            {
                throw new ProtocolError("permission_denied", error.Message, false);
            }
            catch (System.Security.SecurityException error)
            {
                throw new ProtocolError("permission_denied", error.Message, false);
            }
            catch (IOException error)
            {
                throw new ProtocolError("io_error", error.Message, false);
            }
        }

        private Result DispatchInner(string op, IDictionary<string, object> body)
        {
            if (body == null)
            {
                body = new Dictionary<string, object>();
            }
            if (op == "read")
            {
                Result result = new Result();
                result.Metadata = Read(
                    Str(body, "path"),
                    (int)Json.GetInt64(body, "offset", 0),
                    (int)Json.GetInt64(body, "length", FileLimits.DefaultReadBytes),
                    out result.Payload);
                return result;
            }
            if (op == "write")
            {
                object encodedValue;
                body.TryGetValue("data_b64", out encodedValue);
                string encoded = encodedValue as string;
                if (encoded == null)
                {
                    throw new ProtocolError("invalid_argument", "data_b64 is mandatory", false);
                }
                byte[] data;
                if (!Wire.IsStrictBase64(encoded))
                {
                    throw new ProtocolError(
                        "invalid_base64", "data_b64 is not valid", false);
                }
                try
                {
                    data = Convert.FromBase64String(encoded);
                }
                catch (FormatException)
                {
                    throw new ProtocolError(
                        "invalid_base64", "data_b64 is not valid", false);
                }
                Result result = new Result();
                result.Metadata = Write(Str(body, "path"), data);
                return result;
            }
            if (op == "list")
            {
                Result result = new Result();
                result.Metadata = List(
                    Str(body, "path"),
                    (int)Json.GetInt64(body, "offset", 0),
                    (int)Json.GetInt64(body, "limit", FileLimits.MaxListEntries));
                return result;
            }
            if (op == "delete")
            {
                Result result = new Result();
                result.Metadata = Delete(Str(body, "path"));
                return result;
            }
            if (op == "replace")
            {
                Result result = new Result();
                result.Metadata = Replace(
                    Str(body, "path"), Str(body, "old"), StrOrEmpty(body, "new"));
                return result;
            }
            if (op == "search")
            {
                Result result = new Result();
                result.Metadata = Search(
                    Str(body, "path"),
                    Str(body, "query"),
                    (int)Json.GetInt64(body, "limit", FileLimits.MaxSearchResults));
                return result;
            }
            if (op == "find")
            {
                Result result = new Result();
                result.Metadata = Find(
                    Str(body, "path"),
                    Str(body, "pattern"),
                    (int)Json.GetInt64(body, "limit", FileLimits.MaxFindResults));
                return result;
            }
            if (op == "sysinfo")
            {
                Result result = new Result();
                result.Metadata = Sysinfo();
                return result;
            }
            if (op == "screen")
            {
                return _screen.Capture();
            }
            throw new ProtocolError("unknown_op", "unknown fs operation", false);
        }

        private static string Str(IDictionary<string, object> body, string key)
        {
            object value;
            body.TryGetValue(key, out value);
            return value as string;
        }

        private static string StrOrEmpty(IDictionary<string, object> body, string key)
        {
            object value;
            body.TryGetValue(key, out value);
            string text = value as string;
            return text == null ? string.Empty : text;
        }

        /// <summary>
        /// Expands a leading ~ (or ~name) to the user profile exactly once and
        /// then applies native path semantics. %VAR% and $env: are never
        /// expanded.
        /// </summary>
        private static string PathOf(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new ProtocolError("invalid_path", "path is mandatory", false);
            }
            string expanded = ExpandHome(value);
            return Path.GetFullPath(expanded);
        }

        private static string ExpandHome(string value)
        {
            if (value.Length == 0 || value[0] != '~')
            {
                return value;
            }
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (value.Length == 1)
            {
                return profile;
            }
            if (value[1] == '/' || value[1] == '\\')
            {
                return profile + value.Substring(1);
            }
            int separator = value.IndexOfAny(new char[] { '/', '\\' });
            if (separator < 0)
            {
                return profile;
            }
            return profile + value.Substring(separator);
        }

        private static string Sha256Hex(byte[] data)
        {
            using (SHA256 sha = SHA256.Create())
            {
                return Hex(sha.ComputeHash(data));
            }
        }

        internal static string Hex(byte[] value)
        {
            StringBuilder builder = new StringBuilder(value.Length * 2);
            for (int index = 0; index < value.Length; index++)
            {
                builder.Append(value[index].ToString("x2", CultureInfo.InvariantCulture));
            }
            return builder.ToString();
        }

        private static string RandomSuffix()
        {
            return Guid.NewGuid().ToString("N");
        }

        /// <summary>
        /// Writes to a sibling temporary, flushes it to disk and replaces the
        /// destination with MoveFileExW(REPLACE_EXISTING|WRITE_THROUGH).
        /// Partial content is never visible; only its own temp is removed on
        /// failure.
        /// </summary>
        private void AtomicWrite(string path, byte[] data)
        {
            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            string temporary = Path.Combine(
                directory ?? string.Empty,
                "." + Path.GetFileName(path) + ".titella-" + RandomSuffix());
            try
            {
                using (FileStream stream = new FileStream(
                    temporary, FileMode.CreateNew, FileAccess.Write,
                    FileShare.None, 4096, FileOptions.WriteThrough))
                {
                    stream.Write(data, 0, data.Length);
                    stream.Flush(true);
                }
                if (!NativeMethods.MoveFileExW(
                        temporary, path,
                        Win32Constants.MOVEFILE_REPLACE_EXISTING |
                            Win32Constants.MOVEFILE_WRITE_THROUGH))
                {
                    int error = Marshal.GetLastWin32Error();
                    throw new IOException(
                        string.Format(
                            CultureInfo.InvariantCulture,
                            "MoveFileExW failed with {0}",
                            error));
                }
            }
            catch
            {
                try
                {
                    if (File.Exists(temporary))
                    {
                        File.Delete(temporary);
                    }
                }
                catch (Exception)
                {
                    // The own temp is best-effort cleanup; the original error wins.
                }
                throw;
            }
        }

        public IDictionary<string, object> Read(string path, int offset, int length,
                                                out byte[] payload)
        {
            string target = PathOf(path);
            offset = Math.Max(0, offset);
            length = Math.Min(Math.Max(1, length), FileLimits.MaxReadBytes);
            FileInfo info = new FileInfo(target);
            long size = info.Length;
            byte[] data;
            using (FileStream stream = new FileStream(
                target, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                stream.Seek(offset, SeekOrigin.Begin);
                long remaining = Math.Max(0, size - offset);
                int wanted = (int)Math.Min(length, remaining);
                data = new byte[wanted];
                int read = 0;
                while (read < wanted)
                {
                    int count = stream.Read(data, read, wanted - read);
                    if (count <= 0)
                    {
                        break;
                    }
                    read += count;
                }
                if (read != wanted)
                {
                    byte[] shorter = new byte[read];
                    Array.Copy(data, shorter, read);
                    data = shorter;
                }
            }
            payload = data;
            IDictionary<string, object> metadata = new Dictionary<string, object>();
            metadata["path"] = target;
            metadata["offset"] = offset;
            metadata["next_offset"] = offset + data.Length;
            metadata["size"] = size;
            metadata["eof"] = offset + data.Length >= size;
            metadata["bytes"] = data.Length;
            return metadata;
        }

        public IDictionary<string, object> Write(string path, byte[] data)
        {
            if (data.Length > FileLimits.MaxWriteBytes)
            {
                throw new ProtocolError(
                    "write_too_large", "remote_fs_write accepts up to 64 KiB", false);
            }
            string target = PathOf(path);
            AtomicWrite(target, data);
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "written";
            result["path"] = target;
            result["bytes"] = data.Length;
            result["sha256"] = Sha256Hex(data);
            return result;
        }

        public IDictionary<string, object> List(string path, int offset, int limit)
        {
            string target = PathOf(path);
            offset = Math.Max(0, offset);
            limit = Math.Min(Math.Max(1, limit), FileLimits.MaxListEntries);
            List<string> entries = new List<string>(Directory.GetFileSystemEntries(target));
            entries.Sort(delegate(string left, string right)
            {
                return string.CompareOrdinal(Path.GetFileName(left), Path.GetFileName(right));
            });
            int start = Math.Min(offset, entries.Count);
            int end = Math.Min(start + limit, entries.Count);
            List<object> page = new List<object>();
            for (int index = start; index < end; index++)
            {
                string entry = entries[index];
                FileAttributes attributes = File.GetAttributes(entry);
                string kind;
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                {
                    kind = "symlink";
                }
                else if ((attributes & FileAttributes.Directory) != 0)
                {
                    kind = "directory";
                }
                else if (File.Exists(entry))
                {
                    kind = "file";
                }
                else
                {
                    kind = "other";
                }
                long size = 0;
                double mtime = 0;
                if ((attributes & FileAttributes.Directory) != 0)
                {
                    mtime = Seconds(File.GetLastWriteTimeUtc(entry));
                }
                else
                {
                    FileInfo info = new FileInfo(entry);
                    size = info.Length;
                    mtime = Seconds(info.LastWriteTimeUtc);
                }
                IDictionary<string, object> item = new Dictionary<string, object>();
                item["name"] = Path.GetFileName(entry);
                item["path"] = entry;
                item["type"] = kind;
                item["size"] = size;
                item["mtime"] = mtime;
                page.Add(item);
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["path"] = target;
            result["entries"] = page;
            result["offset"] = offset;
            result["next_offset"] = offset + page.Count;
            result["has_more"] = offset + page.Count < entries.Count;
            result["total"] = entries.Count;
            return result;
        }

        private static double Seconds(DateTime value)
        {
            return (value.ToUniversalTime() - Epoch).TotalSeconds;
        }

        /// <summary>
        /// A directory is never deleted recursively; a reparse-point directory
        /// (junction) is unlinked with RemoveDirectoryW, which removes the link
        /// without touching its target.
        /// </summary>
        public IDictionary<string, object> Delete(string path)
        {
            string target = PathOf(path);
            uint attributes = NativeMethods.GetFileAttributesW(target);
            if (attributes == Win32Constants.INVALID_FILE_ATTRIBUTES)
            {
                throw new ProtocolError(
                    "not_found",
                    "the path does not exist",
                    false);
            }
            bool directory = (attributes & Win32Constants.FILE_ATTRIBUTE_DIRECTORY) != 0;
            bool reparse = (attributes & Win32Constants.FILE_ATTRIBUTE_REPARSE_POINT) != 0;
            if (directory && !reparse)
            {
                throw new ProtocolError(
                    "directory_delete_denied",
                    "delete is not recursive and does not remove directories",
                    false);
            }
            bool removed;
            if (directory && reparse)
            {
                removed = NativeMethods.RemoveDirectoryW(target);
            }
            else
            {
                removed = NativeMethods.DeleteFileW(target);
            }
            if (!removed)
            {
                int error = Marshal.GetLastWin32Error();
                if (error == 2 || error == 3)
                {
                    throw new ProtocolError("not_found", "the path does not exist", false);
                }
                if (error == 5)
                {
                    throw new ProtocolError("permission_denied", "access denied", false);
                }
                throw new IOException(
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "delete failed with {0}",
                        error));
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "deleted";
            result["path"] = target;
            return result;
        }

        private static int CountOccurrences(byte[] data, byte[] needle)
        {
            if (needle.Length == 0)
            {
                return 0;
            }
            int count = 0;
            int index = 0;
            while (index <= data.Length - needle.Length)
            {
                bool match = true;
                for (int probe = 0; probe < needle.Length; probe++)
                {
                    if (data[index + probe] != needle[probe])
                    {
                        match = false;
                        break;
                    }
                }
                if (match)
                {
                    count++;
                    index += needle.Length;
                }
                else
                {
                    index++;
                }
            }
            return count;
        }

        public IDictionary<string, object> Replace(string path, string oldValue, string newValue)
        {
            string target = PathOf(path);
            if (string.IsNullOrEmpty(oldValue))
            {
                throw new ProtocolError("invalid_argument", "old must not be empty", false);
            }
            byte[] data = File.ReadAllBytes(target);
            if (data.Length > FileLimits.MaxSearchRead)
            {
                throw new ProtocolError(
                    "file_too_large", "replace accepts files of up to 4 MiB", false);
            }
            byte[] oldBytes = Encoding.UTF8.GetBytes(oldValue);
            byte[] newBytes = Encoding.UTF8.GetBytes(newValue ?? string.Empty);
            int count = CountOccurrences(data, oldBytes);
            if (count != 1)
            {
                throw new ProtocolError(
                    "replace_count",
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "replace requires exactly one occurrence; found {0}",
                        count),
                    false);
            }
            int position = IndexOf(data, oldBytes);
            byte[] updated = new byte[data.Length - oldBytes.Length + newBytes.Length];
            Array.Copy(data, 0, updated, 0, position);
            Array.Copy(newBytes, 0, updated, position, newBytes.Length);
            Array.Copy(data, position + oldBytes.Length, updated,
                       position + newBytes.Length,
                       data.Length - position - oldBytes.Length);
            AtomicWrite(target, updated);
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "replaced";
            result["path"] = target;
            result["bytes"] = updated.Length;
            return result;
        }

        private static int IndexOf(byte[] data, byte[] needle)
        {
            for (int index = 0; index <= data.Length - needle.Length; index++)
            {
                bool match = true;
                for (int probe = 0; probe < needle.Length; probe++)
                {
                    if (data[index + probe] != needle[probe])
                    {
                        match = false;
                        break;
                    }
                }
                if (match)
                {
                    return index;
                }
            }
            return -1;
        }

        public IDictionary<string, object> Search(string path, string query, int limit)
        {
            string target = PathOf(path);
            if (string.IsNullOrEmpty(query))
            {
                throw new ProtocolError("invalid_argument", "query is mandatory", false);
            }
            limit = Math.Min(Math.Max(1, limit), FileLimits.MaxSearchResults);
            byte[] data;
            using (FileStream stream = new FileStream(
                target, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                int wanted = Math.Min(FileLimits.MaxSearchRead + 1, (int)Math.Min(
                    int.MaxValue, stream.Length + 1));
                data = new byte[wanted];
                int read = 0;
                while (read < wanted)
                {
                    int count = stream.Read(data, read, wanted - read);
                    if (count <= 0)
                    {
                        break;
                    }
                    read += count;
                }
                if (read != wanted)
                {
                    byte[] shorter = new byte[read];
                    Array.Copy(data, shorter, read);
                    data = shorter;
                }
            }
            bool truncated = data.Length > FileLimits.MaxSearchRead;
            if (truncated)
            {
                byte[] shorter = new byte[FileLimits.MaxSearchRead];
                Array.Copy(data, shorter, shorter.Length);
                data = shorter;
            }
            string text = new UTF8Encoding(false, false).GetString(data);
            List<object> results = new List<object>();
            IList<string> lines = SplitLines(text);
            for (int index = 0; index < lines.Count; index++)
            {
                string line = lines[index];
                if (line.IndexOf(query, StringComparison.Ordinal) >= 0)
                {
                    string snippet = line.Length <= FileLimits.MaxLineCharacters
                        ? line
                        : SafePrefix(line, FileLimits.MaxLineCharacters);
                    IDictionary<string, object> item = new Dictionary<string, object>();
                    item["line"] = index + 1;
                    item["text"] = snippet;
                    results.Add(item);
                    if (results.Count >= limit)
                    {
                        break;
                    }
                }
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["path"] = target;
            result["query"] = query;
            result["results"] = results;
            result["truncated"] = truncated || results.Count >= limit;
            return result;
        }

        /// <summary>Truncates to at most count UTF-16 units and drops a lone
        /// trailing high surrogate, which JSON cannot represent.</summary>
        private static string SafePrefix(string line, int count)
        {
            if (line.Length <= count)
            {
                return line;
            }
            int length = count;
            if (char.IsHighSurrogate(line[length - 1]))
            {
                length--;
            }
            return line.Substring(0, length);
        }

        /// <summary>
        /// Python str.splitlines() separators; no trailing empty element. A
        /// terminal separator closes the last line without creating one.
        /// </summary>
        private static IList<string> SplitLines(string text)
        {
            List<string> lines = new List<string>();
            StringBuilder current = new StringBuilder();
            int index = 0;
            while (index < text.Length)
            {
                char c = text[index];
                if (c == '\r')
                {
                    if (index + 1 < text.Length && text[index + 1] == '\n')
                    {
                        index += 2;
                    }
                    else
                    {
                        index++;
                    }
                    lines.Add(current.ToString());
                    current.Length = 0;
                    continue;
                }
                if (c == '\n' || c == '\v' || c == '\f' || c == '\u001c' ||
                    c == '\u001d' || c == '\u001e' || c == '\u0085' ||
                    c == '\u2028' || c == '\u2029')
                {
                    index++;
                    lines.Add(current.ToString());
                    current.Length = 0;
                    continue;
                }
                current.Append(c);
                index++;
            }
            if (current.Length > 0)
            {
                lines.Add(current.ToString());
            }
            return lines;
        }

        public IDictionary<string, object> Find(string path, string pattern, int limit)
        {
            string target = PathOf(path);
            if (string.IsNullOrEmpty(pattern))
            {
                throw new ProtocolError("invalid_argument", "pattern is mandatory", false);
            }
            limit = Math.Min(Math.Max(1, limit), FileLimits.MaxFindResults);
            List<object> results = new List<object>();
            bool truncated = false;
            FileAttributes attributes = File.GetAttributes(target);
            bool isDirectory = (attributes & FileAttributes.Directory) != 0;
            bool isReparse = (attributes & FileAttributes.ReparsePoint) != 0;
            if (!isDirectory || isReparse)
            {
                if (GlobMatch(Path.GetFileName(target), pattern))
                {
                    results.Add(target);
                }
            }
            else
            {
                Walk(target, pattern, limit, results, ref truncated);
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["path"] = target;
            result["pattern"] = pattern;
            result["results"] = results;
            result["truncated"] = truncated;
            return result;
        }

        /// <summary>
        /// Top-down walk reproducing os.walk(followlinks=False): at each level
        /// directories are sorted first and matched after the files, then the
        /// sorted subdirectories are visited. Reparse points are listed but
        /// never descended into.
        /// </summary>
        private static void Walk(string root, string pattern, int limit,
                                 List<object> results, ref bool truncated)
        {
            List<string> directories = new List<string>();
            List<string> files = new List<string>();
            foreach (string entry in Directory.GetFileSystemEntries(root))
            {
                FileAttributes attributes = File.GetAttributes(entry);
                if ((attributes & FileAttributes.Directory) != 0 &&
                    (attributes & FileAttributes.ReparsePoint) == 0)
                {
                    directories.Add(entry);
                }
                else
                {
                    files.Add(entry);
                }
            }
            directories.Sort(delegate(string left, string right)
            {
                return string.CompareOrdinal(Path.GetFileName(left), Path.GetFileName(right));
            });
            files.Sort(delegate(string left, string right)
            {
                return string.CompareOrdinal(Path.GetFileName(left), Path.GetFileName(right));
            });
            List<string> names = new List<string>(directories.Count + files.Count);
            names.AddRange(directories);
            names.AddRange(files);
            foreach (string entry in names)
            {
                if (GlobMatch(Path.GetFileName(entry), pattern))
                {
                    results.Add(entry);
                    if (results.Count >= limit)
                    {
                        truncated = true;
                        return;
                    }
                }
            }
            foreach (string directory in directories)
            {
                Walk(directory, pattern, limit, results, ref truncated);
                if (truncated)
                {
                    return;
                }
            }
        }

        /// <summary>
        /// fnmatch-style matching over a bare name: * any sequence, ? one
        /// character, [seq]/[!seq] classes, no escape character and no
        /// path-separator special-casing. Matching is ordinal (case
        /// sensitive), which is what the macOS/Linux Python slave exposes.
        /// </summary>
        internal static bool GlobMatch(string name, string pattern)
        {
            return GlobAt(name, 0, pattern, 0);
        }

        private static bool GlobAt(string name, int n, string pattern, int p)
        {
            while (p < pattern.Length)
            {
                char token = pattern[p];
                if (token == '*')
                {
                    while (p + 1 < pattern.Length && pattern[p + 1] == '*')
                    {
                        p++;
                    }
                    if (p + 1 == pattern.Length)
                    {
                        return true;
                    }
                    for (int skip = n; skip <= name.Length; skip++)
                    {
                        if (GlobAt(name, skip, pattern, p + 1))
                        {
                            return true;
                        }
                    }
                    return false;
                }
                if (n >= name.Length)
                {
                    return false;
                }
                if (token == '?')
                {
                    n++;
                    p++;
                    continue;
                }
                if (token == '[')
                {
                    int close = p + 1;
                    bool negate = false;
                    if (close < pattern.Length && pattern[close] == '!')
                    {
                        negate = true;
                        close++;
                    }
                    if (close < pattern.Length && pattern[close] == ']')
                    {
                        close++;
                    }
                    while (close < pattern.Length && pattern[close] != ']')
                    {
                        close++;
                    }
                    if (close >= pattern.Length)
                    {
                        // Unclosed class: the bracket is literal.
                        if (name[n] != '[')
                        {
                            return false;
                        }
                        n++;
                        p++;
                        continue;
                    }
                    bool matched = ClassMatch(name[n], pattern, p + 1, close, negate);
                    if (!matched)
                    {
                        return false;
                    }
                    n++;
                    p = close + 1;
                    continue;
                }
                if (name[n] != token)
                {
                    return false;
                }
                n++;
                p++;
            }
            return n == name.Length;
        }

        private static bool ClassMatch(char value, string pattern, int start, int end, bool negate)
        {
            int index = start;
            if (index < end && pattern[index] == '!')
            {
                index++;
            }
            bool matched = false;
            while (index < end)
            {
                char low = pattern[index];
                if (index + 2 < end && pattern[index + 1] == '-' && pattern[index + 2] != ']')
                {
                    char high = pattern[index + 2];
                    if (value >= low && value <= high)
                    {
                        matched = true;
                    }
                    index += 3;
                    continue;
                }
                if (value == low)
                {
                    matched = true;
                }
                index++;
            }
            return negate ? !matched : matched;
        }

        public IDictionary<string, object> Sysinfo()
        {
            string version = null;
            try
            {
                version = Agent.NdpVersion();
            }
            catch (Exception)
            {
                version = null;
            }
            IDictionary<string, object> runtime = new Dictionary<string, object>();
            runtime["name"] = "dotnet-framework";
            runtime["version"] = version;
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["system"] = "Windows";
            result["release"] = Environment.OSVersion.Version.ToString();
            result["version"] = Environment.OSVersion.VersionString;
            string machine = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE");
            result["machine"] = machine ?? "unknown";
            result["hostname"] = Environment.MachineName;
            result["python"] = null;
            result["uid"] = null;
            result["gid"] = null;
            result["home"] = Environment.GetFolderPath(
                Environment.SpecialFolder.UserProfile);
            result["runtime"] = runtime;
            return result;
        }
    }
}

// HID data transport: .NET endpoint of the firmware's report 0x10 flow
// plus the Win32 side that finds and opens the vendor collection.
// Report 0x10 (64 bytes with ID, little-endian): [0]=0x10 [1]=version 1
// [2]=class OPEN=1 OPEN_ACK=2 DATA=3 ACK=4 CLOSE=5 [3..6]=epoch uint32
// [7..8]=sequence uint16 per direction [9]=length 0..54 [10..63]=payload.
// State machine mirrors the portable C++ endpoint: one in-flight DATA per
// direction, exact-duplicate re-acknowledgement, payload admission before
// the ACK, controls that overtake data, and 250 ms x3 retries before an
// explicit disconnect. Self-contained (own P/Invokes, C# 5, System and
// System.Core); it never touches the 0x11 loader mailbox.

namespace Titella.Slave
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;

    internal static class HidWireConstants
    {
        public const byte ReportId = 0x10;
        public const int ReportBytes = 64;
        public const byte ProtocolVersion = 1;
        public const int QueueBytes = 8192;
        public const int DataMax = 54;
        public const uint RetryTimeoutMs = 250u;
        public const int MaxRetries = 3;

        public const int PollMs = 5;
        public const int ReadIdleMs = 100;
        public const int OpenBudgetMs = 1000;
        public const int DisposeJoinMs = 1000;
        public const uint WriteTimeoutMs = 250u;
        // Bounded wait for a cancellation to be confirmed by the driver; never an unbounded completion wait.
        public const uint CancelSettleMs = 250u;

        public const ushort VendorId = 0x17EF;
        public const ushort ProductId = 0xA38F;
        public const ushort UsagePageVendor = 0xFF00;
        public const ushort UsageData = 0x01;
        public const int CollectionReportBytes = 64;

        public const string BindingPrefix = "HID:";
        public const int SerialChars = 12;
    }

    internal enum HidFrameClass : byte
    {
        Open = 1,
        OpenAck = 2,
        Data = 3,
        Ack = 4,
        Close = 5,
    }

    internal enum HidLinkState : byte
    {
        Disconnected = 0,
        Opening = 1,
        Connected = 2,
    }

    internal enum HidStaged : byte
    {
        None = 0,
        Open = 1,
        OpenAck = 2,
        Ack = 3,
        Close = 4,
        DataNew = 5,
        DataRetry = 6,
    }

    internal static class HidErrors
    {
        public static IOException Coded(string code, string message)
        {
            IOException error = new IOException(message);
            error.Data["titella_code"] = code;
            return error;
        }

        public static string CodeOf(Exception error)
        {
            if (error == null || error.Data == null)
            {
                return null;
            }
            if (!error.Data.Contains("titella_code"))
            {
                return null;
            }
            return error.Data["titella_code"] as string;
        }
    }

    internal interface IHidReportIo : IDisposable
    {
        int Read(byte[] report, int timeoutMs);
        void Write(byte[] report);
    }

    public sealed class HidByteStream : Stream
    {
        private static int _epochCounter;

        private readonly object _gate;
        private readonly Func<long> _clock;
        private readonly IHidReportIo _io;
        private readonly Thread _worker;
        private readonly byte[] _inReport;
        private readonly byte[] _outReport;

        private readonly byte[] _txQueue;
        private readonly byte[] _rxQueue;
        private int _txHead;
        private int _txLength;
        private int _rxHead;
        private int _rxLength;

        private HidLinkState _state;
        private uint _epoch;
        private ushort _txSequence;
        private ushort _rxSequence;

        private bool _pendingValid;
        private ushort _pendingSequence;
        private int _pendingLength;
        private int _pendingAttempt;
        private uint _pendingDeadline;
        private readonly byte[] _flightData;
        private readonly byte[] _scratchData;

        private bool _ackPending;
        private ushort _ackSequence;
        private bool _openAckPending;
        private bool _closePending;
        private uint _closeEpoch;

        private bool _openSent;
        private int _openAttempt;
        private uint _openDeadline;

        private bool _lastRxValid;
        private ushort _lastRxSequence;
        private int _lastRxLength;
        private readonly byte[] _lastRxData;

        private HidStaged _staged;
        private int _stagedTake;

        // Cumulative byte counters: Write waits until its own watermark has been acknowledged, so a queue drain...
        private long _txEnqueued;
        private long _txAcknowledged;
        private long _generation;

        private bool _cancelled;
        private bool _disposeRequested;
        private volatile bool _disposedFlag;
        private string _failureCode;
        private string _failureMessage;

        internal HidByteStream(IHidReportIo io, Func<long> clockMilliseconds, uint epoch)
        {
            if (io == null)
            {
                throw new ArgumentNullException("io");
            }
            if (epoch == 0)
            {
                throw new ArgumentException("a non-zero epoch is required", "epoch");
            }
            _gate = new object();
            _io = io;
            _clock = clockMilliseconds ?? new Func<long>(SystemClockMilliseconds);
            _inReport = new byte[HidWireConstants.ReportBytes];
            _outReport = new byte[HidWireConstants.ReportBytes];
            _txQueue = new byte[HidWireConstants.QueueBytes];
            _rxQueue = new byte[HidWireConstants.QueueBytes];
            _flightData = new byte[HidWireConstants.DataMax];
            _scratchData = new byte[HidWireConstants.DataMax];
            _lastRxData = new byte[HidWireConstants.DataMax];
            _epoch = epoch;
            _state = HidLinkState.Opening;
            _openSent = false;
            _openAttempt = 0;
            _openDeadline = 0u;
            _worker = new Thread(WorkerLoop);
            _worker.IsBackground = true;
            _worker.Name = "titella-hid";
            _worker.Start();
        }

        public static HidByteStream Open(string binding)
        {
            string serial = ParseBinding(binding);
            Win32HidReportIo io = new Win32HidReportIo(serial);
            HidByteStream stream = new HidByteStream(io, SystemClockMilliseconds, NextEpoch());
            stream.WaitForOpen(HidWireConstants.OpenBudgetMs);
            return stream;
        }

        public static bool IsHidBinding(string value)
        {
            if (value == null || value.Length != HidWireConstants.BindingPrefix.Length + HidWireConstants.SerialChars)
            {
                return false;
            }
            if (value[0] != 'H' || value[1] != 'I' || value[2] != 'D' || value[3] != ':')
            {
                return false;
            }
            for (int index = HidWireConstants.BindingPrefix.Length; index < value.Length; index++)
            {
                char current = value[index];
                bool hexadecimal = (current >= '0' && current <= '9')
                    || (current >= 'A' && current <= 'F');
                if (!hexadecimal)
                {
                    return false;
                }
            }
            return true;
        }

        private static string ParseBinding(string binding)
        {
            if (!IsHidBinding(binding))
            {
                throw HidErrors.Coded(
                    "invalid_argument",
                    "the HID binding must be HID:<12 uppercase hexadecimal characters>");
            }
            return binding.Substring(HidWireConstants.BindingPrefix.Length);
        }

        private static long SystemClockMilliseconds()
        {
            return (long)(Stopwatch.GetTimestamp() * 1000.0 / Stopwatch.Frequency);
        }

        private static uint NextEpoch()
        {
            int counter = Interlocked.Increment(ref _epochCounter);
            uint mixed = unchecked((uint)counter * 2654435761u);
            uint time = unchecked((uint)(Stopwatch.GetTimestamp() & 0xFFFFFFFFL));
            uint epoch = mixed ^ time;
            if (epoch == 0)
            {
                epoch = 0xA5A50001u;
            }
            return epoch;
        }

        private void WaitForOpen(int budgetMs)
        {
            long started = Stopwatch.GetTimestamp();
            IOException failure = null;
            lock (_gate)
            {
                while (true)
                {
                    if (_state == HidLinkState.Connected)
                    {
                        return;
                    }
                    if (_failureCode != null)
                    {
                        failure = BuildFailureLocked();
                        break;
                    }
                    long elapsed = (Stopwatch.GetTimestamp() - started) * 1000L / Stopwatch.Frequency;
                    long remaining = budgetMs - elapsed;
                    if (remaining <= 0)
                    {
                        break;
                    }
                    Monitor.Wait(_gate, (int)Math.Min(remaining, 50L));
                }
            }
            long used = (Stopwatch.GetTimestamp() - started) * 1000L / Stopwatch.Frequency;
            long left = budgetMs - used;
            Shutdown((int)Math.Max(0L, left));
            if (failure != null)
            {
                throw failure;
            }
            throw HidErrors.Coded(
                "hid_open_timeout",
                "the HID OPEN handshake did not complete within 1000 ms");
        }

        private void Shutdown(int joinBudgetMs)
        {
            bool first = false;
            lock (_gate)
            {
                if (!_disposedFlag)
                {
                    _disposedFlag = true;
                    first = true;
                }
                if (_state != HidLinkState.Connected)
                {
                    _cancelled = true;
                }
                Monitor.PulseAll(_gate);
            }
            if (first && joinBudgetMs > 0)
            {
                Thread worker = _worker;
                if (worker != null && worker != Thread.CurrentThread)
                {
                    worker.Join(joinBudgetMs);
                }
            }
        }

        public override bool CanRead
        {
            get { return !_disposedFlag; }
        }

        public override bool CanWrite
        {
            get { return !_disposedFlag; }
        }

        public override bool CanSeek
        {
            get { return false; }
        }

        public override long Length
        {
            get { throw new NotSupportedException("the HID stream has no length"); }
        }

        public override long Position
        {
            get { throw new NotSupportedException("the HID stream is not seekable"); }
            set { throw new NotSupportedException("the HID stream is not seekable"); }
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException("the HID stream is not seekable");
        }

        public override void SetLength(long value)
        {
            throw new NotSupportedException("the HID stream has no length");
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }
            if (offset < 0 || count < 0 || offset + count > buffer.Length)
            {
                throw new ArgumentOutOfRangeException("count");
            }
            if (count == 0)
            {
                return 0;
            }
            long started = Stopwatch.GetTimestamp();
            lock (_gate)
            {
                while (true)
                {
                    ThrowIfUnavailableLocked();
                    if (_rxLength > 0)
                    {
                        int take = Math.Min(count, _rxLength);
                        PopRing(_rxQueue, ref _rxHead, ref _rxLength, buffer, offset, take);
                        return take;
                    }
                    long elapsed = (Stopwatch.GetTimestamp() - started) * 1000L / Stopwatch.Frequency;
                    long remaining = HidWireConstants.ReadIdleMs - elapsed;
                    if (remaining <= 0)
                    {
                        return 0;
                    }
                    Monitor.Wait(_gate, (int)Math.Min(remaining, HidWireConstants.ReadIdleMs));
                }
            }
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }
            if (offset < 0 || count < 0 || offset + count > buffer.Length)
            {
                throw new ArgumentOutOfRangeException("count");
            }
            if (count == 0)
            {
                return;
            }
            lock (_gate)
            {
                ThrowIfUnavailableLocked();
                long generation = _generation;
                long watermark = _txEnqueued + count;
                int written = 0;
                while (written < count)
                {
                    ThrowIfUnavailableLocked();
                    ThrowIfGenerationLocked(generation);
                    int free = HidWireConstants.QueueBytes - _txLength;
                    if (free > 0)
                    {
                        int take = Math.Min(free, count - written);
                        PushRing(_txQueue, ref _txHead, ref _txLength, buffer, offset + written, take);
                        _txEnqueued += take;
                        written += take;
                        Monitor.PulseAll(_gate);
                    }
                    if (written < count)
                    {
                        Monitor.Wait(_gate, 100);
                    }
                }
                while (true)
                {
                    ThrowIfUnavailableLocked();
                    ThrowIfGenerationLocked(generation);
                    if (_txAcknowledged >= watermark)
                    {
                        return;
                    }
                    Monitor.Wait(_gate, 100);
                }
            }
        }

        public override void Flush()
        {
            lock (_gate)
            {
                ThrowIfUnavailableLocked();
                long generation = _generation;
                while (_txLength > 0 || _pendingValid || _ackPending || _openAckPending
                    || _closePending || _state == HidLinkState.Opening)
                {
                    ThrowIfUnavailableLocked();
                    ThrowIfGenerationLocked(generation);
                    Monitor.Wait(_gate, 100);
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            bool first = false;
            lock (_gate)
            {
                if (!_disposedFlag)
                {
                    _disposedFlag = true;
                    first = true;
                }
                if (_state == HidLinkState.Connected)
                {
                    _disposeRequested = true;
                    _closeEpoch = _epoch;
                    ResetFlowLockedKeepClose();
                }
                else
                {
                    _cancelled = true;
                }
                Monitor.PulseAll(_gate);
            }
            if (disposing && first)
            {
                Thread worker = _worker;
                if (worker != null && worker != Thread.CurrentThread)
                {
                    worker.Join(HidWireConstants.DisposeJoinMs);
                }
            }
            base.Dispose(disposing);
        }

        private void ResetFlowLockedKeepClose()
        {
            uint closingEpoch = _closeEpoch;
            ResetFlowLocked();
            _closeEpoch = closingEpoch;
            _closePending = true;
            _state = HidLinkState.Disconnected;
            _epoch = 0u;
        }

        private uint Now()
        {
            return unchecked((uint)_clock());
        }

        private void WorkerLoop()
        {
            try
            {
                while (true)
                {
                    bool stop;
                    bool finishing;
                    lock (_gate)
                    {
                        stop = _cancelled || _failureCode != null;
                        finishing = _disposeRequested && !_closePending;
                    }
                    if (stop || finishing)
                    {
                        break;
                    }
                    PumpOutbound();
                    lock (_gate)
                    {
                        if (_cancelled || _failureCode != null
                            || (_disposeRequested && !_closePending))
                        {
                            break;
                        }
                    }
                    int read;
                    try
                    {
                        read = _io.Read(_inReport, HidWireConstants.PollMs);
                    }
                    catch (IOException error)
                    {
                        FailLocked(error);
                        break;
                    }
                    if (read < 0)
                    {
                        break;
                    }
                    if (read > 0)
                    {
                        if (read != HidWireConstants.ReportBytes)
                        {
                            // A short or oversized report must never reach the parser: the reused buffer can still carry a valid he...
                            Array.Clear(_inReport, 0, _inReport.Length);
                            continue;
                        }
                        lock (_gate)
                        {
                            HandleInboundLocked(_inReport, Now());
                        }
                        continue;
                    }
                }
            }
            finally
            {
                FinishWorker();
            }
        }

        private void PumpOutbound()
        {
            while (true)
            {
                bool staged;
                lock (_gate)
                {
                    if (_cancelled || _failureCode != null)
                    {
                        return;
                    }
                    staged = FillNextReportLocked(Now());
                }
                if (!staged)
                {
                    return;
                }
                try
                {
                    _io.Write(_outReport);
                }
                catch (IOException error)
                {
                    FailLocked(error);
                    return;
                }
                lock (_gate)
                {
                    ConfirmSendLocked(Now());
                    Monitor.PulseAll(_gate);
                }
            }
        }

        private bool FillNextReportLocked(uint now)
        {
            _staged = HidStaged.None;
            if (_closePending)
            {
                BuildReportLocked(HidFrameClass.Close, _closeEpoch, 0, null, 0);
                _staged = HidStaged.Close;
                return true;
            }
            if (_state == HidLinkState.Opening)
            {
                if (!_openSent)
                {
                    BuildReportLocked(HidFrameClass.Open, _epoch, 0, null, 0);
                    _staged = HidStaged.Open;
                    return true;
                }
                if (unchecked((int)(now - _openDeadline)) < 0)
                {
                    return false;
                }
                if (_openAttempt > HidWireConstants.MaxRetries)
                {
                    FailLocked(HidErrors.Coded(
                        "hid_retry_exhausted",
                        "the peer never answered the HID OPEN"));
                    return false;
                }
                BuildReportLocked(HidFrameClass.Open, _epoch, 0, null, 0);
                _staged = HidStaged.Open;
                return true;
            }
            if (_state != HidLinkState.Connected)
            {
                return false;
            }
            if (_openAckPending)
            {
                BuildReportLocked(HidFrameClass.OpenAck, _epoch, 0, null, 0);
                _staged = HidStaged.OpenAck;
                return true;
            }
            if (_ackPending)
            {
                BuildReportLocked(HidFrameClass.Ack, _epoch, _ackSequence, null, 0);
                _staged = HidStaged.Ack;
                return true;
            }
            if (_pendingValid)
            {
                if (unchecked((int)(now - _pendingDeadline)) < 0)
                {
                    return false;
                }
                if (_pendingAttempt > HidWireConstants.MaxRetries)
                {
                    FailLocked(HidErrors.Coded(
                        "hid_retry_exhausted",
                        "the peer never acknowledged the in-flight HID DATA"));
                    return false;
                }
                BuildReportLocked(
                    HidFrameClass.Data, _epoch, _pendingSequence, _flightData, _pendingLength);
                _staged = HidStaged.DataRetry;
                return true;
            }
            if (_txLength > 0)
            {
                int take = Math.Min(_txLength, HidWireConstants.DataMax);
                PeekRing(_txQueue, _txHead, _txLength, _scratchData, take);
                BuildReportLocked(HidFrameClass.Data, _epoch, _txSequence, _scratchData, take);
                _stagedTake = take;
                _staged = HidStaged.DataNew;
                return true;
            }
            return false;
        }

        private void ConfirmSendLocked(uint now)
        {
            switch (_staged)
            {
                case HidStaged.Open:
                    _openSent = true;
                    _openAttempt++;
                    _openDeadline = unchecked(now + HidWireConstants.RetryTimeoutMs);
                    break;
                case HidStaged.OpenAck:
                    _openAckPending = false;
                    break;
                case HidStaged.Ack:
                    _ackPending = false;
                    break;
                case HidStaged.Close:
                    _closePending = false;
                    break;
                case HidStaged.DataNew:
                    StageNewDataLocked(_stagedTake);
                    _pendingDeadline = unchecked(now + HidWireConstants.RetryTimeoutMs);
                    break;
                case HidStaged.DataRetry:
                    _pendingAttempt++;
                    _pendingDeadline = unchecked(now + HidWireConstants.RetryTimeoutMs);
                    break;
                case HidStaged.None:
                    break;
            }
            _staged = HidStaged.None;
        }

        private void StageNewDataLocked(int take)
        {
            PopRing(_txQueue, ref _txHead, ref _txLength, _flightData, 0, take);
            _pendingLength = take;
            _pendingSequence = _txSequence;
            _txSequence = unchecked((ushort)(_txSequence + 1));
            _pendingValid = true;
            _pendingAttempt = 1;
        }

        private void HandleInboundLocked(byte[] report, uint now)
        {
            HidFrameClass frame;
            uint epoch;
            ushort sequence;
            int length;
            if (!ParseReportLocked(report, out frame, out epoch, out sequence, out length))
            {
                return;
            }
            switch (frame)
            {
                case HidFrameClass.Open:
                    if (_state == HidLinkState.Connected && epoch == _epoch)
                    {
                        _openAckPending = true;
                        break;
                    }
                    ResetFlowLocked();
                    _epoch = epoch;
                    _state = HidLinkState.Connected;
                    _openAckPending = true;
                    break;
                case HidFrameClass.OpenAck:
                    if (_state == HidLinkState.Opening && epoch == _epoch)
                    {
                        _state = HidLinkState.Connected;
                        _openSent = false;
                        _openAttempt = 0;
                        _openDeadline = 0u;
                    }
                    break;
                case HidFrameClass.Data:
                    if (_state != HidLinkState.Connected || epoch != _epoch)
                    {
                        break;
                    }
                    if (sequence == _rxSequence)
                    {
                        if (length > HidWireConstants.QueueBytes - _rxLength)
                        {
                            // Backpressure: never copy partially and never acknowledge bytes that were not admitted; the retransmis...
                            break;
                        }
                        PushRing(_rxQueue, ref _rxHead, ref _rxLength, report, 10, length);
                        _lastRxValid = true;
                        _lastRxSequence = sequence;
                        _lastRxLength = length;
                        Array.Copy(report, 10, _lastRxData, 0, length);
                        _rxSequence = unchecked((ushort)(sequence + 1));
                        _ackPending = true;
                        _ackSequence = sequence;
                        break;
                    }
                    if (_lastRxValid && sequence == _lastRxSequence && length == _lastRxLength
                        && SamePayload(report, 10, _lastRxData, length))
                    {
                        _ackPending = true;
                        _ackSequence = sequence;
                    }
                    break;
                case HidFrameClass.Ack:
                    if (_state == HidLinkState.Connected && epoch == _epoch
                        && _pendingValid && sequence == _pendingSequence)
                    {
                        _pendingValid = false;
                        _txAcknowledged += _pendingLength;
                        _pendingLength = 0;
                    }
                    break;
                case HidFrameClass.Close:
                    if (_state != HidLinkState.Disconnected && epoch == _epoch)
                    {
                        FailLocked(HidErrors.Coded(
                            "hid_peer_closed",
                            "the peer closed the HID session"));
                    }
                    break;
            }
            Monitor.PulseAll(_gate);
        }

        private static bool ParseReportLocked(
            byte[] report, out HidFrameClass frame, out uint epoch, out ushort sequence, out int length)
        {
            frame = HidFrameClass.Open;
            epoch = 0u;
            sequence = 0;
            length = 0;
            if (report == null || report.Length < HidWireConstants.ReportBytes)
            {
                return false;
            }
            if (report[0] != HidWireConstants.ReportId)
            {
                return false;
            }
            if (report[1] != HidWireConstants.ProtocolVersion)
            {
                return false;
            }
            epoch = ReadU32(report, 3);
            if (epoch == 0u)
            {
                return false;
            }
            byte klass = report[2];
            if (klass < (byte)HidFrameClass.Open || klass > (byte)HidFrameClass.Close)
            {
                return false;
            }
            int payload = report[9];
            if (klass == (byte)HidFrameClass.Data)
            {
                if (payload == 0 || payload > HidWireConstants.DataMax)
                {
                    return false;
                }
            }
            else if (payload != 0)
            {
                return false;
            }
            frame = (HidFrameClass)klass;
            sequence = ReadU16(report, 7);
            length = payload;
            return true;
        }

        private void BuildReportLocked(
            HidFrameClass frame, uint epoch, ushort sequence, byte[] data, int length)
        {
            Array.Clear(_outReport, 0, HidWireConstants.ReportBytes);
            _outReport[0] = HidWireConstants.ReportId;
            _outReport[1] = HidWireConstants.ProtocolVersion;
            _outReport[2] = (byte)frame;
            WriteU32(_outReport, 3, epoch);
            WriteU16(_outReport, 7, sequence);
            if (data != null && length > 0)
            {
                int take = Math.Min(length, HidWireConstants.DataMax);
                _outReport[9] = (byte)take;
                Array.Copy(data, 0, _outReport, 10, take);
            }
        }

        private void ResetFlowLocked()
        {
            _txHead = 0;
            _txLength = 0;
            _rxHead = 0;
            _rxLength = 0;
            _txSequence = 0;
            _rxSequence = 0;
            _pendingValid = false;
            _pendingLength = 0;
            _pendingAttempt = 0;
            _pendingDeadline = 0u;
            _ackPending = false;
            _ackSequence = 0;
            _openAckPending = false;
            _closePending = false;
            _closeEpoch = 0u;
            _openSent = false;
            _openAttempt = 0;
            _openDeadline = 0u;
            _lastRxValid = false;
            _lastRxLength = 0;
            _staged = HidStaged.None;
            _txAcknowledged = _txEnqueued;
            _generation++;
        }

        private void FailLocked(IOException error)
        {
            lock (_gate)
            {
                if (_failureCode == null)
                {
                    string code = HidErrors.CodeOf(error);
                    _failureCode = code != null ? code : "hid_io_error";
                    _failureMessage = error.Message;
                }
                ResetFlowLocked();
                _state = HidLinkState.Disconnected;
                _epoch = 0u;
                Monitor.PulseAll(_gate);
            }
        }

        private void FinishWorker()
        {
            lock (_gate)
            {
                _cancelled = true;
                if (_failureCode == null && !_disposedFlag)
                {
                    _failureCode = "hid_io_error";
                    _failureMessage = "the HID worker stopped";
                }
                ResetFlowLocked();
                _state = HidLinkState.Disconnected;
                _epoch = 0u;
                Monitor.PulseAll(_gate);
            }
            try
            {
                _io.Dispose();
            }
            catch (Exception)
            {
                // Teardown is best effort: the worker owns every handle and releases them here, on its own thread.
            }
            // Cooperative reclamation.
            Win32HidReportIo native = _io as Win32HidReportIo;
            if (native != null)
            {
                while (!native.CleanupComplete)
                {
                    native.TryReclaimDeferred();
                }
            }
        }

        private void ThrowIfUnavailableLocked()
        {
            if (_disposedFlag)
            {
                throw HidErrors.Coded("hid_closed", "the HID stream was disposed");
            }
            if (_failureCode != null)
            {
                throw BuildFailureLocked();
            }
        }

        private void ThrowIfGenerationLocked(long generation)
        {
            if (_generation != generation)
            {
                throw HidErrors.Coded(
                    "hid_session_reset",
                    "a new HID session began; unacknowledged bytes were discarded");
            }
        }

        private IOException BuildFailureLocked()
        {
            return HidErrors.Coded(_failureCode, _failureMessage);
        }

        private static bool SamePayload(byte[] left, int leftOffset, byte[] right, int length)
        {
            for (int index = 0; index < length; index++)
            {
                if (left[leftOffset + index] != right[index])
                {
                    return false;
                }
            }
            return true;
        }

        private static ushort ReadU16(byte[] buffer, int offset)
        {
            return unchecked((ushort)(buffer[offset] | (buffer[offset + 1] << 8)));
        }

        private static uint ReadU32(byte[] buffer, int offset)
        {
            return unchecked((uint)buffer[offset]
                | ((uint)buffer[offset + 1] << 8)
                | ((uint)buffer[offset + 2] << 16)
                | ((uint)buffer[offset + 3] << 24));
        }

        private static void WriteU16(byte[] buffer, int offset, ushort value)
        {
            buffer[offset] = unchecked((byte)(value & 0xFF));
            buffer[offset + 1] = unchecked((byte)((value >> 8) & 0xFF));
        }

        private static void WriteU32(byte[] buffer, int offset, uint value)
        {
            buffer[offset] = unchecked((byte)(value & 0xFF));
            buffer[offset + 1] = unchecked((byte)((value >> 8) & 0xFF));
            buffer[offset + 2] = unchecked((byte)((value >> 16) & 0xFF));
            buffer[offset + 3] = unchecked((byte)((value >> 24) & 0xFF));
        }

        private static void PushRing(
            byte[] queue, ref int head, ref int length, byte[] source, int sourceOffset, int count)
        {
            int tail = (head + length) % HidWireConstants.QueueBytes;
            int first = HidWireConstants.QueueBytes - tail;
            if (first > count)
            {
                first = count;
            }
            Array.Copy(source, sourceOffset, queue, tail, first);
            if (count > first)
            {
                Array.Copy(source, sourceOffset + first, queue, 0, count - first);
            }
            length += count;
        }

        private static void PopRing(
            byte[] queue, ref int head, ref int length, byte[] destination,
            int destinationOffset, int count)
        {
            int first = HidWireConstants.QueueBytes - head;
            if (first > count)
            {
                first = count;
            }
            Array.Copy(queue, head, destination, destinationOffset, first);
            if (count > first)
            {
                Array.Copy(queue, 0, destination, destinationOffset + first, count - first);
            }
            head = (head + count) % HidWireConstants.QueueBytes;
            length -= count;
            if (length == 0)
            {
                head = 0;
            }
        }

        private static void PeekRing(byte[] queue, int head, int length, byte[] destination, int count)
        {
            int take = Math.Min(count, length);
            int first = HidWireConstants.QueueBytes - head;
            if (first > take)
            {
                first = take;
            }
            Array.Copy(queue, head, destination, 0, first);
            if (take > first)
            {
                Array.Copy(queue, 0, destination, first, take - first);
            }
        }
    }

    internal sealed class Win32HidReportIo : IHidReportIo
    {
        private readonly string _serial;
        private readonly object _writeGate;
        private readonly byte[] _readBuffer;
        private readonly byte[] _writeBuffer;
        private readonly GCHandle[] _bufferPins;
        private IntPtr _handle;
        private IntPtr _readEvent;
        private IntPtr _writeEvent;
        private IntPtr _readOverlapped;
        private IntPtr _writeOverlapped;
        private bool _readPending;
        private bool _writePending;
        private bool _opened;
        private bool _disposed;
        private bool _cleanupDeferred;
        private Mutex _mutex;
        private bool _mutexHeld;

        public Win32HidReportIo(string serial)
        {
            _serial = serial;
            _writeGate = new object();
            _readBuffer = new byte[HidWireConstants.ReportBytes];
            _writeBuffer = new byte[HidWireConstants.ReportBytes];
            _bufferPins = new GCHandle[2];
            _readOverlapped = IntPtr.Zero;
            _writeOverlapped = IntPtr.Zero;
        }

        public int Read(byte[] report, int timeoutMs)
        {
            if (report == null || report.Length < HidWireConstants.ReportBytes)
            {
                throw new ArgumentException("a 64-byte report buffer is required", "report");
            }
            if (_disposed)
            {
                return -1;
            }
            EnsureOpen();
            if (!_readPending)
            {
                uint immediate;
                bool started = HidInterop.ReadFile(
                    _handle,
                    _bufferPins[0].AddrOfPinnedObject(),
                    (uint)HidWireConstants.ReportBytes,
                    out immediate,
                    _readOverlapped);
                if (started)
                {
                    return CopyReadResult(report, immediate);
                }
                int error = Marshal.GetLastWin32Error();
                if (error != HidNative.ErrorIoPending)
                {
                    throw HidErrors.Coded(
                        "hid_io_error",
                        "ReadFile on the HID collection failed with " + error);
                }
                _readPending = true;
            }
            uint wait = HidInterop.WaitForSingleObject(_readEvent, (uint)Math.Max(timeoutMs, 0));
            if (wait == HidNative.WaitObject0)
            {
                _readPending = false;
                HidInterop.ResetEvent(_readEvent);
                uint transferred;
                if (!HidInterop.GetOverlappedResult(_handle, _readOverlapped, out transferred, false))
                {
                    int error = Marshal.GetLastWin32Error();
                    if (error == HidNative.ErrorOperationAborted)
                    {
                        return -1;
                    }
                    throw HidErrors.Coded(
                        "hid_io_error",
                        "GetOverlappedResult after a HID read failed with " + error);
                }
                return CopyReadResult(report, transferred);
            }
            return 0;
        }

        private int CopyReadResult(byte[] report, uint transferred)
        {
            if (transferred == 0)
            {
                return 0;
            }
            if (transferred > HidWireConstants.ReportBytes)
            {
                transferred = (uint)HidWireConstants.ReportBytes;
            }
            Array.Copy(_readBuffer, 0, report, 0, (int)transferred);
            for (int index = (int)transferred; index < HidWireConstants.ReportBytes; index++)
            {
                report[index] = 0;
            }
            return (int)transferred;
        }

        public void Write(byte[] report)
        {
            if (report == null || report.Length < HidWireConstants.ReportBytes)
            {
                throw new ArgumentException("a 64-byte report is required", "report");
            }
            if (_disposed)
            {
                throw HidErrors.Coded("hid_closed", "the HID stream was disposed");
            }
            EnsureOpen();
            lock (_writeGate)
            {
                if (_writePending)
                {
                    // A previous write timed out and its overlapped operation is still owned by the kernel: the pinned buff...
                    if (!WriteCompleted())
                    {
                        throw HidErrors.Coded(
                            "hid_write_timeout",
                            "a previous HID write is still pending");
                    }
                }
                Array.Copy(report, 0, _writeBuffer, 0, HidWireConstants.ReportBytes);
                uint immediate;
                bool started = HidInterop.WriteFile(
                    _handle,
                    _bufferPins[1].AddrOfPinnedObject(),
                    (uint)HidWireConstants.ReportBytes,
                    out immediate,
                    _writeOverlapped);
                if (!started)
                {
                    int pending = Marshal.GetLastWin32Error();
                    if (pending != HidNative.ErrorIoPending)
                    {
                        throw HidErrors.Coded(
                            "hid_io_error",
                            "WriteFile on the HID collection failed with " + pending);
                    }
                    _writePending = true;
                    uint wait = HidInterop.WaitForSingleObject(
                        _writeEvent, HidWireConstants.WriteTimeoutMs);
                    if (wait != HidNative.WaitObject0)
                    {
                        HidInterop.CancelIoEx(_handle, _writeOverlapped);
                        throw HidErrors.Coded(
                            "hid_write_timeout",
                            "the HID write did not complete within 250 ms");
                    }
                    _writePending = false;
                    HidInterop.ResetEvent(_writeEvent);
                }
                uint written;
                if (!HidInterop.GetOverlappedResult(_handle, _writeOverlapped, out written, false))
                {
                    int error = Marshal.GetLastWin32Error();
                    if (error == HidNative.ErrorOperationAborted)
                    {
                        throw HidErrors.Coded("hid_closed", "the HID write was cancelled");
                    }
                    throw HidErrors.Coded(
                        "hid_io_error",
                        "GetOverlappedResult after a HID write failed with " + error);
                }
                if (written != HidWireConstants.ReportBytes)
                {
                    throw HidErrors.Coded(
                        "hid_io_error",
                        "short HID write: " + written + " of 64 bytes");
                }
            }
        }

        private bool WriteCompleted()
        {
            if (!_writePending)
            {
                return true;
            }
            if (_handle == IntPtr.Zero)
            {
                return false;
            }
            uint wait = HidInterop.WaitForSingleObject(_writeEvent, 0u);
            if (wait != HidNative.WaitObject0)
            {
                return false;
            }
            uint transferred;
            HidInterop.GetOverlappedResult(_handle, _writeOverlapped, out transferred, false);
            _writePending = false;
            HidInterop.ResetEvent(_writeEvent);
            return true;
        }

        // Cooperative native reclamation, run by the worker's own thread after the device handle was closed (cl...
        private bool ReclaimPendingMemory()
        {
            if (OperationDone(_writePending, _writeEvent))
            {
                _writePending = false;
                if (_writeOverlapped != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(_writeOverlapped);
                    _writeOverlapped = IntPtr.Zero;
                }
                if (_writeEvent != IntPtr.Zero)
                {
                    HidInterop.CloseHandle(_writeEvent);
                    _writeEvent = IntPtr.Zero;
                }
                if (_bufferPins[1].IsAllocated)
                {
                    _bufferPins[1].Free();
                }
            }
            if (OperationDone(_readPending, _readEvent))
            {
                _readPending = false;
                if (_readOverlapped != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(_readOverlapped);
                    _readOverlapped = IntPtr.Zero;
                }
                if (_readEvent != IntPtr.Zero)
                {
                    HidInterop.CloseHandle(_readEvent);
                    _readEvent = IntPtr.Zero;
                }
                if (_bufferPins[0].IsAllocated)
                {
                    _bufferPins[0].Free();
                }
            }
            return !_writePending && !_readPending;
        }

        public bool TryReclaimDeferred()
        {
            if (!_cleanupDeferred)
            {
                return true;
            }
            if (ReclaimPendingMemory())
            {
                _cleanupDeferred = false;
            }
            return !_cleanupDeferred;
        }

        private bool OperationDone(bool pending, IntPtr completionEvent)
        {
            if (!pending || completionEvent == IntPtr.Zero)
            {
                return true;
            }
            uint wait = HidInterop.WaitForSingleObject(
                completionEvent, HidWireConstants.CancelSettleMs);
            return wait == HidNative.WaitObject0;
        }

        private void EnsureOpen()
        {
            if (_opened)
            {
                return;
            }
            AcquireMutex();
            string path = HidDeviceBrowser.FindDataCollection(_serial);
            IntPtr handle = HidInterop.CreateFileW(
                path,
                HidNative.GenericRead | HidNative.GenericWrite,
                HidNative.FileShareRead | HidNative.FileShareWrite,
                IntPtr.Zero,
                HidNative.OpenExisting,
                HidNative.FileFlagOverlapped,
                IntPtr.Zero);
            if (handle == HidNative.InvalidHandleValue)
            {
                int error = Marshal.GetLastWin32Error();
                throw HidErrors.Coded(
                    "hid_access_denied",
                    "CreateFileW on the HID collection failed with " + error);
            }
            IntPtr readEvent = HidInterop.CreateEventW(IntPtr.Zero, true, false, null);
            IntPtr writeEvent = HidInterop.CreateEventW(IntPtr.Zero, true, false, null);
            if (readEvent == IntPtr.Zero || writeEvent == IntPtr.Zero)
            {
                int error = Marshal.GetLastWin32Error();
                if (readEvent != IntPtr.Zero)
                {
                    HidInterop.CloseHandle(readEvent);
                }
                if (writeEvent != IntPtr.Zero)
                {
                    HidInterop.CloseHandle(writeEvent);
                }
                HidInterop.CloseHandle(handle);
                throw HidErrors.Coded(
                    "hid_io_error",
                    "CreateEventW for the HID transport failed with " + error);
            }
            _bufferPins[0] = GCHandle.Alloc(_readBuffer, GCHandleType.Pinned);
            _bufferPins[1] = GCHandle.Alloc(_writeBuffer, GCHandleType.Pinned);
            _readOverlapped = AllocateOverlapped(readEvent);
            _writeOverlapped = AllocateOverlapped(writeEvent);
            _handle = handle;
            _readEvent = readEvent;
            _writeEvent = writeEvent;
            _opened = true;
        }

        private static IntPtr AllocateOverlapped(IntPtr eventHandle)
        {
            int size = Marshal.SizeOf(typeof(HidOverlapped));
            IntPtr memory = Marshal.AllocHGlobal(size);
            HidOverlapped overlapped = new HidOverlapped();
            overlapped.Internal = IntPtr.Zero;
            overlapped.InternalHigh = IntPtr.Zero;
            overlapped.Offset = 0u;
            overlapped.OffsetHigh = 0u;
            overlapped.EventHandle = eventHandle;
            Marshal.StructureToPtr(overlapped, memory, false);
            return memory;
        }

        private void AcquireMutex()
        {
            try
            {
                // Windows mutexes are thread-affine: acquired and released
                // only on the I/O (worker) thread; failure is hid_busy.
                _mutex = new Mutex(false, "Local\\Titella.Hid." + _serial);
            }
            catch (Exception error)
            {
                throw HidErrors.Coded(
                    "hid_busy",
                    "the HID consumer mutex could not be created: " + error.Message);
            }
            try
            {
                _mutexHeld = _mutex.WaitOne(0, false);
            }
            catch (AbandonedMutexException)
            {
                // The previous owner died without releasing it: ownership was passed to this thread.
                _mutexHeld = true;
            }
            if (!_mutexHeld)
            {
                throw HidErrors.Coded(
                    "hid_busy",
                    "another consumer holds Local\\Titella.Hid." + _serial);
            }
        }

        public void Dispose()
        {
            if (_disposed)
            {
                return;
            }
            _disposed = true;
            if (_handle != IntPtr.Zero)
            {
                HidInterop.CancelIoEx(_handle, IntPtr.Zero);
                HidInterop.CloseHandle(_handle);
                _handle = IntPtr.Zero;
            }
            if (!ReclaimPendingMemory())
            {
                _cleanupDeferred = true;
            }
            if (_mutexHeld)
            {
                try
                {
                    _mutex.ReleaseMutex();
                }
                catch (ApplicationException)
                {
                    // Ownership was already lost; nothing to release.
                }
                _mutexHeld = false;
            }
            if (_mutex != null)
            {
                _mutex.Dispose();
                _mutex = null;
            }
        }

        public bool CleanupComplete
        {
            get { return !_cleanupDeferred; }
        }
    }

    internal static class HidDeviceBrowser
    {
        public static string FindDataCollection(string serial)
        {
            Guid hidGuid;
            HidInterop.HidD_GetHidGuid(out hidGuid);
            IntPtr set = HidInterop.SetupDiGetClassDevsW(
                ref hidGuid,
                IntPtr.Zero,
                IntPtr.Zero,
                HidNative.DigcfPresent | HidNative.DigcfDeviceInterface);
            if (set == HidNative.InvalidHandleValue)
            {
                throw HidErrors.Coded(
                    "hid_not_found",
                    "SetupDiGetClassDevsW failed with " + Marshal.GetLastWin32Error());
            }
            try
            {
                HidInterfaceData data = new HidInterfaceData();
                data.Size = Marshal.SizeOf(typeof(HidInterfaceData));
                int exact = 0;
                int incompatible = 0;
                int denied = 0;
                string exactPath = null;
                for (uint index = 0; ; index++)
                {
                    if (!HidInterop.SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref hidGuid, index, ref data))
                    {
                        int error = Marshal.GetLastWin32Error();
                        if (error == HidNative.ErrorNoMoreItems)
                        {
                            break;
                        }
                        throw HidErrors.Coded(
                            "hid_not_found",
                            "SetupDiEnumDeviceInterfaces failed with " + error);
                    }
                    string path = InterfacePath(set, ref data);
                    if (path == null)
                    {
                        continue;
                    }
                    HidProbe probe = Probe(path, serial);
                    if (probe == HidProbe.Exact)
                    {
                        exact++;
                        exactPath = path;
                    }
                    else if (probe == HidProbe.Incompatible)
                    {
                        incompatible++;
                    }
                    else if (probe == HidProbe.Denied && PathCarriesIdentity(path))
                    {
                        denied++;
                    }
                }
                if (exact == 1)
                {
                    return exactPath;
                }
                if (exact > 1)
                {
                    throw HidErrors.Coded(
                        "hid_ambiguous",
                        "several HID data collections match the device serial");
                }
                if (incompatible > 0)
                {
                    throw HidErrors.Coded(
                        "hid_incompatible",
                        "the HID data collection does not expose 64-byte IN/OUT/Feature reports");
                }
                if (denied > 0)
                {
                    throw HidErrors.Coded(
                        "hid_access_denied",
                        "the HID data collection could not be inspected");
                }
                throw HidErrors.Coded(
                    "hid_not_found",
                    "no HID data collection for serial " + serial + " is present");
            }
            finally
            {
                HidInterop.SetupDiDestroyDeviceInfoList(set);
            }
        }

        private static string InterfacePath(IntPtr set, ref HidInterfaceData data)
        {
            uint required;
            HidInterop.SetupDiGetDeviceInterfaceDetailW(
                set, ref data, IntPtr.Zero, 0u, out required, IntPtr.Zero);
            if (required == 0u)
            {
                return null;
            }
            IntPtr buffer = Marshal.AllocHGlobal((int)required);
            try
            {
                // cbSize is 6 on x86 / 8 on x64, but DevicePath always begins
                // at byte offset 4 on BOTH architectures (offset 8 drops the
                // first two UTF-16 chars on x64 and CreateFile would fail).
                const int textOffset = 4;
                uint detailSize = IntPtr.Size == 8 ? 8u : 6u;
                Marshal.WriteInt32(buffer, (int)detailSize);
                if (!HidInterop.SetupDiGetDeviceInterfaceDetailW(
                        set, ref data, buffer, required, out required, IntPtr.Zero))
                {
                    return null;
                }
                return Marshal.PtrToStringUni(new IntPtr(buffer.ToInt64() + textOffset));
            }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }
        }

        private static HidProbe Probe(string path, string serial)
        {
            IntPtr handle = HidInterop.CreateFileW(
                path,
                0u,
                HidNative.FileShareRead | HidNative.FileShareWrite,
                IntPtr.Zero,
                HidNative.OpenExisting,
                0u,
                IntPtr.Zero);
            if (handle == HidNative.InvalidHandleValue)
            {
                return HidProbe.Denied;
            }
            try
            {
                HidAttributes attributes = new HidAttributes();
                attributes.Size = (uint)Marshal.SizeOf(typeof(HidAttributes));
                if (!HidInterop.HidD_GetAttributes(handle, ref attributes))
                {
                    return HidProbe.Denied;
                }
                if (attributes.VendorID != HidWireConstants.VendorId
                    || attributes.ProductID != HidWireConstants.ProductId)
                {
                    return HidProbe.Other;
                }
                string deviceSerial = SerialNumber(handle);
                if (deviceSerial == null || !string.Equals(deviceSerial, serial, StringComparison.Ordinal))
                {
                    return HidProbe.Other;
                }
                IntPtr preparsed;
                if (!HidInterop.HidD_GetPreparsedData(handle, out preparsed))
                {
                    return HidProbe.Incompatible;
                }
                try
                {
                    HidCaps caps = new HidCaps();
                    caps.Reserved = new ushort[17];
                    if (HidInterop.HidP_GetCaps(preparsed, ref caps) != HidNative.HidpStatusSuccess)
                    {
                        return HidProbe.Incompatible;
                    }
                    if (caps.UsagePage != HidWireConstants.UsagePageVendor
                        || caps.Usage != HidWireConstants.UsageData)
                    {
                        return HidProbe.Other;
                    }
                    if (caps.InputReportByteLength != HidWireConstants.CollectionReportBytes
                        || caps.OutputReportByteLength != HidWireConstants.CollectionReportBytes
                        || caps.FeatureReportByteLength != HidWireConstants.CollectionReportBytes)
                    {
                        return HidProbe.Incompatible;
                    }
                    return HidProbe.Exact;
                }
                finally
                {
                    HidInterop.HidD_FreePreparsedData(preparsed);
                }
            }
            finally
            {
                HidInterop.CloseHandle(handle);
            }
        }

        private static string SerialNumber(IntPtr handle)
        {
            StringBuilder buffer = new StringBuilder(128);
            if (!HidInterop.HidD_GetSerialNumberString(handle, buffer, (uint)(buffer.Capacity * 2)))
            {
                return null;
            }
            string serial = buffer.ToString();
            int terminator = serial.IndexOf('\0');
            if (terminator >= 0)
            {
                serial = serial.Substring(0, terminator);
            }
            return serial;
        }

        private static bool PathCarriesIdentity(string path)
        {
            if (path == null)
            {
                return false;
            }
            return path.IndexOf("vid_17ef", StringComparison.OrdinalIgnoreCase) >= 0
                && path.IndexOf("pid_a38f", StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }

    internal enum HidProbe : byte
    {
        Other = 0,
        Exact = 1,
        Incompatible = 2,
        Denied = 3,
    }

    internal static class HidNative
    {
        public const uint DigcfPresent = 0x00000002u;
        public const uint DigcfDeviceInterface = 0x00000010u;
        public const uint GenericRead = 0x80000000u;
        public const uint GenericWrite = 0x40000000u;
        public const uint FileShareRead = 0x00000001u;
        public const uint FileShareWrite = 0x00000002u;
        public const uint OpenExisting = 3u;
        public const uint FileFlagOverlapped = 0x40000000u;
        public const uint ErrorNoMoreItems = 259u;
        public const int ErrorIoPending = 997;
        public const int ErrorOperationAborted = 995;
        public const uint WaitObject0 = 0u;
        public const int HidpStatusSuccess = 0x00110000;
        public static readonly IntPtr InvalidHandleValue = new IntPtr(-1);
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct HidInterfaceData
    {
        public int Size;
        public Guid InterfaceClassGuid;
        public int Flags;
        public IntPtr Reserved;
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct HidAttributes
    {
        public uint Size;
        public ushort VendorID;
        public ushort ProductID;
        public ushort VersionNumber;
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct HidCaps
    {
        public ushort Usage;
        public ushort UsagePage;
        public ushort InputReportByteLength;
        public ushort OutputReportByteLength;
        public ushort FeatureReportByteLength;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)]
        public ushort[] Reserved;
        public ushort NumberLinkCollectionNodes;
        public ushort NumberInputButtonCaps;
        public ushort NumberInputValueCaps;
        public ushort NumberInputDataIndices;
        public ushort NumberOutputButtonCaps;
        public ushort NumberOutputValueCaps;
        public ushort NumberOutputDataIndices;
        public ushort NumberFeatureButtonCaps;
        public ushort NumberFeatureValueCaps;
        public ushort NumberFeatureDataIndices;
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct HidOverlapped
    {
        public IntPtr Internal;
        public IntPtr InternalHigh;
        public uint Offset;
        public uint OffsetHigh;
        public IntPtr EventHandle;
    }

    internal static class HidInterop
    {
        [DllImport("hid.dll")]
        internal static extern void HidD_GetHidGuid(out Guid hidGuid);

        [DllImport("hid.dll", SetLastError = true)]
        internal static extern bool HidD_GetAttributes(IntPtr device, ref HidAttributes attributes);

        [DllImport("hid.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool HidD_GetSerialNumberString(
            IntPtr device, StringBuilder buffer, uint bufferChars);

        [DllImport("hid.dll", SetLastError = true)]
        internal static extern bool HidD_GetPreparsedData(IntPtr device, out IntPtr preparsed);

        [DllImport("hid.dll")]
        internal static extern bool HidD_FreePreparsedData(IntPtr preparsed);

        [DllImport("hid.dll")]
        internal static extern int HidP_GetCaps(IntPtr preparsed, ref HidCaps caps);

        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr SetupDiGetClassDevsW(
            ref Guid classGuid, IntPtr enumerator, IntPtr window, uint flags);

        [DllImport("setupapi.dll", SetLastError = true)]
        internal static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr set, IntPtr deviceInfo, ref Guid classGuid, uint index,
            ref HidInterfaceData data);

        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetailW(
            IntPtr set, ref HidInterfaceData data, IntPtr detail, uint detailBytes,
            out uint required, IntPtr deviceInfo);

        [DllImport("setupapi.dll", SetLastError = true)]
        internal static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr CreateFileW(
            string path, uint access, uint share, IntPtr security, uint disposition,
            uint flags, IntPtr template);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool CloseHandle(IntPtr handle);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ReadFile(
            IntPtr handle, IntPtr buffer, uint bytes, out uint transferred, IntPtr overlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool WriteFile(
            IntPtr handle, IntPtr buffer, uint bytes, out uint transferred, IntPtr overlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetOverlappedResult(
            IntPtr handle, IntPtr overlapped, out uint transferred, bool wait);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool CancelIoEx(IntPtr handle, IntPtr overlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern IntPtr CreateEventW(
            IntPtr attributes, bool manualReset, bool initialState, string name);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ResetEvent(IntPtr handle);

        [DllImport("kernel32.dll")]
        internal static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);
    }
}

// ILinkTransport adapter over the HID byte stream. AgentLink keeps its
// reader/writer/heartbeat threads, bounded queues and every service exactly
// as it does for the CDC and clipboard transports; this unit only maps the
// HID binding to a HidByteStream and translates stream failures into the
// existing LinkLostException the link already understands.

namespace Titella.Slave
{
    using System;
    using System.IO;

    /// <summary>
    /// Transport for <c>slave_transport = "hid"</c> (the protocol field
    /// <c>agent_protocol</c> stays <c>serial</c>): protocol v1 frames travel
    /// inside the HID data stream, never through the shared clipboard, a COM
    /// port or the network. Read keeps the CDC contract (zero after 100 ms
    /// without bytes) and Write returns once the peer acknowledged the bytes.
    /// </summary>
    internal sealed class HidTransport : ILinkTransport
    {
        private readonly string _binding;
        private HidByteStream _stream;

        public HidTransport(string binding)
        {
            if (!HidByteStream.IsHidBinding(binding))
            {
                throw new ArgumentException(
                    "a HID binding such as HID:0123456789AB is required", "binding");
            }
            _binding = binding;
        }

        /// <summary>True for the exact <c>HID:&lt;12 uppercase hex&gt;</c> form.</summary>
        public static bool IsHidBinding(string value)
        {
            return HidByteStream.IsHidBinding(value);
        }

        /// <summary>Opens the data collection and completes the OPEN handshake.</summary>
        public void Open()
        {
            _stream = HidByteStream.Open(_binding);
        }

        public bool IsOpen
        {
            get { return _stream != null; }
        }

        public int Read(byte[] buffer, int offset, int count)
        {
            HidByteStream stream = _stream;
            if (stream == null)
            {
                throw new LinkLostException(0, "the HID transport is closed");
            }
            try
            {
                return stream.Read(buffer, offset, count);
            }
            catch (IOException error)
            {
                throw ToLinkLost(error);
            }
        }

        public void Write(byte[] buffer, int offset, int count)
        {
            HidByteStream stream = _stream;
            if (stream == null)
            {
                throw new LinkLostException(0, "the HID transport is closed");
            }
            try
            {
                stream.Write(buffer, offset, count);
            }
            catch (IOException error)
            {
                throw ToLinkLost(error);
            }
        }

        public void Dispose()
        {
            HidByteStream stream = _stream;
            _stream = null;
            if (stream != null)
            {
                stream.Dispose();
            }
        }

        /// <summary>
        /// Keeps the HID code visible: the loader walks the InnerException
        /// chain for Exception.Data["titella_code"], and AgentLink only knows
        /// LinkLostException.
        /// </summary>
        private static LinkLostException ToLinkLost(IOException error)
        {
            LinkLostException link = new LinkLostException(0, error.Message);
            string code = HidErrors.CodeOf(error);
            if (code != null)
            {
                link.Data["titella_code"] = code;
            }
            return link;
        }
    }
}

// In-process PowerShell engine host for one-shot jobs.
//
// A job is the agent executable itself started with --job and assigned to a
// job object (so cancellation and timeouts keep killing the whole process
// tree), but the user script never touches the child's command line. The
// command line only says --job; the script itself arrives on stdin and
// executes in a custom PSHost, which keeps the script text out of every
// classic PowerShell log channel (Id 400/800 HostApplication, 4103/4104
// script text, PSReadLine history).

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.IO;
    using System.Management.Automation;
    using System.Management.Automation.Host;
    using System.Management.Automation.Runspaces;
    using System.Security;
    using System.Text;

    internal sealed class JobHostUserInterface : PSHostUserInterface
    {
        private readonly Action<string> _stdout;
        private readonly Action<string> _stderr;
        internal bool SawError;

        public JobHostUserInterface(Action<string> stdout, Action<string> stderr)
        {
            _stdout = stdout;
            _stderr = stderr;
        }

        public override void Write(string value)
        {
            _stdout(value);
        }

        public override void WriteLine()
        {
            _stdout(string.Empty);
        }

        public override void WriteLine(string value)
        {
            _stdout(value);
        }

        public override void Write(ConsoleColor foreground, ConsoleColor background, string value)
        {
            _stdout(value);
        }

        public override void WriteLine(ConsoleColor foreground, ConsoleColor background, string value)
        {
            _stdout(value);
        }

        public override void WriteErrorLine(string value)
        {
            SawError = true;
            _stderr(value);
        }

        public override void WriteDebugLine(string value) { }

        public override void WriteVerboseLine(string value) { }

        public override void WriteWarningLine(string value)
        {
            _stderr("WARNING: " + value);
        }

        public override void WriteProgress(long sourceId, ProgressRecord record) { }

        public override string ReadLine()
        {
            throw new PSInvalidOperationException(
                "this host is non-interactive; Read-Host is not available");
        }

        public override SecureString ReadLineAsSecureString()
        {
            throw new PSInvalidOperationException(
                "this host is non-interactive; Read-Host is not available");
        }

        public override Dictionary<string, PSObject> Prompt(
            string caption, string message,
            Collection<FieldDescription> descriptions)
        {
            throw new PSInvalidOperationException(
                "this host is non-interactive; Prompt is not available");
        }

        public override PSCredential PromptForCredential(
            string caption, string message, string userName, string targetName)
        {
            throw new PSInvalidOperationException(
                "this host is non-interactive; credential prompts are not available");
        }

        public override PSCredential PromptForCredential(
            string caption, string message, string userName, string targetName,
            PSCredentialTypes allowedTypes, PSCredentialUIOptions options)
        {
            throw new PSInvalidOperationException(
                "this host is non-interactive; credential prompts are not available");
        }

        public override int PromptForChoice(
            string caption, string message,
            Collection<ChoiceDescription> choices, int defaultChoice)
        {
            throw new PSInvalidOperationException(
                "this host is non-interactive; choice prompts are not available");
        }

        public override PSHostRawUserInterface RawUI
        {
            get { return null; }
        }
    }

    internal sealed class JobHost : PSHost
    {
        private readonly JobHostUserInterface _ui;
        private readonly Guid _instanceId = Guid.NewGuid();
        private readonly Action<int> _setExit;

        public JobHost(Action<string> stdout, Action<string> stderr, Action<int> setExit)
        {
            _ui = new JobHostUserInterface(stdout, stderr);
            _setExit = setExit;
        }

        internal bool SawError
        {
            get { return _ui.SawError; }
        }

        public override CultureInfo CurrentCulture
        {
            get { return CultureInfo.InvariantCulture; }
        }

        public override CultureInfo CurrentUICulture
        {
            get { return CultureInfo.InvariantCulture; }
        }

        public override Guid InstanceId
        {
            get { return _instanceId; }
        }

        public override string Name
        {
            get { return "Default Host"; }
        }

        public override PSHostUserInterface UI
        {
            get { return _ui; }
        }

        public override Version Version
        {
            get { return new Version(5, 1); }
        }

        public override void EnterNestedPrompt()
        {
            throw new PSNotSupportedException();
        }

        public override void ExitNestedPrompt()
        {
            throw new PSNotSupportedException();
        }

        public override void NotifyBeginApplication() { }

        public override void NotifyEndApplication() { }

        public override void SetShouldExit(int exitCode)
        {
            _setExit(exitCode);
        }
    }

    /// <summary>
    /// One script executed in one in-process Runspace with a custom host.
    /// Mirrors the semantics of the previous powershell.exe -EncodedCommand
    /// child: UTF-8 output encoding is forced, stdout and stderr are
    /// separated (Write-Host and pipeline output go to stdout; host error
    /// writes and cmdlet error records go to stderr), the exit code is the
    /// argument of exit (or 0/1 depending on success), and native commands
    /// inherit redirected stdout/stderr so they stay separated too.
    /// </summary>
    internal sealed class JobEngine
    {
        private readonly StringBuilder _stdout = new StringBuilder();
        private readonly StringBuilder _stderr = new StringBuilder();
        private int _exitCode;
        private bool _exitCalled;

        public static int Run(string script, TextWriter stdout, TextWriter stderr)
        {
            JobEngine engine = new JobEngine();
            return engine.RunCore(script, stdout, stderr);
        }

        private int RunCore(string script, TextWriter stdout, TextWriter stderr)
        {
            JobHost host = new JobHost(
                delegate(string line)
                {
                    lock (_stdout)
                    {
                        _stdout.Append(line);
                        _stdout.Append('\n');
                    }
                },
                delegate(string line)
                {
                    lock (_stderr)
                    {
                        _stderr.Append(line);
                        _stderr.Append('\n');
                    }
                },
                delegate(int code)
                {
                    _exitCode = code;
                    _exitCalled = true;
                });
            Runspace runspace = null;
            try
            {
                runspace = RunspaceFactory.CreateRunspace(host);
                runspace.Open();
                Pipeline pipeline = runspace.CreatePipeline();
                pipeline.Commands.AddScript(script);
                pipeline.Commands.Add("Out-Default");
                try
                {
                    pipeline.Invoke();
                }
                catch (RuntimeException)
                {
                    // Terminating errors are already reported through the
                    // host error stream by the engine; the job must finish
                    // with a non-zero exit code like powershell.exe would.
                    _exitCode = 1;
                    return Finish(stdout, stderr);
                }
                finally
                {
                    FlushBuffers(stdout, stderr);
                }
                if (_exitCalled)
                {
                    return Finish(stdout, stderr);
                }
                // Non-terminating cmdlet errors are rendered to the host
                // error stream by Out-Default; powershell.exe -Command
                // exits 1 when any error was written, and the runner
                // keeps that contract.
                _exitCode = host.SawError ? 1 : 0;
                return Finish(stdout, stderr);
            }
            finally
            {
                if (runspace != null)
                {
                    try
                    {
                        runspace.Close();
                    }
                    catch (Exception)
                    {
                        // Closing after a failed pipeline is best effort.
                    }
                }
            }
        }

        private int Finish(TextWriter stdout, TextWriter stderr)
        {
            FlushBuffers(stdout, stderr);
            return _exitCode;
        }

        private void FlushBuffers(TextWriter stdout, TextWriter stderr)
        {
            string outText;
            string errText;
            lock (_stdout)
            {
                outText = _stdout.ToString();
                _stdout.Length = 0;
            }
            lock (_stderr)
            {
                errText = _stderr.ToString();
                _stderr.Length = 0;
            }
            if (outText.Length > 0)
            {
                stdout.Write(outText);
            }
            if (errText.Length > 0)
            {
                stderr.Write(errText);
            }
        }
    }

    /// <summary>
    /// Child-process entry point (--job): read the script from stdin (the
    /// parent closes its end after writing, which is the EOF signal) and
    /// execute it in the in-process Runspace, mapping the exit code to
    /// the process exit code exactly like powershell.exe -Command does.
    /// </summary>
    internal static class JobEntry
    {
        public static int Run()
        {
            try
            {
                // The job child has redirected pipes and no console: the
                // Win32 console APIs behind Console.OutputEncoding fail with
                // UnauthorizedAccessException on a console-less process, so
                // UTF-8 is enforced by the writers alone.
                string script = Console.In.ReadToEnd();
                Encoding utf8 = new UTF8Encoding(false);
                using (StreamWriter stdout = new StreamWriter(Console.OpenStandardOutput(), utf8))
                using (StreamWriter stderr = new StreamWriter(Console.OpenStandardError(), utf8))
                {
                    stdout.AutoFlush = true;
                    stderr.AutoFlush = true;
                    return JobEngine.Run(script, stdout, stderr);
                }
            }
            catch (Exception e)
            {
                try
                {
                    Console.Error.WriteLine("jobentry_failed: " + e.GetType().Name
                                            + ": " + e.Message);
                }
                catch (Exception)
                {
                    // Nothing else can be reported from here.
                }
                return 4;
            }
        }
    }
}

// Win32 interop for the Titella Windows slave: serial CDC, job-object
// process containment, suspended CreateProcessW with ConPTY attributes,
// and atomic replace/delete primitives. Pure declarations plus thin RAII
// wrappers; no protocol policy lives here. Compiled as C# 5 on the
// .NET Framework 4.7.2 in-memory compiler of PowerShell 5.1 Add-Type.

namespace Titella.Slave
{
    using System;
    using System.Runtime.InteropServices;

    /// <summary>Win32 constants shared by several units.</summary>
    internal static class Win32Constants
    {
        // CreateFileW
        public const uint GENERIC_READ = 0x80000000u;
        public const uint GENERIC_WRITE = 0x40000000u;
        public const uint OPEN_EXISTING = 3u;
        public const uint FILE_ATTRIBUTE_NORMAL = 0x00000080u;
        public const uint INVALID_ERROR = 0xFFFFFFFFu;

        // Serial
        public const uint CBR_2000000 = 2000000u;
        public const uint NOPARITY = 0u;
        public const byte ONESTOPBIT = 0;
        public const uint MAXDWORD = 0xFFFFFFFFu;
        public const uint SETRTS = 3u;
        public const uint SETDTR = 5u;

        // COMMTIMEOUTS poll recipe: ReadFile returns TRUE with zero bytes
        // after ReadTotalTimeoutConstant instead of blocking forever.
        public const uint READ_POLL_MS = 100u;
        public const uint WRITE_TOTAL_MS = 2000u;

        // Win32 errors that mean "the CDC went away" for the reader loop.
        public const int ERROR_ACCESS_DENIED = 5;
        public const int ERROR_BROKEN_PIPE = 109;
        public const int ERROR_BAD_COMMAND = 22;
        public const int ERROR_GEN_FAILURE = 31;
        public const int ERROR_OPERATION_ABORTED = 995;
        public const int ERROR_DEVICE_NOT_CONNECTED = 1167;

        // Job objects
        public const int JobObjectExtendedLimitInformation = 9;
        public const uint JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000u;
        public const uint STATUS_CONTROL_C_EXIT = 0xC000013Au;

        // CreateProcessW
        public const uint CREATE_SUSPENDED = 0x00000004u;
        public const uint CREATE_UNICODE_ENVIRONMENT = 0x00000400u;
        public const uint EXTENDED_STARTUPINFO_PRESENT = 0x00080000u;
        public const uint CREATE_NO_WINDOW = 0x08000000u;
        public const int STARTF_USESTDHANDLES = 0x00000100;
        public const uint HANDLE_FLAG_INHERIT = 0x00000001u;
        public const uint WAIT_OBJECT_0 = 0u;
        public const uint WAIT_TIMEOUT = 258u;
        public const uint INFINITE = 0xFFFFFFFFu;

        // ProcThreadAttribute (IntPtr is not a legal const type in C#; static
        // readonly keeps the same single instance per AppDomain).
        public static readonly IntPtr PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = (IntPtr)0x00020016;

        // MoveFileExW / attributes
        public const uint MOVEFILE_REPLACE_EXISTING = 0x00000001u;
        public const uint MOVEFILE_WRITE_THROUGH = 0x00000008u;
        public const uint INVALID_FILE_ATTRIBUTES = 0xFFFFFFFFu;
        public const uint FILE_ATTRIBUTE_DIRECTORY = 0x00000010u;
        public const uint FILE_ATTRIBUTE_REPARSE_POINT = 0x00000400u;

        // Screen capture (GetSystemMetrics)
        public const int SM_CXSCREEN = 0;
        public const int SM_CYSCREEN = 1;

        // Clipboard: CF_UNICODETEXT payloads carried over GMEM_MOVEABLE
        // global allocations, the only form SetClipboardData accepts.
        public const uint CF_UNICODETEXT = 13u;
        public const uint GMEM_MOVEABLE = 0x0002u;
        public const uint GMEM_ZEROINIT = 0x0040u;

        // DPI awareness context (IntPtr is not a legal const type in C#;
        // PER_MONITOR_AWARE_V2 is the documented (HANDLE)-4).
        public static readonly IntPtr DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = (IntPtr)(-4);
    }

    /// <summary>Native structures. All layout-critical; keep Pack defaults.</summary>
    internal static class Win32Structs
    {
        [StructLayout(LayoutKind.Sequential)]
        internal struct DCB
        {
            public uint DCBlength;      // sizeof(DCB)
            public uint BaudRate;       // CBR_2000000
            public uint Flags;          // bitfield dword; fBinary must be set
            public ushort wReserved;
            public ushort XonLim;
            public ushort XoffLim;
            public byte ByteSize;       // 8
            public byte Parity;        // NOPARITY
            public byte StopBits;       // ONESTOPBIT
            public byte XonChar;
            public byte XoffChar;
            public byte ErrorChar;
            public byte EofChar;
            public byte EvtChar;
            public ushort wReserved1;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct COMMTIMEOUTS
        {
            public uint ReadIntervalTimeout;         // MAXDWORD
            public uint ReadTotalTimeoutMultiplier;  // MAXDWORD
            public uint ReadTotalTimeoutConstant;    // 100 ms poll
            public uint WriteTotalTimeoutMultiplier; // 0
            public uint WriteTotalTimeoutConstant;  // 2000 ms
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct COMSTAT
        {
            public uint Flags;
            public uint cbInQue;
            public uint cbOutQue;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct JOBOBJECT_BASIC_LIMIT_INFORMATION
        {
            public long PerProcessUserTimeLimit;
            public long PerJobUserTimeLimit;
            public uint LimitFlags;
            public UIntPtr MinimumWorkingSetSize;
            public UIntPtr MaximumWorkingSetSize;
            public uint ActiveProcessLimit;
            public UIntPtr Affinity;
            public uint PriorityClass;
            public uint SchedulingClass;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct IO_COUNTERS
        {
            public ulong ReadOperationCount;
            public ulong WriteOperationCount;
            public ulong OtherOperationCount;
            public ulong ReadTransferCount;
            public ulong WriteTransferCount;
            public ulong OtherTransferCount;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION
        {
            public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
            public IO_COUNTERS IoInfo;
            public UIntPtr ProcessMemoryLimit;
            public UIntPtr JobMemoryLimit;
            public UIntPtr PeakProcessMemoryUsed;
            public UIntPtr PeakJobMemoryUsed;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct STARTUPINFOW
        {
            public int cb;
            public IntPtr lpReserved;
            public IntPtr lpDesktop;
            public IntPtr lpTitle;
            public int dwX;
            public int dwY;
            public int dwXSize;
            public int dwYSize;
            public int dwXCountChars;
            public int dwYCountChars;
            public int dwFillAttribute;
            public int dwFlags;
            public short wShowWindow;
            public short cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput;
            public IntPtr hStdOutput;
            public IntPtr hStdError;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct STARTUPINFOEX
        {
            public STARTUPINFOW StartupInfo;
            public IntPtr lpAttributeList;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public uint dwProcessId;
            public uint dwThreadId;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct SECURITY_ATTRIBUTES
        {
            public uint nLength;
            public IntPtr lpSecurityDescriptor;
            [MarshalAs(UnmanagedType.Bool)]
            public bool bInheritHandle;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct COORD
        {
            public short X;
            public short Y;
        }
    }

    /// <summary>Raw P/Invoke declarations. SetLastError is mandatory on
    /// every call whose failure becomes a protocol error; failures are read
    /// with Marshal.GetLastWin32Error(), never a GetLastError import.</summary>
    internal static class NativeMethods
    {
        // ---- Files and devices -------------------------------------------------

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern IntPtr CreateFileW(
            string lpFileName, uint dwDesiredAccess, uint dwShareMode,
            IntPtr lpSecurityAttributes, uint dwCreationDisposition,
            uint dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ReadFile(
            IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToRead,
            out uint lpNumberOfBytesRead, IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool WriteFile(
            IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite,
            out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool CloseHandle(IntPtr hObject);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool SetHandleInformation(IntPtr hObject, uint dwMask, uint dwFlags);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool CreatePipe(
            out IntPtr hReadPipe, out IntPtr hWritePipe,
            IntPtr lpPipeAttributes, uint nSize);

        // ---- Serial ------------------------------------------------------------

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetCommState(IntPtr hFile, ref Win32Structs.DCB lpDCB);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool SetCommState(IntPtr hFile, ref Win32Structs.DCB lpDCB);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool SetCommTimeouts(IntPtr hFile, ref Win32Structs.COMMTIMEOUTS lpCommTimeouts);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool SetupComm(IntPtr hFile, uint dwInQueue, uint dwOutQueue);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ClearCommError(IntPtr hFile, out uint lpErrors, out Win32Structs.COMSTAT lpStat);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool EscapeCommFunction(IntPtr hFile, uint dwFunc);

        // ---- Job objects -------------------------------------------------------

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern IntPtr CreateJobObjectW(IntPtr lpJobAttributes, string lpName);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool SetInformationJobObject(IntPtr hJob, int infoClass, IntPtr lpInfo, uint cbInfoLength);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool TerminateJobObject(IntPtr hJob, uint uExitCode);

        // ---- Processes ---------------------------------------------------------

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool CreateProcessW(
            string lpApplicationName, System.Text.StringBuilder lpCommandLine,
            IntPtr lpProcessAttributes, IntPtr lpThreadAttributes,
            [MarshalAs(UnmanagedType.Bool)] bool bInheritHandles, uint dwCreationFlags,
            IntPtr lpEnvironment, string lpCurrentDirectory,
            ref Win32Structs.STARTUPINFOEX lpStartupInfo,
            out Win32Structs.PROCESS_INFORMATION lpProcessInformation);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool InitializeProcThreadAttributeList(
            IntPtr lpAttributeList, uint dwAttributeCount, uint dwFlags, ref IntPtr lpSize);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool UpdateProcThreadAttribute(
            IntPtr lpAttributeList, uint dwFlags, IntPtr attribute,
            IntPtr lpValue, IntPtr cbSize, IntPtr lpPreviousValue, IntPtr lpReturnSize);

        [DllImport("kernel32.dll")]
        internal static extern void DeleteProcThreadAttributeList(IntPtr lpAttributeList);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern uint ResumeThread(IntPtr hThread);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetExitCodeProcess(IntPtr hProcess, out uint lpExitCode);

        // ---- ConPTY -------------------------------------------------------------

        // HRESULT (not BOOL): negative means failure.
        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern int CreatePseudoConsole(
            Win32Structs.COORD size, IntPtr hInput, IntPtr hOutput, uint dwFlags, out IntPtr phPC);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern int ResizePseudoConsole(IntPtr hPC, Win32Structs.COORD size);

        [DllImport("kernel32.dll")]
        internal static extern void ClosePseudoConsole(IntPtr hPC);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern IntPtr GetModuleHandleW(string lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
        internal static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool FreeConsole();

        // ---- Filesystem --------------------------------------------------------

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool MoveFileExW(string lpExistingFileName, string lpNewFileName, uint dwFlags);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern uint GetFileAttributesW(string lpFileName);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool RemoveDirectoryW(string lpPathName);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool DeleteFileW(string lpFileName);

        // ---- Desktop -----------------------------------------------------------

        // Returns the previous context; NULL means the requested one was not
        // applied. Available since Windows 10 1809.
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern IntPtr SetThreadDpiAwarenessContext(IntPtr dpiContext);

        [DllImport("user32.dll")]
        internal static extern int GetSystemMetrics(int nIndex);

        // ---- Clipboard ---------------------------------------------------------

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool OpenClipboard(IntPtr hWndNewOwner);

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool CloseClipboard();

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool EmptyClipboard();

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool IsClipboardFormatAvailable(uint format);

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern IntPtr GetClipboardData(uint uFormat);

        // On success the system owns hMem; the caller must not free it.
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern IntPtr SetClipboardData(uint uFormat, IntPtr hMem);

        [DllImport("user32.dll")]
        internal static extern uint GetClipboardSequenceNumber();

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern uint RegisterClipboardFormatW(string lpszFormat);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern IntPtr GlobalAlloc(uint uFlags, UIntPtr dwBytes);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern IntPtr GlobalLock(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GlobalUnlock(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern IntPtr GlobalFree(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern UIntPtr GlobalSize(IntPtr hMem);
    }

    /// <summary>
    /// A job object configured with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE.
    /// Closing the handle terminates every process still assigned to the
    /// job, including whole descendant trees; that is the only tree-kill
    /// mechanism this agent uses. Dispose is idempotent.
    /// </summary>
    internal sealed class ProcessJob : IDisposable
    {
        private IntPtr _handle;

        public ProcessJob()
        {
            IntPtr handle = NativeMethods.CreateJobObjectW(IntPtr.Zero, null);
            if (handle == IntPtr.Zero)
            {
                throw new ProtocolError(
                    "process_containment_failed",
                    string.Format(
                        System.Globalization.CultureInfo.InvariantCulture,
                        "CreateJobObjectW failed with {0}",
                        Marshal.GetLastWin32Error()),
                    false);
            }
            Win32Structs.JOBOBJECT_EXTENDED_LIMIT_INFORMATION info =
                new Win32Structs.JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
            info.BasicLimitInformation.LimitFlags =
                Win32Constants.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            int size = Marshal.SizeOf(typeof(Win32Structs.JOBOBJECT_EXTENDED_LIMIT_INFORMATION));
            IntPtr block = IntPtr.Zero;
            try
            {
                block = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(info, block, false);
                if (!NativeMethods.SetInformationJobObject(
                        handle, Win32Constants.JobObjectExtendedLimitInformation,
                        block, (uint)size))
                {
                    throw new ProtocolError(
                        "process_containment_failed",
                        string.Format(
                            System.Globalization.CultureInfo.InvariantCulture,
                            "SetInformationJobObject failed with {0}",
                            Marshal.GetLastWin32Error()),
                        false);
                }
            }
            catch
            {
                NativeMethods.CloseHandle(handle);
                throw;
            }
            finally
            {
                if (block != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(block);
                }
            }
            _handle = handle;
        }

        public IntPtr Handle
        {
            get { return _handle; }
        }

        /// <summary>
        /// Assigns a suspended process to this job and resumes it. Mandated
        /// order: the child never executes user code unless containment is
        /// proven. On failure the child is terminated here and
        /// process_containment_failed is raised; there is no PID-only
        /// fallback.
        /// </summary>
        public void AssignAndResume(IntPtr hProcess, IntPtr hThread)
        {
            if (!NativeMethods.AssignProcessToJobObject(_handle, hProcess))
            {
                int error = Marshal.GetLastWin32Error();
                NativeMethods.TerminateProcess(hProcess, 1);
                throw new ProtocolError(
                    "process_containment_failed",
                    string.Format(
                        System.Globalization.CultureInfo.InvariantCulture,
                        "AssignProcessToJobObject failed with {0}",
                        error),
                    false);
            }
            if (NativeMethods.ResumeThread(hThread) == 0xFFFFFFFFu)
            {
                int error = Marshal.GetLastWin32Error();
                NativeMethods.TerminateProcess(hProcess, 1);
                throw new ProtocolError(
                    "process_containment_failed",
                    string.Format(
                        System.Globalization.CultureInfo.InvariantCulture,
                        "ResumeThread failed with {0}",
                        error),
                    false);
            }
        }

        public void Terminate(uint exitCode)
        {
            IntPtr handle = _handle;
            if (handle != IntPtr.Zero)
            {
                NativeMethods.TerminateJobObject(handle, exitCode);
            }
        }

        public void Dispose()
        {
            IntPtr handle = System.Threading.Interlocked.Exchange(ref _handle, IntPtr.Zero);
            if (handle != IntPtr.Zero)
            {
                NativeMethods.CloseHandle(handle);
            }
        }
    }

    /// <summary>
    /// One-shot capability probe run before the agent reports ready:
    /// ConPTY must exist in kernel32 and KILL_ON_JOB_CLOSE jobs must be
    /// settable. Returns null when the platform can serve the full
    /// protocol; a partial platform is reported, never papered over.
    /// </summary>
    internal static class Capabilities
    {
        public static ProtocolError Probe()
        {
            IntPtr kernel32 = NativeMethods.GetModuleHandleW("kernel32.dll");
            if (kernel32 == IntPtr.Zero ||
                NativeMethods.GetProcAddress(kernel32, "CreatePseudoConsole") == IntPtr.Zero)
            {
                return new ProtocolError(
                    "platform_unsupported",
                    "ConPTY is not available; Windows 10 1809 or later is required",
                    false);
            }
            ProcessJob probe = null;
            try
            {
                probe = new ProcessJob();
            }
            catch (ProtocolError error)
            {
                return error;
            }
            finally
            {
                if (probe != null)
                {
                    probe.Dispose();
                }
            }
            return null;
        }
    }
}

// On-demand capture of the interactive Windows desktop with the permissions
// of the agent's own session: one native-resolution PNG of the primary
// monitor, origin (0,0). The bytes travel in the fs stream and live only in
// memory; no file is written on the slave and nothing runs between calls.
//
// The capture is best effort by nature: a locked session, a secure desktop,
// a protected surface or a disconnected RDP session is not guaranteed to be
// capturable. A failure is reported with its real diagnostic; a valid black
// PNG is not evidence of any particular cause.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.Globalization;
    using System.IO;
    using System.Runtime.InteropServices;

    internal static class ScreenLimits
    {
        // Memory guard for the encoded PNG, not a promise that every image
        // under the ceiling crosses the link inside the master deadline.
        public const int MaxPngBytes = 32 * 1024 * 1024;
    }

    /// <summary>Primary-monitor capture served by fs.screen.</summary>
    internal sealed class ScreenService
    {
        /// <summary>
        /// Captures the primary monitor in its physical pixels and returns the
        /// PNG as the payload. The calling thread keeps the per-monitor DPI
        /// context only for the duration of the call.
        /// </summary>
        public FileService.Result Capture()
        {
            IntPtr previous = NativeMethods.SetThreadDpiAwarenessContext(
                Win32Constants.DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
            if (previous == IntPtr.Zero)
            {
                throw Failure(
                    "the thread DPI awareness context cannot be established",
                    Marshal.GetLastWin32Error());
            }
            FileService.Result result = null;
            try
            {
                result = CaptureInContext();
            }
            finally
            {
                // Restoring a different context would silently rescale the
                // next capture, so a failed restore is reported as a capture
                // failure unless another error is already on its way out.
                if (NativeMethods.SetThreadDpiAwarenessContext(previous) == IntPtr.Zero
                    && result != null)
                {
                    throw Failure(
                        "the previous thread DPI awareness context cannot be restored",
                        Marshal.GetLastWin32Error());
                }
            }
            return result;
        }

        private static FileService.Result CaptureInContext()
        {
            int width = NativeMethods.GetSystemMetrics(Win32Constants.SM_CXSCREEN);
            int height = NativeMethods.GetSystemMetrics(Win32Constants.SM_CYSCREEN);
            long pixels = (long)width * (long)height;
            if (width <= 0 || height <= 0 || pixels <= 0 || pixels > int.MaxValue)
            {
                throw Failure(
                    "the primary monitor reports no usable area (" +
                    Number(width) + "x" + Number(height) + ")",
                    0);
            }
            byte[] png = Encode(width, height);
            IDictionary<string, object> metadata = new Dictionary<string, object>();
            metadata["format"] = "png";
            metadata["width_px"] = width;
            metadata["height_px"] = height;
            metadata["bytes"] = png.Length;
            metadata["source"] = "agent";
            metadata["monitor"] = "primary";
            FileService.Result result = new FileService.Result();
            result.Metadata = metadata;
            result.Payload = png;
            return result;
        }

        private static byte[] Encode(int width, int height)
        {
            try
            {
                using (Bitmap bitmap = new Bitmap(width, height, PixelFormat.Format24bppRgb))
                {
                    using (Graphics graphics = Graphics.FromImage(bitmap))
                    {
                        graphics.CopyFromScreen(
                            0, 0, 0, 0, new Size(width, height),
                            CopyPixelOperation.SourceCopy);
                    }
                    using (MemoryStream buffer = new MemoryStream())
                    {
                        bitmap.Save(buffer, ImageFormat.Png);
                        if (buffer.Length > ScreenLimits.MaxPngBytes)
                        {
                            throw new ProtocolError(
                                "screen_too_large",
                                "the encoded PNG exceeds the " +
                                Number(ScreenLimits.MaxPngBytes) + " byte ceiling",
                                false);
                        }
                        return buffer.ToArray();
                    }
                }
            }
            catch (ProtocolError)
            {
                throw;
            }
            catch (Exception error)
            {
                throw Failure("the desktop capture failed: " + Describe(error), 0);
            }
        }

        private static string Describe(Exception error)
        {
            ExternalException external = error as ExternalException;
            if (external != null && external.ErrorCode != 0)
            {
                return error.Message + " (HRESULT 0x" +
                    external.ErrorCode.ToString("x8", CultureInfo.InvariantCulture) + ")";
            }
            return error.Message;
        }

        private static ProtocolError Failure(string message, int win32Error)
        {
            string detail = win32Error > 0
                ? message + " (Win32 error " + Number(win32Error) + ")"
                : message;
            return new ProtocolError("screen_capture_failed", detail, true);
        }

        private static string Number(int value)
        {
            return value.ToString(CultureInfo.InvariantCulture);
        }
    }
}

// One-shot PowerShell jobs and ConPTY terminals of the Windows slave.
// Port of implementations/python/shell_service.py with the Windows process
// model: every child is created suspended, assigned to a job object with
// JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE, and only then resumed. Cancellation
// and timeouts use TerminateJobObject; POSIX signals are neither available
// nor simulated. A job child is the agent executable itself (--job): no
// powershell.exe process is spawned for jobs, so no classic PowerShell log
// channel records a job start.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;

    /// <summary>
    /// Error carrying the protocol code and retryability. The dispatch mapper
    /// turns it into {code, message, retryable}.
    /// </summary>
    internal sealed class ProtocolError : Exception
    {
        public ProtocolError(string code, string message, bool retryable)
            : base(message)
        {
            Code = code;
            Retryable = retryable;
        }

        public string Code { get; private set; }
        public bool Retryable { get; private set; }
    }

    /// <summary>Shared capacity-4 slots for jobs and terminals.</summary>
    internal sealed class ProcessRegistry
    {
        private readonly int _maximum;
        private readonly object _gate = new object();
        private int _count;

        public ProcessRegistry(int maximum)
        {
            _maximum = maximum;
        }

        public int Count
        {
            get
            {
                lock (_gate)
                {
                    return _count;
                }
            }
        }

        public bool Acquire()
        {
            lock (_gate)
            {
                if (_count >= _maximum)
                {
                    return false;
                }
                _count++;
                return true;
            }
        }

        public void Release()
        {
            lock (_gate)
            {
                _count = Math.Max(0, _count - 1);
            }
        }
    }

    /// <summary>
    /// Path of the system Windows PowerShell. It is only the default shell
    /// of ConPTY terminals (operator interaction); jobs never run it, and the
    /// job child is the agent executable itself with --job.
    /// </summary>
    internal static class PowerShell
    {
        public static string ExecutablePath()
        {
            string root = Environment.GetEnvironmentVariable("SystemRoot");
            if (string.IsNullOrEmpty(root))
            {
                root = @"C:\Windows";
            }
            return System.IO.Path.Combine(
                root, @"System32\WindowsPowerShell\v1.0\powershell.exe");
        }
    }

    /// <summary>One detached PowerShell job with separated stdout/stderr.</summary>
    internal sealed class Job
    {
        public string JobId;
        public long StartedTicks;
        public double TimeoutSeconds;
        public string Status = "running";
        public int ReturnCode;
        public bool TimedOut;
        public bool Cancelled;
        public long Sequence;
        public readonly ManualResetEventSlim Finished = new ManualResetEventSlim(false);
        public readonly object SequenceLock = new object();
        public readonly object ContainerLock = new object();
        public ProcessJob Container;
        public IntPtr ProcessHandle;
        public IntPtr StdoutHandle;
        public IntPtr StderrHandle;
        public Thread StdoutReader;
        public Thread StderrReader;
        public Thread Waiter;

        public long NextSequence()
        {
            lock (SequenceLock)
            {
                long value = Sequence;
                Sequence++;
                return value;
            }
        }

        public ProcessJob CurrentContainer()
        {
            lock (ContainerLock)
            {
                return Container;
            }
        }
    }

    /// <summary>Jobs: start, cancel and shutdown with job-object containment.</summary>
    internal sealed class JobManager
    {
        private readonly AgentLink _link;
        private readonly ProcessRegistry _registry;
        private readonly Dictionary<string, Job> _jobs = new Dictionary<string, Job>();
        private readonly object _gate = new object();

        // Test-only containment fault injection: when set, the launcher
        // refuses to assign the suspended child and reports
        // process_containment_failed exactly as a real failure would.
        internal static bool SimulateContainmentFailure = false;

        public JobManager(AgentLink link, ProcessRegistry registry)
        {
            _link = link;
            _registry = registry;
        }

        public IDictionary<string, object> Start(string jobId, string command,
                                                 double timeoutSeconds, string cwd)
        {
            if (!_registry.Acquire())
            {
                throw new ProtocolError("session_limit", "session_limit", false);
            }
            double timeout = Math.Min(Math.Max(timeoutSeconds, 1.0), 3600.0);
            if (string.IsNullOrEmpty(jobId))
            {
                jobId = Guid.NewGuid().ToString("N");
            }
            Job job = new Job();
            job.JobId = jobId;
            job.TimeoutSeconds = timeout;
            try
            {
                Launch(job, command, cwd);
            }
            catch
            {
                _registry.Release();
                throw;
            }
            lock (_gate)
            {
                _jobs[jobId] = job;
            }
            job.StdoutReader = new Thread(delegate() { Drain(job, "stdout", job.StdoutHandle); });
            job.StdoutReader.IsBackground = true;
            job.StdoutReader.Name = "job-" + ShortId(jobId) + "-stdout";
            job.StderrReader = new Thread(delegate() { Drain(job, "stderr", job.StderrHandle); });
            job.StderrReader.IsBackground = true;
            job.StderrReader.Name = "job-" + ShortId(jobId) + "-stderr";
            job.Waiter = new Thread(delegate() { Wait(job); });
            job.Waiter.IsBackground = true;
            job.Waiter.Name = "job-" + ShortId(jobId) + "-wait";
            job.StdoutReader.Start();
            job.StderrReader.Start();
            job.Waiter.Start();
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "running";
            result["job_id"] = jobId;
            return result;
        }

        private static string ShortId(string value)
        {
            return value.Length <= 8 ? value : value.Substring(0, 8);
        }

        private void Launch(Job job, string command, string cwd)
        {
            // The user script is delivered over stdin to the in-process
            // Runspace runner (JobEntry): it never appears in the child
            // command line, so no classic PowerShell log channel records
            // its text. UTF-8 output encoding is forced by JobEntry.
            string script =
                "[Console]::InputEncoding=[System.Text.Encoding]::UTF8;" +
                "$OutputEncoding=[System.Text.Encoding]::UTF8;" + command;
            // The child is the agent executable itself: "<agent.exe>" --job
            // boots JobEntry, which reads the script from stdin. No
            // powershell.exe child and no assembly-loading command line.
            string image = Agent.ExecutableAssembly();
            StringBuilder commandLine = new StringBuilder();
            commandLine.Append('"').Append(image).Append("\" --job");

            Win32Structs.SECURITY_ATTRIBUTES inheritable =
                new Win32Structs.SECURITY_ATTRIBUTES();
            inheritable.nLength = (uint)Marshal.SizeOf(typeof(Win32Structs.SECURITY_ATTRIBUTES));
            inheritable.lpSecurityDescriptor = IntPtr.Zero;
            inheritable.bInheritHandle = true;

            IntPtr inheritableBlock = IntPtr.Zero;
            IntPtr stdoutRead = IntPtr.Zero;
            IntPtr stdoutWrite = IntPtr.Zero;
            IntPtr stderrRead = IntPtr.Zero;
            IntPtr stderrWrite = IntPtr.Zero;
            IntPtr stdinHandle = IntPtr.Zero;
            IntPtr stdinRead = IntPtr.Zero;
            Win32Structs.PROCESS_INFORMATION process =
                new Win32Structs.PROCESS_INFORMATION();
            bool processCreated = false;
            bool transferred = false;
            try
            {
                inheritableBlock = Marshal.AllocHGlobal(
                    Marshal.SizeOf(typeof(Win32Structs.SECURITY_ATTRIBUTES)));
                Marshal.StructureToPtr(inheritable, inheritableBlock, false);

                if (!NativeMethods.CreatePipe(out stdoutRead, out stdoutWrite, inheritableBlock, 0))
                {
                    throw LaunchError("CreatePipe(stdout)");
                }
                if (!NativeMethods.CreatePipe(out stderrRead, out stderrWrite, inheritableBlock, 0))
                {
                    throw LaunchError("CreatePipe(stderr)");
                }
                NativeMethods.SetHandleInformation(
                    stdoutRead, Win32Constants.HANDLE_FLAG_INHERIT, 0u);
                NativeMethods.SetHandleInformation(
                    stderrRead, Win32Constants.HANDLE_FLAG_INHERIT, 0u);

                // stdin carries the user script to JobEntry: the child
                // inherits the READ end (its stdin) and the parent keeps the
                // WRITE end to deliver the script and close it for EOF.
                // Marking directions correctly matters: inheriting the write
                // end as stdin makes every read fail with access denied.
                if (!NativeMethods.CreatePipe(out stdinRead, out stdinHandle, inheritableBlock, 0))
                {
                    throw LaunchError("CreatePipe(stdin)");
                }
                NativeMethods.SetHandleInformation(
                    stdinHandle, Win32Constants.HANDLE_FLAG_INHERIT, 0u);

                Win32Structs.STARTUPINFOEX startup = new Win32Structs.STARTUPINFOEX();
                startup.StartupInfo.cb = Marshal.SizeOf(typeof(Win32Structs.STARTUPINFOW));
                startup.StartupInfo.dwFlags = Win32Constants.STARTF_USESTDHANDLES;
                startup.StartupInfo.hStdInput = stdinRead;
                startup.StartupInfo.hStdOutput = stdoutWrite;
                startup.StartupInfo.hStdError = stderrWrite;
                startup.lpAttributeList = IntPtr.Zero;

                if (!NativeMethods.CreateProcessW(
                        image,
                        commandLine,
                        IntPtr.Zero,
                        IntPtr.Zero,
                        true,
                        Win32Constants.CREATE_SUSPENDED | Win32Constants.CREATE_NO_WINDOW,
                        IntPtr.Zero,
                        string.IsNullOrEmpty(cwd) ? null : cwd,
                        ref startup,
                        out process))
                {
                    throw LaunchError("CreateProcessW");
                }
                processCreated = true;

                // The child inherited its ends; ours must close now or the
                // drains never see EOF.
                NativeMethods.CloseHandle(stdoutWrite);
                stdoutWrite = IntPtr.Zero;
                NativeMethods.CloseHandle(stderrWrite);
                stderrWrite = IntPtr.Zero;


                ProcessJob container = new ProcessJob();
                bool assigned = false;
                try
                {
                    if (SimulateContainmentFailure)
                    {
                        throw new ProtocolError(
                            "process_containment_failed",
                            "the child could not be assigned to its job",
                            false);
                    }
                    container.AssignAndResume(process.hProcess, process.hThread);
                    assigned = true;
                }
                finally
                {
                    if (!assigned)
                    {
                        NativeMethods.TerminateProcess(process.hProcess, 1u);
                        container.Dispose();
                    }
                }

                // The child is running and reading stdin: deliver the
                // script, then close our end so JobEntry sees EOF. A write
                // failure here (child died instantly) surfaces as an
                // operation_failed launch error.
                try
                {
                    byte[] scriptBytes = Encoding.UTF8.GetBytes(script);
                    uint written;
                    if (!NativeMethods.WriteFile(stdinHandle, scriptBytes,
                                                  (uint)scriptBytes.Length,
                                                  out written, IntPtr.Zero)
                        || written != (uint)scriptBytes.Length)
                    {
                        throw LaunchError("WriteFile(stdin)");
                    }
                }
                finally
                {
                    NativeMethods.CloseHandle(stdinHandle);
                    stdinHandle = IntPtr.Zero;
                }

                NativeMethods.CloseHandle(process.hThread);
                process.hThread = IntPtr.Zero;

                lock (job.ContainerLock)
                {
                    job.Container = container;
                }
                job.ProcessHandle = process.hProcess;
                process.hProcess = IntPtr.Zero;
                job.StdoutHandle = stdoutRead;
                stdoutRead = IntPtr.Zero;
                job.StderrHandle = stderrRead;
                stderrRead = IntPtr.Zero;
                job.StartedTicks = System.Diagnostics.Stopwatch.GetTimestamp();
                transferred = true;
            }
            finally
            {
                if (!transferred)
                {
                    if (processCreated)
                    {
                        NativeMethods.CloseHandle(process.hThread);
                        process.hThread = IntPtr.Zero;
                        NativeMethods.CloseHandle(process.hProcess);
                        process.hProcess = IntPtr.Zero;
                    }
                    CloseHandle(ref stdoutRead);
                    CloseHandle(ref stderrRead);
                }
                CloseHandle(ref stdoutWrite);
                CloseHandle(ref stderrWrite);
                CloseHandle(ref stdinHandle);
                CloseHandle(ref stdinRead);
                if (inheritableBlock != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(inheritableBlock);
                }
            }
        }

        private static void CloseHandle(ref IntPtr handle)
        {
            if (handle != IntPtr.Zero)
            {
                NativeMethods.CloseHandle(handle);
                handle = IntPtr.Zero;
            }
        }

        private static ProtocolError LaunchError(string operation)
        {
            return new ProtocolError(
                "operation_failed",
                string.Format(
                    CultureInfo.InvariantCulture,
                    "{0} failed with {1}",
                    operation,
                    Marshal.GetLastWin32Error()),
                false);
        }

        private void Drain(Job job, string streamName, IntPtr handle)
        {
            byte[] buffer = new byte[WireConstants.DataChunkBytes];
            try
            {
                while (true)
                {
                    uint read;
                    if (!NativeMethods.ReadFile(handle, buffer, (uint)buffer.Length,
                                                out read, IntPtr.Zero))
                    {
                        return;
                    }
                    if (read == 0)
                    {
                        return;
                    }
                    byte[] chunk = new byte[read];
                    Array.Copy(buffer, chunk, (int)read);
                    IDictionary<string, object> extra = new Dictionary<string, object>();
                    extra["stream"] = streamName;
                    try
                    {
                        _link.SendData("shell", job.JobId, job.NextSequence(), chunk, extra);
                    }
                    catch (Exception)
                    {
                        return;
                    }
                }
            }
            finally
            {
                if (handle != IntPtr.Zero)
                {
                    NativeMethods.CloseHandle(handle);
                }
            }
        }

        private void Wait(Job job)
        {
            try
            {
                uint timeoutMs = (uint)Math.Min(job.TimeoutSeconds * 1000.0, int.MaxValue);
                uint wait = NativeMethods.WaitForSingleObject(job.ProcessHandle, timeoutMs);
                if (wait == Win32Constants.WAIT_TIMEOUT)
                {
                    job.TimedOut = true;
                    ProcessJob container = job.CurrentContainer();
                    if (container != null)
                    {
                        container.Terminate(Win32Constants.STATUS_CONTROL_C_EXIT);
                    }
                    NativeMethods.WaitForSingleObject(job.ProcessHandle, 5000u);
                }
                uint exitCode;
                if (NativeMethods.GetExitCodeProcess(job.ProcessHandle, out exitCode))
                {
                    job.ReturnCode = unchecked((int)exitCode);
                }
                if (job.StdoutReader != null)
                {
                    job.StdoutReader.Join(5000);
                }
                if (job.StderrReader != null)
                {
                    job.StderrReader.Join(5000);
                }
                job.Status = job.TimedOut ? "error" : "finished";
                IDictionary<string, object> body = new Dictionary<string, object>();
                body["status"] = job.Status;
                body["returncode"] = job.ReturnCode;
                body["timed_out"] = job.TimedOut;
                body["cancelled"] = job.Cancelled;
                body["elapsed"] = (System.Diagnostics.Stopwatch.GetTimestamp() - job.StartedTicks)
                    / (double)System.Diagnostics.Stopwatch.Frequency;
                try
                {
                    _link.Event("shell", "job.finished", job.JobId, body);
                }
                catch (Exception)
                {
                    // The link may already be closing: the event is best effort.
                }
            }
            finally
            {
                if (job.ProcessHandle != IntPtr.Zero)
                {
                    NativeMethods.CloseHandle(job.ProcessHandle);
                    job.ProcessHandle = IntPtr.Zero;
                }
                ProcessJob container;
                lock (job.ContainerLock)
                {
                    container = job.Container;
                    job.Container = null;
                }
                if (container != null)
                {
                    container.Dispose();
                }
                job.Finished.Set();
                _registry.Release();
            }
        }

        public IDictionary<string, object> Cancel(string jobId)
        {
            Job job;
            lock (_gate)
            {
                _jobs.TryGetValue(jobId ?? string.Empty, out job);
            }
            if (job == null)
            {
                IDictionary<string, object> missing = new Dictionary<string, object>();
                missing["status"] = "not_found";
                missing["job_id"] = jobId;
                return missing;
            }
            if (job.Finished.IsSet)
            {
                IDictionary<string, object> finished = new Dictionary<string, object>();
                finished["status"] = job.Status;
                finished["job_id"] = jobId;
                finished["returncode"] = job.ReturnCode;
                return finished;
            }
            job.Cancelled = true;
            ProcessJob container = job.CurrentContainer();
            if (container != null)
            {
                container.Terminate(Win32Constants.STATUS_CONTROL_C_EXIT);
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "cancelled";
            result["job_id"] = jobId;
            return result;
        }

        public void Shutdown()
        {
            List<Job> jobs;
            lock (_gate)
            {
                jobs = new List<Job>(_jobs.Values);
            }
            foreach (Job job in jobs)
            {
                if (!job.Finished.IsSet)
                {
                    job.Cancelled = true;
                    ProcessJob container = job.CurrentContainer();
                    if (container != null)
                    {
                        container.Terminate(Win32Constants.STATUS_CONTROL_C_EXIT);
                    }
                }
            }
        }
    }

    /// <summary>A ConPTY terminal session.</summary>
    internal sealed class Terminal
    {
        public string SessionId;
        public string Status = "running";
        public int ReturnCode;
        public int Rows;
        public int Cols;
        public int IdleTimeoutSeconds;
        public long LastActivityTicks;
        public long Sequence;
        public readonly BoundedQueue<byte[]> Output = new BoundedQueue<byte[]>(512);
        public readonly ManualResetEventSlim Closed = new ManualResetEventSlim(false);
        public readonly ManualResetEventSlim TeardownDone = new ManualResetEventSlim(false);
        public readonly object WriteLock = new object();
        public readonly object StateLock = new object();
        public ProcessJob Container;
        public IntPtr PseudoConsole;
        public IntPtr ProcessHandle;
        public IntPtr InputWrite;
        public IntPtr OutputRead;
        public Thread Reader;
        public Thread Sender;
        public Thread Waiter;
        public bool Closing;
        public bool Released;
        public bool TeardownStarted;
        public volatile bool Stopping;
        public volatile bool Draining;

        public ProcessJob CurrentContainer()
        {
            lock (StateLock)
            {
                return Container;
            }
        }

        public void ClearContainer()
        {
            lock (StateLock)
            {
                Container = null;
            }
        }
    }

    /// <summary>ConPTY terminals: open, input, resize, close and idle expiry.</summary>
    internal sealed class TerminalManager
    {
        private readonly AgentLink _link;
        private readonly ProcessRegistry _registry;
        private readonly Dictionary<string, Terminal> _sessions =
            new Dictionary<string, Terminal>();
        private readonly object _gate = new object();
        private readonly ManualResetEventSlim _stop = new ManualResetEventSlim(false);

        public TerminalManager(AgentLink link, ProcessRegistry registry)
        {
            _link = link;
            _registry = registry;
            Thread idle = new Thread(IdleLoop);
            idle.IsBackground = true;
            idle.Name = "pty-idle";
            idle.Start();
        }

        public IDictionary<string, object> Open(string cwd, string shell,
                                                int rows, int cols, int idleTimeout)
        {
            rows = Math.Min(Math.Max(rows, 1), 1000);
            cols = Math.Min(Math.Max(cols, 1), 1000);
            idleTimeout = Math.Min(Math.Max(idleTimeout, 1), 3600);
            if (!_registry.Acquire())
            {
                throw new ProtocolError("session_limit", "session_limit", false);
            }
            string selected;
            if (shell == null)
            {
                selected = PowerShell.ExecutablePath();
            }
            else
            {
                selected = shell;
                if (!System.IO.Path.IsPathRooted(selected) || !File.Exists(selected))
                {
                    _registry.Release();
                    throw new ProtocolError("invalid_argument", "shell not executable", false);
                }
            }
            if (!string.IsNullOrEmpty(cwd) && !Directory.Exists(cwd))
            {
                _registry.Release();
                throw new ProtocolError("invalid_argument", "cwd does not exist", false);
            }
            Terminal terminal;
            try
            {
                terminal = Launch(selected, string.IsNullOrEmpty(cwd) ? null : cwd,
                                  rows, cols, idleTimeout);
            }
            catch
            {
                _registry.Release();
                throw;
            }
            lock (_gate)
            {
                _sessions[terminal.SessionId] = terminal;
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "running";
            result["session_id"] = terminal.SessionId;
            result["rows"] = rows;
            result["cols"] = cols;
            return result;
        }

        private Terminal Launch(string shell, string cwd, int rows, int cols,
                                int idleTimeout)
        {
            IntPtr inputRead = IntPtr.Zero;
            IntPtr inputWrite = IntPtr.Zero;
            IntPtr outputRead = IntPtr.Zero;
            IntPtr outputWrite = IntPtr.Zero;
            IntPtr attributeList = IntPtr.Zero;
            IntPtr pseudoConsole = IntPtr.Zero;
            Win32Structs.PROCESS_INFORMATION process =
                new Win32Structs.PROCESS_INFORMATION();
            ProcessJob container = null;
            bool processCreated = false;
            bool transferred = false;
            StringBuilder commandLine = new StringBuilder();
            commandLine.Append('"').Append(shell).Append('"').Append(" -NoLogo -NoProfile");
            try
            {
                // ConPTY pipes are non-inheritable; the pseudoconsole
                // duplicates what it needs. This is the inverse of the job
                // pipes, which must be inheritable for the child.
                if (!NativeMethods.CreatePipe(out inputRead, out inputWrite, IntPtr.Zero, 0))
                {
                    throw LaunchError("CreatePipe(input)");
                }
                if (!NativeMethods.CreatePipe(out outputRead, out outputWrite, IntPtr.Zero, 0))
                {
                    throw LaunchError("CreatePipe(output)");
                }
                Win32Structs.COORD size = new Win32Structs.COORD();
                size.X = (short)cols;
                size.Y = (short)rows;
                int hresult = NativeMethods.CreatePseudoConsole(
                    size, inputRead, outputWrite, 0u, out pseudoConsole);
                if (hresult < 0)
                {
                    throw new ProtocolError(
                        "io_error",
                        string.Format(
                            CultureInfo.InvariantCulture,
                            "CreatePseudoConsole failed with 0x{0:X8}",
                            hresult),
                        false);
                }

                // Documented double call: learn the buffer size, allocate,
                // then initialize for real.
                IntPtr required = IntPtr.Zero;
                NativeMethods.InitializeProcThreadAttributeList(
                    IntPtr.Zero, 1u, 0u, ref required);
                attributeList = Marshal.AllocHGlobal(required);
                if (!NativeMethods.InitializeProcThreadAttributeList(
                        attributeList, 1u, 0u, ref required))
                {
                    throw LaunchError("InitializeProcThreadAttributeList");
                }
                // The Microsoft ConPTY sample passes the HPCON **value**
                // directly as lpValue with cbSize = sizeof(HPCON). Passing a
                // pointer to a variable holding it makes the child receive a
                // pointer-shaped but invalid console handle, which is why the
                // terminal child never acted on its input.
                if (!NativeMethods.UpdateProcThreadAttribute(
                        attributeList,
                        0u,
                        Win32Constants.PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE,
                        pseudoConsole,
                        (IntPtr)IntPtr.Size,
                        IntPtr.Zero,
                        IntPtr.Zero))
                {
                    throw LaunchError("UpdateProcThreadAttribute");
                }

                Win32Structs.STARTUPINFOEX startup = new Win32Structs.STARTUPINFOEX();
                startup.StartupInfo.cb = Marshal.SizeOf(typeof(Win32Structs.STARTUPINFOEX));
                startup.lpAttributeList = attributeList;

                if (!NativeMethods.CreateProcessW(
                        shell,
                        commandLine,
                        IntPtr.Zero,
                        IntPtr.Zero,
                        false,
                        Win32Constants.EXTENDED_STARTUPINFO_PRESENT |
                            Win32Constants.CREATE_SUSPENDED,
                        IntPtr.Zero,
                        cwd,
                        ref startup,
                        out process))
                {
                    throw LaunchError("CreateProcessW");
                }
                processCreated = true;

                container = new ProcessJob();
                bool assigned = false;
                try
                {
                    if (JobManager.SimulateContainmentFailure)
                    {
                        throw new ProtocolError(
                            "process_containment_failed",
                            "the terminal child could not be assigned to its job",
                            false);
                    }
                    container.AssignAndResume(process.hProcess, process.hThread);
                    assigned = true;
                }
                finally
                {
                    if (!assigned)
                    {
                        NativeMethods.TerminateProcess(process.hProcess, 1u);
                        container.Dispose();
                        container = null;
                    }
                }
                NativeMethods.CloseHandle(process.hThread);
                process.hThread = IntPtr.Zero;

                // The walkthrough says the handles given to
                // CreatePseudoConsole should be freed from this process so the
                // pipe can report a broken channel.
                CloseHandle(ref inputRead);
                CloseHandle(ref outputWrite);

                Terminal terminal = new Terminal();
                terminal.SessionId = Guid.NewGuid().ToString("N");
                terminal.Rows = rows;
                terminal.Cols = cols;
                terminal.IdleTimeoutSeconds = idleTimeout;
                terminal.LastActivityTicks = System.Diagnostics.Stopwatch.GetTimestamp();
                terminal.Container = container;
                terminal.PseudoConsole = pseudoConsole;
                terminal.ProcessHandle = process.hProcess;
                terminal.InputWrite = inputWrite;
                terminal.OutputRead = outputRead;
                terminal.Reader = new Thread(delegate() { ReadLoop(terminal); });
                terminal.Reader.IsBackground = true;
                terminal.Reader.Name = "pty-" + ShortId(terminal.SessionId) + "-read";
                terminal.Sender = new Thread(delegate() { SendLoop(terminal); });
                terminal.Sender.IsBackground = true;
                terminal.Sender.Name = "pty-" + ShortId(terminal.SessionId) + "-send";
                terminal.Waiter = new Thread(delegate() { WaitLoop(terminal); });
                terminal.Waiter.IsBackground = true;
                terminal.Waiter.Name = "pty-" + ShortId(terminal.SessionId) + "-wait";

                container = null;
                process.hProcess = IntPtr.Zero;
                inputWrite = IntPtr.Zero;
                outputRead = IntPtr.Zero;
                pseudoConsole = IntPtr.Zero;
                transferred = true;
                terminal.Reader.Start();
                terminal.Sender.Start();
                terminal.Waiter.Start();
                return terminal;
            }
            finally
            {
                if (!transferred)
                {
                    if (processCreated)
                    {
                        NativeMethods.CloseHandle(process.hThread);
                        process.hThread = IntPtr.Zero;
                        NativeMethods.CloseHandle(process.hProcess);
                        process.hProcess = IntPtr.Zero;
                    }
                    CloseHandle(ref inputRead);
                    CloseHandle(ref inputWrite);
                    CloseHandle(ref outputRead);
                    CloseHandle(ref outputWrite);
                    if (pseudoConsole != IntPtr.Zero)
                    {
                        NativeMethods.ClosePseudoConsole(pseudoConsole);
                        pseudoConsole = IntPtr.Zero;
                    }
                    if (container != null)
                    {
                        container.Dispose();
                        container = null;
                    }
                }
                if (attributeList != IntPtr.Zero)
                {
                    NativeMethods.DeleteProcThreadAttributeList(attributeList);
                    Marshal.FreeHGlobal(attributeList);
                }
            }
        }

        private static void CloseHandle(ref IntPtr handle)
        {
            if (handle != IntPtr.Zero)
            {
                NativeMethods.CloseHandle(handle);
                handle = IntPtr.Zero;
            }
        }

        private static ProtocolError LaunchError(string operation)
        {
            return new ProtocolError(
                "operation_failed",
                string.Format(
                    CultureInfo.InvariantCulture,
                    "{0} failed with {1}",
                    operation,
                    Marshal.GetLastWin32Error()),
                false);
        }

        private static string ShortId(string value)
        {
            return value.Length <= 8 ? value : value.Substring(0, 8);
        }

        private void ReadLoop(Terminal terminal)
        {
            byte[] buffer = new byte[WireConstants.DataChunkBytes];
            try
            {
                while (!terminal.Stopping)
                {
                    if (terminal.Output.Count >= 512)
                    {
                        if (terminal.Stopping)
                        {
                            return;
                        }
                        if (terminal.Draining)
                        {
                            // Teardown is draining: keep reading (and
                            // discarding) so ClosePseudoConsole never waits on
                            // an unread pipe.
                            uint discarded;
                            if (!NativeMethods.ReadFile(
                                    terminal.OutputRead, buffer, (uint)buffer.Length,
                                    out discarded, IntPtr.Zero) || discarded == 0)
                            {
                                return;
                            }
                            continue;
                        }
                        Thread.Sleep(20);
                        continue;
                    }
                    uint read;
                    if (!NativeMethods.ReadFile(
                            terminal.OutputRead, buffer, (uint)buffer.Length,
                            out read, IntPtr.Zero))
                    {
                        return;
                    }
                    if (read == 0)
                    {
                        return;
                    }
                    byte[] chunk = new byte[read];
                    Array.Copy(buffer, chunk, (int)read);
                    terminal.LastActivityTicks = System.Diagnostics.Stopwatch.GetTimestamp();
                    terminal.Output.TryEnqueue(chunk, 1000);
                }
            }
            finally
            {
                terminal.Output.TryEnqueue(null, 5000);
            }
        }

        private void SendLoop(Terminal terminal)
        {
            while (true)
            {
                byte[] data;
                if (!terminal.Output.TryDequeue(100, out data))
                {
                    if (terminal.Closed.IsSet && terminal.Output.Count == 0)
                    {
                        return;
                    }
                    continue;
                }
                if (data == null)
                {
                    return;
                }
                long sequence;
                lock (terminal.StateLock)
                {
                    sequence = terminal.Sequence;
                    terminal.Sequence++;
                }
                try
                {
                    _link.SendData("shell", terminal.SessionId, sequence, data, null);
                }
                catch (Exception)
                {
                    return;
                }
            }
        }

        private void WaitLoop(Terminal terminal)
        {
            try
            {
                NativeMethods.WaitForSingleObject(
                    terminal.ProcessHandle, Win32Constants.INFINITE);
                uint exitCode;
                if (NativeMethods.GetExitCodeProcess(terminal.ProcessHandle, out exitCode))
                {
                    terminal.ReturnCode = unchecked((int)exitCode);
                }
                lock (terminal.StateLock)
                {
                    terminal.Status = "closed";
                }
                terminal.Closed.Set();
                IDictionary<string, object> body = new Dictionary<string, object>();
                body["status"] = "closed";
                body["returncode"] = terminal.ReturnCode;
                try
                {
                    _link.Event("shell", "terminal.closed", terminal.SessionId, body);
                }
                catch (Exception)
                {
                    // Best effort while the link may be closing.
                }
                ReleaseSlot(terminal);
                // The exit path must not wait behind a closer that may be
                // joining this very thread.
                Teardown(terminal, false);
            }
            finally
            {
                ReleaseSlot(terminal);
                if (terminal.ProcessHandle != IntPtr.Zero)
                {
                    NativeMethods.CloseHandle(terminal.ProcessHandle);
                    terminal.ProcessHandle = IntPtr.Zero;
                }
            }
        }

        private void ReleaseSlot(Terminal terminal)
        {
            bool release = false;
            lock (terminal.StateLock)
            {
                if (!terminal.Released)
                {
                    terminal.Released = true;
                    release = true;
                }
            }
            if (release)
            {
                _registry.Release();
            }
        }

        private Terminal Get(string sessionId)
        {
            Terminal terminal;
            lock (_gate)
            {
                _sessions.TryGetValue(sessionId ?? string.Empty, out terminal);
            }
            if (terminal == null)
            {
                throw new ProtocolError("terminal_not_found", "terminal not found", false);
            }
            return terminal;
        }

        public IDictionary<string, object> Input(string sessionId, byte[] data)
        {
            Terminal terminal = Get(sessionId);
            bool closed;
            bool closing;
            lock (terminal.StateLock)
            {
                closed = terminal.Status == "closed";
                closing = terminal.Closing;
            }
            if (closed || closing)
            {
                IDictionary<string, object> result = new Dictionary<string, object>();
                result["status"] = "closed";
                result["session_id"] = sessionId;
                return result;
            }
            terminal.LastActivityTicks = System.Diagnostics.Stopwatch.GetTimestamp();
            lock (terminal.WriteLock)
            {
                int total = 0;
                while (total < data.Length)
                {
                    byte[] part = new byte[data.Length - total];
                    Array.Copy(data, total, part, 0, part.Length);
                    uint written;
                    if (!NativeMethods.WriteFile(
                            terminal.InputWrite, part, (uint)part.Length,
                            out written, IntPtr.Zero))
                    {
                        throw new ProtocolError(
                            "io_error", "WriteFile to the terminal failed", false);
                    }
                    if (written == 0)
                    {
                        throw new ProtocolError(
                            "io_error", "short write to the terminal", false);
                    }
                    total += (int)written;
                }
                IDictionary<string, object> result = new Dictionary<string, object>();
                result["status"] = "written";
                result["session_id"] = sessionId;
                result["bytes"] = total;
                return result;
            }
        }

        public IDictionary<string, object> Resize(string sessionId, int rows, int cols)
        {
            Terminal terminal = Get(sessionId);
            rows = Math.Min(Math.Max(rows, 1), 1000);
            cols = Math.Min(Math.Max(cols, 1), 1000);
            Win32Structs.COORD size = new Win32Structs.COORD();
            size.X = (short)cols;
            size.Y = (short)rows;
            int hresult = NativeMethods.ResizePseudoConsole(terminal.PseudoConsole, size);
            if (hresult < 0)
            {
                throw new ProtocolError(
                    "io_error",
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "ResizePseudoConsole failed with 0x{0:X8}",
                        hresult),
                    false);
            }
            terminal.Rows = rows;
            terminal.Cols = cols;
            terminal.LastActivityTicks = System.Diagnostics.Stopwatch.GetTimestamp();
            IDictionary<string, object> result = new Dictionary<string, object>();
            lock (terminal.StateLock)
            {
                result["status"] = terminal.Status;
            }
            result["session_id"] = sessionId;
            result["rows"] = rows;
            result["cols"] = cols;
            return result;
        }

        /// <summary>
        /// Closes a terminal with the ordering that matters on Windows:
        /// reject new writes, terminate the job tree, keep draining output,
        /// and only then close the pseudoconsole from this thread (never the
        /// reader), free the pipes and join the drains.
        /// </summary>
        public IDictionary<string, object> Close(string sessionId)
        {
            Terminal terminal;
            lock (_gate)
            {
                _sessions.TryGetValue(sessionId ?? string.Empty, out terminal);
            }
            if (terminal == null)
            {
                IDictionary<string, object> missing = new Dictionary<string, object>();
                missing["status"] = "closed";
                missing["session_id"] = sessionId;
                return missing;
            }
            lock (terminal.StateLock)
            {
                if (terminal.Status == "closed")
                {
                    IDictionary<string, object> closed = new Dictionary<string, object>();
                    closed["status"] = "closed";
                    closed["session_id"] = sessionId;
                    closed["returncode"] = terminal.ReturnCode;
                    return closed;
                }
                if (terminal.Closing)
                {
                    IDictionary<string, object> closing = new Dictionary<string, object>();
                    closing["status"] = "closed";
                    closing["session_id"] = sessionId;
                    return closing;
                }
                terminal.Closing = true;
                terminal.Status = "closing";
            }
            ProcessJob container = terminal.CurrentContainer();
            if (container != null)
            {
                container.Terminate(Win32Constants.STATUS_CONTROL_C_EXIT);
            }
            // Python's close() returns immediately: the drain and the
            // pseudoconsole teardown continue in the background. Doing that
            // here keeps the dispatch loop responsive with a full 256 KiB
            // output backlog, while the wait thread still performs the
            // ordered teardown off the reading thread.
            Thread closer = new Thread(delegate() { Teardown(terminal, true); });
            closer.IsBackground = true;
            closer.Name = "pty-close-" + ShortId(sessionId);
            closer.Start();
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "closed";
            result["session_id"] = sessionId;
            return result;
        }

        /// <summary>
        /// Exactly-once teardown; every caller waits for the owner to finish.
        /// Ordering that matters: the reader keeps draining while
        /// ClosePseudoConsole waits (it must not run on the reading thread and
        /// must not run after the reader was stopped), then the read end is
        /// closed to unblock a pending ReadFile, and finally the drains are
        /// joined.
        /// </summary>
        private void Teardown(Terminal terminal, bool waitForOwner)
        {
            bool owner = false;
            lock (terminal.StateLock)
            {
                if (!terminal.TeardownStarted)
                {
                    terminal.TeardownStarted = true;
                    owner = true;
                }
            }
            if (!owner)
            {
                if (waitForOwner)
                {
                    terminal.TeardownDone.Wait(15000);
                }
                return;
            }
            try
            {
                // 0. Once teardown starts the reader must never block on a
                //    full output queue: it discards until the pipe breaks,
                //    because ClosePseudoConsole waits for the drain.
                terminal.Draining = true;
                // 1. Close the pseudoconsole while the reader still drains.
                if (terminal.PseudoConsole != IntPtr.Zero)
                {
                    NativeMethods.ClosePseudoConsole(terminal.PseudoConsole);
                    terminal.PseudoConsole = IntPtr.Zero;
                }
                // 2. Stop the reader after ClosePseudoConsole has broken the
                //    pipe; joining before closing the handle avoids closing a
                //    handle another thread is inside ReadFile with.
                terminal.Stopping = true;
                if (terminal.Reader != null && terminal.Reader != Thread.CurrentThread)
                {
                    terminal.Reader.Join(10000);
                }
                if (terminal.OutputRead != IntPtr.Zero)
                {
                    NativeMethods.CloseHandle(terminal.OutputRead);
                    terminal.OutputRead = IntPtr.Zero;
                }
                if (terminal.InputWrite != IntPtr.Zero)
                {
                    NativeMethods.CloseHandle(terminal.InputWrite);
                    terminal.InputWrite = IntPtr.Zero;
                }
                ProcessJob container = terminal.CurrentContainer();
                terminal.ClearContainer();
                if (container != null)
                {
                    container.Dispose();
                }
                if (terminal.Sender != null && terminal.Sender != Thread.CurrentThread)
                {
                    terminal.Sender.Join(2000);
                }
                if (terminal.Waiter != null && terminal.Waiter != Thread.CurrentThread)
                {
                    terminal.Waiter.Join(5000);
                }
            }
            finally
            {
                terminal.TeardownDone.Set();
            }
        }

        private void IdleLoop()
        {
            while (!_stop.Wait(1000))
            {
                List<Terminal> snapshot;
                lock (_gate)
                {
                    snapshot = new List<Terminal>(_sessions.Values);
                }
                long now = System.Diagnostics.Stopwatch.GetTimestamp();
                foreach (Terminal terminal in snapshot)
                {
                    if (terminal.Closed.IsSet)
                    {
                        continue;
                    }
                    double idle = (now - terminal.LastActivityTicks)
                        / (double)System.Diagnostics.Stopwatch.Frequency;
                    if (idle > terminal.IdleTimeoutSeconds)
                    {
                        try
                        {
                            Close(terminal.SessionId);
                        }
                        catch (Exception)
                        {
                            // An idle close is best effort.
                        }
                    }
                }
            }
        }

        public void Shutdown()
        {
            _stop.Set();
            List<string> sessions;
            lock (_gate)
            {
                sessions = new List<string>(_sessions.Keys);
            }
            foreach (string sessionId in sessions)
            {
                try
                {
                    Close(sessionId);
                }
                catch (Exception)
                {
                    // Shutdown closes every session it can; a dead one is fine.
                }
            }
        }
    }
}

// Atomic transfers with exact size, SHA-256 and cancellation. Port of
// implementations/python/transfer_service.py: the destination is never
// visible until size and digest are verified, the streaming window is
// 1..64 blocks, and only the upload's own temporary file is ever removed.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography;
    using System.Text;
    using System.Threading;

    internal static class TransferLimits
    {
        public const long MaxTransferBytes = 512L * 1024L * 1024L;
        public const int MaxDownloadWindow = 64;
        public const int ProgressStepBytes = 1024 * 1024;
        public const int DownloadHashBlock = 1024 * 1024;
    }

    internal sealed class Upload
    {
        public string TransferId;
        public string FinalPath;
        public string Temporary;
        public FileStream Stream;
        public long Size;
        public string Checksum;
        public long Received;
        public long ExpectedSequence;
        public IncrementalHash Hasher;
        public string Status = "running";
        public readonly ManualResetEventSlim Cancelled = new ManualResetEventSlim(false);
        public long LastProgress;
    }

    internal sealed class Download
    {
        public string TransferId;
        public string Path;
        public long Size;
        public string Checksum;
        public int Window = WireConstants.DataWindowDefault;
        public long Transferred;
        public string Status = "running";
        public readonly ManualResetEventSlim Cancelled = new ManualResetEventSlim(false);
    }

    /// <summary>Upload and download lifetime with exact verification.</summary>
    internal sealed class TransferService
    {
        private readonly AgentLink _link;
        private readonly Dictionary<string, object> _transfers =
            new Dictionary<string, object>();
        private readonly object _gate = new object();

        public TransferService(AgentLink link)
        {
            _link = link;
        }

        private static string PathOf(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new ProtocolError("invalid_path", "path is mandatory", false);
            }
            return System.IO.Path.GetFullPath(value);
        }

        private static string Key(string transferId)
        {
            // Python keys the map with None for a missing id; a single empty
            // bucket reproduces that for the only reachable case.
            return transferId == null ? string.Empty : transferId;
        }

        public IDictionary<string, object> BeginUpload(string transferId, string path,
                                                       long size, string checksum)
        {
            if (size < 0 || size > TransferLimits.MaxTransferBytes)
            {
                throw new ProtocolError(
                    "size_limit", "the transfer exceeds 512 MiB", false);
            }
            if (checksum == null || checksum.Length != 64)
            {
                throw new ProtocolError(
                    "invalid_checksum", "sha256 is mandatory", false);
            }
            string finalPath = PathOf(path);
            string directory = System.IO.Path.GetDirectoryName(finalPath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            string temporary = System.IO.Path.Combine(
                directory ?? string.Empty,
                "." + System.IO.Path.GetFileName(finalPath) + ".titella-" +
                Guid.NewGuid().ToString("N"));
            FileStream stream = new FileStream(
                temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                4096, FileOptions.WriteThrough);
            Upload upload = new Upload();
            upload.TransferId = transferId;
            upload.FinalPath = finalPath;
            upload.Temporary = temporary;
            upload.Stream = stream;
            upload.Size = size;
            upload.Checksum = checksum;
            upload.Hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            lock (_gate)
            {
                string key = Key(transferId);
                object existing;
                if (_transfers.TryGetValue(key, out existing))
                {
                    Upload previous = existing as Upload;
                    Download previousDownload = existing as Download;
                    bool running =
                        (previous != null && previous.Status == "running") ||
                        (previousDownload != null && previousDownload.Status == "running");
                    if (running)
                    {
                        stream.Dispose();
                        DeleteOwnTemporary(temporary);
                        throw new ProtocolError(
                            "transfer_exists",
                            "transfer_id is already active",
                            false);
                    }
                }
                _transfers[key] = upload;
            }
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "running";
            result["transfer_id"] = transferId;
            result["bytes_total"] = size;
            result["bytes_transferred"] = 0;
            return result;
        }

        private static void DeleteOwnTemporary(string temporary)
        {
            try
            {
                if (File.Exists(temporary))
                {
                    File.Delete(temporary);
                }
            }
            catch (Exception)
            {
                // Deleting our own partial is best effort.
            }
        }

        public void UploadData(string transferId, long sequence, byte[] data)
        {
            object entry;
            lock (_gate)
            {
                _transfers.TryGetValue(Key(transferId), out entry);
            }
            Upload transfer = entry as Upload;
            if (transfer == null)
            {
                throw new ProtocolError("not_found", "upload not found", true);
            }
            if (transfer.Cancelled.IsSet)
            {
                throw new ProtocolError("cancelled", "upload cancelled", false);
            }
            if (sequence < transfer.ExpectedSequence)
            {
                // Block already written: the previous ACK was lost and the
                // sender is retransmitting. Neither rewrite nor reject it;
                // the caller acknowledges it again.
                return;
            }
            if (sequence != transfer.ExpectedSequence)
            {
                // Gap: neither written nor acknowledged; the sender retries.
                throw new ProtocolError("sequence", "unexpected upload sequence", false);
            }
            if (transfer.Received + data.Length > transfer.Size)
            {
                throw new ProtocolError(
                    "size_mismatch", "upload exceeds the declared size", false);
            }
            transfer.Stream.Write(data, 0, data.Length);
            transfer.Hasher.AppendData(data, 0, data.Length);
            transfer.Received += data.Length;
            transfer.ExpectedSequence++;
            if (transfer.Received - transfer.LastProgress >= TransferLimits.ProgressStepBytes)
            {
                transfer.LastProgress = transfer.Received;
                _link.Event("transfer", "transfer.progress", transferId, Status(transferId));
            }
        }

        public IDictionary<string, object> CommitUpload(string transferId)
        {
            object entry;
            lock (_gate)
            {
                _transfers.TryGetValue(Key(transferId), out entry);
            }
            Upload transfer = entry as Upload;
            if (transfer == null)
            {
                throw new ProtocolError("not_found", "upload not found", true);
            }
            try
            {
                transfer.Stream.Flush(true);
                transfer.Stream.Dispose();
                if (transfer.Received != transfer.Size)
                {
                    throw new ProtocolError(
                        "size_mismatch",
                        "received size differs from the declared one",
                        false);
                }
                string digest = FileService.Hex(transfer.Hasher.GetHashAndReset());
                if (!string.Equals(digest, transfer.Checksum, StringComparison.Ordinal))
                {
                    throw new ProtocolError(
                        "checksum_mismatch", "upload SHA-256 does not match", false);
                }
                if (!NativeMethods.MoveFileExW(
                        transfer.Temporary, transfer.FinalPath,
                        Win32Constants.MOVEFILE_REPLACE_EXISTING |
                            Win32Constants.MOVEFILE_WRITE_THROUGH))
                {
                    throw new IOException(
                        string.Format(
                            CultureInfo.InvariantCulture,
                            "MoveFileExW failed with {0}",
                            Marshal.GetLastWin32Error()));
                }
                transfer.Status = "finished";
                IDictionary<string, object> result = Status(transferId);
                result["sha256"] = digest;
                return result;
            }
            catch
            {
                transfer.Status = "error";
                try
                {
                    transfer.Stream.Dispose();
                }
                catch (Exception)
                {
                    // Already closed by the failed commit path.
                }
                DeleteOwnTemporary(transfer.Temporary);
                throw;
            }
        }

        public IDictionary<string, object> BeginDownload(string transferId, string path,
                                                         string expectedChecksum, int window)
        {
            string target = PathOf(path);
            FileInfo info = new FileInfo(target);
            long size = info.Length;
            if (size > TransferLimits.MaxTransferBytes)
            {
                throw new ProtocolError(
                    "size_limit", "the transfer exceeds 512 MiB", false);
            }
            string checksum;
            using (IncrementalHash hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
            {
                using (FileStream stream = new FileStream(
                    target, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    byte[] buffer = new byte[TransferLimits.DownloadHashBlock];
                    while (true)
                    {
                        int read = stream.Read(buffer, 0, buffer.Length);
                        if (read <= 0)
                        {
                            break;
                        }
                        hasher.AppendData(buffer, 0, read);
                    }
                }
                checksum = FileService.Hex(hasher.GetHashAndReset());
            }
            if (!string.IsNullOrEmpty(expectedChecksum) &&
                !string.Equals(checksum, expectedChecksum, StringComparison.Ordinal))
            {
                throw new ProtocolError(
                    "checksum_mismatch",
                    "the remote checksum does not match the expected one",
                    false);
            }
            if (window < 1)
            {
                window = WireConstants.DataWindowDefault;
            }
            window = Math.Min(window, TransferLimits.MaxDownloadWindow);
            Download download = new Download();
            download.TransferId = transferId;
            download.Path = target;
            download.Size = size;
            download.Checksum = checksum;
            download.Window = window;
            lock (_gate)
            {
                object existing;
                if (_transfers.TryGetValue(Key(transferId), out existing))
                {
                    Upload previousUpload = existing as Upload;
                    Download previousDownload = existing as Download;
                    bool running =
                        (previousUpload != null && previousUpload.Status == "running") ||
                        (previousDownload != null && previousDownload.Status == "running");
                    if (running)
                    {
                        throw new ProtocolError(
                            "transfer_exists", "transfer_id is already active", false);
                    }
                }
                _transfers[Key(transferId)] = download;
            }
            Thread thread = new Thread(delegate() { SendDownload(download); });
            thread.IsBackground = true;
            thread.Name = "download-" + ShortId(transferId);
            thread.Start();
            IDictionary<string, object> result = new Dictionary<string, object>();
            result["status"] = "running";
            result["transfer_id"] = transferId;
            result["bytes_total"] = size;
            result["bytes_transferred"] = 0;
            result["sha256"] = checksum;
            return result;
        }

        private static string ShortId(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return "transfer";
            }
            return value.Length <= 8 ? value : value.Substring(0, 8);
        }

        private void SendDownload(Download transfer)
        {
            IncrementalHash hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            try
            {
                using (FileStream stream = new FileStream(
                    transfer.Path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    Func<byte[]> readChunk = delegate()
                    {
                        if (transfer.Cancelled.IsSet)
                        {
                            throw new ProtocolError("cancelled", "download cancelled", false);
                        }
                        byte[] chunk = new byte[WireConstants.DataChunkBytes];
                        int read = stream.Read(chunk, 0, chunk.Length);
                        if (read <= 0)
                        {
                            return new byte[0];
                        }
                        if (read != chunk.Length)
                        {
                            byte[] shorter = new byte[read];
                            Array.Copy(chunk, shorter, read);
                            chunk = shorter;
                        }
                        hasher.AppendData(chunk, 0, chunk.Length);
                        return chunk;
                    };
                    Action<int> onAck = delegate(int total) { transfer.Transferred = total; };
                    Func<bool> stopCheck = delegate() { return transfer.Cancelled.IsSet; };
                    _link.StreamData(
                        "transfer", transfer.TransferId, readChunk,
                        transfer.Window, onAck, stopCheck);
                }
                if (transfer.Cancelled.IsSet)
                {
                    transfer.Status = "cancelled";
                }
                else if (transfer.Transferred != transfer.Size ||
                         !string.Equals(FileService.Hex(hasher.GetHashAndReset()),
                                        transfer.Checksum, StringComparison.Ordinal))
                {
                    transfer.Status = "error";
                }
                else
                {
                    transfer.Status = "finished";
                }
                _link.Event("transfer", "transfer.finished", transfer.TransferId,
                            Status(transfer.TransferId));
            }
            catch (Exception error)
            {
                if (transfer.Cancelled.IsSet)
                {
                    transfer.Status = "cancelled";
                    try
                    {
                        _link.Event("transfer", "transfer.finished", transfer.TransferId,
                                    Status(transfer.TransferId));
                    }
                    catch (Exception)
                    {
                        // The link may be closing; do not leave a traceback.
                    }
                }
                else
                {
                    transfer.Status = "error";
                    IDictionary<string, object> body = new Dictionary<string, object>();
                    body["status"] = "error";
                    body["transfer_id"] = transfer.TransferId;
                    body["code"] = "download_failed";
                    body["message"] = error.Message;
                    body["retryable"] = true;
                    try
                    {
                        _link.Event("transfer", "transfer.finished", transfer.TransferId, body);
                    }
                    catch (Exception)
                    {
                        // Best effort while the link may be closing.
                    }
                }
            }
            finally
            {
                hasher.Dispose();
            }
        }

        public IDictionary<string, object> Status(string transferId)
        {
            object entry;
            lock (_gate)
            {
                _transfers.TryGetValue(Key(transferId), out entry);
            }
            if (entry == null)
            {
                IDictionary<string, object> missing = new Dictionary<string, object>();
                missing["status"] = "not_found";
                missing["transfer_id"] = transferId;
                return missing;
            }
            Upload upload = entry as Upload;
            Download download = entry as Download;
            IDictionary<string, object> result = new Dictionary<string, object>();
            if (upload != null)
            {
                result["status"] = upload.Status;
                result["transfer_id"] = transferId;
                result["bytes_total"] = upload.Size;
                result["bytes_transferred"] = upload.Received;
            }
            else
            {
                result["status"] = download.Status;
                result["transfer_id"] = transferId;
                result["bytes_total"] = download.Size;
                result["bytes_transferred"] = download.Transferred;
            }
            return result;
        }

        public IDictionary<string, object> Cancel(string transferId)
        {
            object entry;
            lock (_gate)
            {
                _transfers.TryGetValue(Key(transferId), out entry);
            }
            if (entry == null)
            {
                IDictionary<string, object> missing = new Dictionary<string, object>();
                missing["status"] = "not_found";
                missing["transfer_id"] = transferId;
                return missing;
            }
            Upload upload = entry as Upload;
            Download download = entry as Download;
            string status = upload != null ? upload.Status : download.Status;
            if (!string.Equals(status, "running", StringComparison.Ordinal))
            {
                return Status(transferId);
            }
            if (upload != null)
            {
                upload.Cancelled.Set();
                upload.Status = "cancelled";
                try
                {
                    upload.Stream.Dispose();
                }
                catch (Exception)
                {
                    // A cancelled upload closes its own stream; failure to
                    // close it does not change the outcome.
                }
                DeleteOwnTemporary(upload.Temporary);
            }
            else
            {
                download.Cancelled.Set();
                download.Status = "cancelled";
            }
            return Status(transferId);
        }

        public void Shutdown()
        {
            List<string> identifiers;
            lock (_gate)
            {
                identifiers = new List<string>(_transfers.Keys);
            }
            foreach (string transferId in identifiers)
            {
                try
                {
                    Cancel(transferId);
                }
                catch (Exception)
                {
                    // Shutdown cancels everything it can.
                }
            }
        }
    }
}

// LF-delimited JSON protocol v1 shared with the master. Faithful port of
// src/titella_slave_assets/wire.py: identical constants, check order and
// error codes. Every other unit depends on this one.
//
// Deliberate hardenings over the Python contract, all invisible to a
// conforming peer (documented in the implementation handoff):
//   - v must be the numeric value 1; Python accepts boolean true because
//     True == 1, this port does not;
//   - the parser keeps at most the last 64 errors instead of an unbounded
//     list (no observable protocol effect);
//   - Base64 whitespace is rejected explicitly instead of relying on
//     Convert.FromBase64String, which ignores it.

namespace Titella.Slave
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;
    using System.Web.Script.Serialization;

    internal static class WireConstants
    {
        public const int ProtocolVersion = 1;
        public const int MaxFrameBytes = 4096;
        public const int FrameBufferBytes = MaxFrameBytes + 1;
        public const int DataChunkBytes = 512;
        public const int DataWindowDefault = 8;
        public const int DataWindowMax = 64;
        public const int MaxRequests = 256;
        public const int MaxDedupEntries = 1024;
        public const int MaxOutboundFrames = 1024;
        public const int MaxParserErrors = 64;

        public const string MasterToFirmware = "master_to_firmware";
        public const string FirmwareToMaster = "firmware_to_master";
        public const string SlaveToFirmware = "slave_to_firmware";
        public const string FirmwareToSlave = "firmware_to_slave";

        public static readonly string[] Channels = new string[]
        {
            "hid", "video", "control", "bootstrap", "shell", "fs", "transfer",
        };

        public static readonly string[] Types = new string[]
        {
            "hello", "heartbeat", "request", "response", "data", "ack", "event", "error",
        };

        // Direction -> channel -> allowed types, verbatim from wire.py:28-47.
        private static readonly Dictionary<string, Dictionary<string, string[]>> DirectionTypes =
            BuildDirectionTypes();

        private static Dictionary<string, string[]> MasterTypes()
        {
            Dictionary<string, string[]> table = new Dictionary<string, string[]>();
            table["control"] = new string[] { "heartbeat", "request", "ack" };
            table["bootstrap"] = new string[] { "request", "data", "ack" };
            table["shell"] = new string[] { "request", "data", "ack" };
            table["fs"] = new string[] { "request", "data", "ack" };
            table["transfer"] = new string[] { "request", "data", "ack" };
            return table;
        }

        private static Dictionary<string, string[]> SlaveTypes()
        {
            Dictionary<string, string[]> table = new Dictionary<string, string[]>();
            table["control"] = new string[] { "hello", "heartbeat", "response", "ack", "event", "error" };
            table["bootstrap"] = new string[] { "response", "ack", "event", "error" };
            table["shell"] = new string[] { "response", "data", "ack", "event", "error" };
            table["fs"] = new string[] { "response", "data", "ack", "event", "error" };
            table["transfer"] = new string[] { "response", "data", "ack", "event", "error" };
            return table;
        }

        private static Dictionary<string, Dictionary<string, string[]>> BuildDirectionTypes()
        {
            Dictionary<string, Dictionary<string, string[]>> table =
                new Dictionary<string, Dictionary<string, string[]>>();

            Dictionary<string, string[]> masterToFirmware = MasterTypes();
            masterToFirmware["hid"] = new string[] { "request" };
            masterToFirmware["video"] = new string[] { "request" };
            table[MasterToFirmware] = masterToFirmware;

            table[FirmwareToSlave] = MasterTypes();

            table[SlaveToFirmware] = SlaveTypes();

            Dictionary<string, string[]> firmwareToMaster = SlaveTypes();
            firmwareToMaster["hid"] = new string[] { "response", "error" };
            firmwareToMaster["video"] = new string[] { "response", "error" };
            table[FirmwareToMaster] = firmwareToMaster;

            return table;
        }

        public static bool Contains(string[] set, string value)
        {
            return Array.IndexOf(set, value) >= 0;
        }

        public static bool DirectionAllows(string direction, string channel, string kind,
                                           out bool knownDirection)
        {
            knownDirection = false;
            Dictionary<string, string[]> channels;
            if (direction == null || !DirectionTypes.TryGetValue(direction, out channels))
            {
                return false;
            }
            knownDirection = true;
            string[] allowed;
            if (!channels.TryGetValue(channel, out allowed))
            {
                return false;
            }
            return Contains(allowed, kind);
        }

        public static bool IsLinkId(string value)
        {
            if (value == null || value.Length != 32)
            {
                return false;
            }
            for (int index = 0; index < value.Length; index++)
            {
                char c = value[index];
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')))
                {
                    return false;
                }
            }
            return true;
        }
    }

    /// <summary>Malformed frame or one incompatible with protocol v1.</summary>
    internal sealed class WireError : Exception
    {
        private readonly string _code;
        private readonly string _detail;

        public WireError(string code, string detail)
            : base(detail)
        {
            _code = code;
            _detail = detail;
        }

        public string Code
        {
            get { return _code; }
        }

        public string Detail
        {
            get { return _detail; }
        }
    }

    /// <summary>
    /// System.Web.Script.Serialization helpers. A per-thread serializer keeps
    /// the reader, writer, heartbeat and stream threads independent
    /// (JavaScriptSerializer instances are not documented as thread-safe).
    /// MaxJsonLength and RecursionLimit bound the work a 4096-byte frame can
    /// cause; the defaults (2 MiB / 100) are far above the protocol needs.
    /// </summary>
    internal static class Json
    {
        // Inbound frames are bounded to 4096 bytes, so parsing never needs
        // more than a small window; outbound replies are not (a search reply
        // can carry 200 x 1000 chars, a find page 500 paths). Python's
        // json.dumps has no length cap, so the serializer used to produce
        // replies must not impose one either: that was the real defect behind
        // "the length of the string exceeds the value set on the
        // maxJsonLength property" on fs.search/fs.list.
        private const int InboundMaxJsonLength = 65536;
        private const int OutboundMaxJsonLength = 4 * 1024 * 1024;
        private const int RecursionLimit = 8;

        [ThreadStatic]
        private static JavaScriptSerializer _parseSerializer;

        [ThreadStatic]
        private static JavaScriptSerializer _writeSerializer;

        private static JavaScriptSerializer ParseSerializer
        {
            get
            {
                JavaScriptSerializer serializer = _parseSerializer;
                if (serializer == null)
                {
                    serializer = new JavaScriptSerializer();
                    serializer.MaxJsonLength = InboundMaxJsonLength;
                    serializer.RecursionLimit = RecursionLimit;
                    _parseSerializer = serializer;
                }
                return serializer;
            }
        }

        private static JavaScriptSerializer WriteSerializer
        {
            get
            {
                JavaScriptSerializer serializer = _writeSerializer;
                if (serializer == null)
                {
                    serializer = new JavaScriptSerializer();
                    serializer.MaxJsonLength = OutboundMaxJsonLength;
                    serializer.RecursionLimit = RecursionLimit;
                    _writeSerializer = serializer;
                }
                return serializer;
            }
        }

        public static object Parse(string text)
        {
            try
            {
                return ParseSerializer.DeserializeObject(text);
            }
            catch (ArgumentException error)
            {
                throw new WireError("invalid_json", error.Message);
            }
            catch (InvalidOperationException error)
            {
                throw new WireError("invalid_json", error.Message);
            }
        }

        public static string Serialize(object value)
        {
            try
            {
                return WriteSerializer.Serialize(value);
            }
            catch (ArgumentException error)
            {
                throw new WireError("invalid_json", error.Message);
            }
            catch (InvalidOperationException error)
            {
                throw new WireError("invalid_json", error.Message);
            }
        }

        public static bool IsObject(object value)
        {
            return value is IDictionary<string, object>;
        }

        public static bool IsArray(object value)
        {
            return value is object[];
        }

        /// <summary>
        /// The deserializer yields int, long, decimal or double depending on
        /// magnitude and fraction. Python's isinstance(value, int) rejects
        /// bool first and floats outright; booleans and strings are rejected
        /// here for the same reason, while integral decimal/double values are
        /// accepted because JavaScriptSerializer may produce them for a
        /// plain integer literal.
        /// </summary>
        public static bool TryGetInt64(object value, out long result)
        {
            result = 0;
            if (value == null || value is bool || value is string)
            {
                return false;
            }
            if (value is int)
            {
                result = (int)value;
                return true;
            }
            if (value is long)
            {
                result = (long)value;
                return true;
            }
            if (value is decimal)
            {
                decimal decimalValue = (decimal)value;
                if (decimalValue != decimal.Truncate(decimalValue) ||
                    decimalValue < long.MinValue || decimalValue > long.MaxValue)
                {
                    return false;
                }
                result = (long)decimalValue;
                return true;
            }
            if (value is double)
            {
                double doubleValue = (double)value;
                if (double.IsNaN(doubleValue) || double.IsInfinity(doubleValue) ||
                    doubleValue != Math.Truncate(doubleValue) ||
                    doubleValue < long.MinValue || doubleValue > long.MaxValue)
                {
                    return false;
                }
                result = (long)doubleValue;
                return true;
            }
            return false;
        }

        /// <summary>Absent or null means the default; non-integers also fall
        /// back; valid integers are clamped into [minimum, maximum].</summary>
        public static int GetInt32(IDictionary<string, object> frame, string key,
                                   int minimum, int maximum, int fallback)
        {
            object value;
            long parsed;
            if (frame == null || !frame.TryGetValue(key, out value) || value == null)
            {
                return fallback;
            }
            if (!TryGetInt64(value, out parsed))
            {
                return fallback;
            }
            if (parsed < minimum)
            {
                return minimum;
            }
            if (parsed > maximum)
            {
                return maximum;
            }
            return (int)parsed;
        }

        public static long GetInt64(IDictionary<string, object> frame, string key, long fallback)
        {
            object value;
            long parsed;
            if (frame == null || !frame.TryGetValue(key, out value) || value == null)
            {
                return fallback;
            }
            if (!TryGetInt64(value, out parsed))
            {
                return fallback;
            }
            return parsed;
        }

        /// <summary>Seconds as a double; invalid or absent means fallback.</summary>
        public static double GetDouble(IDictionary<string, object> frame, string key, double fallback)
        {
            object value;
            if (frame == null || !frame.TryGetValue(key, out value) || value == null || value is bool)
            {
                return fallback;
            }
            if (value is int)
            {
                return (int)value;
            }
            if (value is long)
            {
                return (long)value;
            }
            if (value is decimal)
            {
                return (double)(decimal)value;
            }
            if (value is double)
            {
                return (double)value;
            }
            return fallback;
        }
    }

    /// <summary>Frame validation, encoding and payload helpers.</summary>
    internal static class Wire
    {
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        public static IDictionary<string, object> ValidateFrame(object frame, string direction)
        {
            IDictionary<string, object> mapping = frame as IDictionary<string, object>;
            if (mapping == null)
            {
                throw new WireError("invalid_frame", "the frame must be a JSON object");
            }

            object versionValue;
            long version;
            mapping.TryGetValue("v", out versionValue);
            if (!Json.TryGetInt64(versionValue, out version) ||
                version != WireConstants.ProtocolVersion)
            {
                throw new WireError("unsupported_version", "only v=1 is accepted");
            }

            object channelValue;
            mapping.TryGetValue("channel", out channelValue);
            string channel = channelValue as string;
            if (channel == null || !WireConstants.Contains(WireConstants.Channels, channel))
            {
                throw new WireError("invalid_channel", "unknown channel");
            }

            object typeValue;
            mapping.TryGetValue("type", out typeValue);
            string kind = typeValue as string;
            if (kind == null || !WireConstants.Contains(WireConstants.Types, kind))
            {
                throw new WireError("invalid_type", "unknown type");
            }

            object linkValue;
            mapping.TryGetValue("link_id", out linkValue);
            string linkId = linkValue as string;
            if (!WireConstants.IsLinkId(linkId))
            {
                throw new WireError("invalid_link_id", "link_id must hold 128 bits in hexadecimal");
            }

            if (direction != null)
            {
                bool knownDirection;
                bool allowed = WireConstants.DirectionAllows(direction, channel, kind, out knownDirection);
                if (!knownDirection)
                {
                    throw new WireError(
                        "invalid_direction",
                        "unknown direction: " + direction);
                }
                if (!allowed)
                {
                    throw new WireError(
                        "direction_denied",
                        channel + "." + kind + " is not allowed in " + direction);
                }
            }

            if (kind == "request" || kind == "response")
            {
                RequireInteger(mapping, "request_id", 1);
                object opValue;
                mapping.TryGetValue("op", out opValue);
                string op = opValue as string;
                if (op == null || op.Length == 0)
                {
                    throw new WireError("invalid_frame", "request/response requires op");
                }
            }
            else if (kind == "data")
            {
                RequireSessionId(mapping, "data requires session_id");
                RequireInteger(mapping, "seq", 0);
                DecodeData(mapping);
            }
            else if (kind == "ack")
            {
                RequireSessionId(mapping, "ack requires session_id");
                RequireInteger(mapping, "ack_seq", 0);
            }

            object bodyValue;
            bool hasBody = mapping.TryGetValue("body", out bodyValue);
            if (hasBody && bodyValue != null && !Json.IsObject(bodyValue))
            {
                throw new WireError("invalid_frame", "body must be an object");
            }

            return new Dictionary<string, object>(mapping);
        }

        private static void RequireInteger(IDictionary<string, object> frame, string key, long minimum)
        {
            object value;
            long parsed;
            frame.TryGetValue(key, out value);
            if (!Json.TryGetInt64(value, out parsed) || parsed < minimum)
            {
                throw new WireError(
                    "invalid_frame",
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "{0} must be an integer >= {1}",
                        key,
                        minimum));
            }
        }

        private static void RequireSessionId(IDictionary<string, object> frame, string message)
        {
            object value;
            frame.TryGetValue("session_id", out value);
            string sessionId = value as string;
            if (sessionId == null || sessionId.Length == 0)
            {
                throw new WireError("invalid_frame", message);
            }
        }

        public static byte[] EncodeFrame(object frame, string direction)
        {
            IDictionary<string, object> validated = ValidateFrame(frame, direction);
            string json = Json.Serialize(validated);
            int size = Encoding.UTF8.GetByteCount(json);
            if (size > WireConstants.MaxFrameBytes)
            {
                throw new WireError(
                    "frame_too_large",
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "frame of {0} bytes; maximum {1}",
                        size,
                        WireConstants.MaxFrameBytes));
            }
            byte[] jsonBytes = Encoding.UTF8.GetBytes(json);
            byte[] payload = new byte[jsonBytes.Length + 1];
            Array.Copy(jsonBytes, payload, jsonBytes.Length);
            payload[payload.Length - 1] = 0x0A;
            return payload;
        }

        public static IDictionary<string, object> DecodeLine(byte[] raw, string direction)
        {
            if (raw.Length > WireConstants.MaxFrameBytes)
            {
                throw new WireError("frame_too_large", "frame above the maximum");
            }
            byte[] trimmed = raw;
            if (trimmed.Length > 0 && trimmed[trimmed.Length - 1] == 0x0D)
            {
                trimmed = new byte[raw.Length - 1];
                Array.Copy(raw, trimmed, trimmed.Length);
            }
            string text;
            try
            {
                text = StrictUtf8.GetString(trimmed);
            }
            catch (DecoderFallbackException error)
            {
                throw new WireError("invalid_json", error.Message);
            }
            object parsed = Json.Parse(text);
            return ValidateFrame(parsed, direction);
        }

        public static string DataB64(byte[] data)
        {
            if (data.Length > WireConstants.DataChunkBytes)
            {
                throw new WireError(
                    "chunk_too_large",
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "chunk of {0} bytes; maximum {1}",
                        data.Length,
                        WireConstants.DataChunkBytes));
            }
            return Convert.ToBase64String(data);
        }

        /// <summary>
        /// Python's b64decode(validate=True) rejects whitespace and bad
        /// padding while Convert.FromBase64String silently ignores
        /// whitespace; the pre-check closes that divergence. An empty string
        /// decodes to zero bytes and is valid. Shared with the file service.
        /// </summary>
        internal static bool IsStrictBase64(string value)
        {
            if (value == null || value.Length % 4 != 0)
            {
                return false;
            }
            int padding = 0;
            for (int index = 0; index < value.Length; index++)
            {
                char c = value[index];
                if (c == '=')
                {
                    if (index < value.Length - 2)
                    {
                        return false;
                    }
                    padding++;
                    continue;
                }
                bool alphabet =
                    (c >= 'A' && c <= 'Z') ||
                    (c >= 'a' && c <= 'z') ||
                    (c >= '0' && c <= '9') ||
                    c == '+' || c == '/';
                if (!alphabet)
                {
                    return false;
                }
            }
            return padding <= 2;
        }

        public static byte[] DecodeData(IDictionary<string, object> frame)
        {
            object encodedValue;
            frame.TryGetValue("data_b64", out encodedValue);
            string encoded = encodedValue as string;
            if (encoded == null)
            {
                throw new WireError("invalid_frame", "data requires data_b64");
            }
            if (!IsStrictBase64(encoded))
            {
                throw new WireError("invalid_base64", "data_b64 is not valid base64");
            }
            byte[] data;
            try
            {
                data = Convert.FromBase64String(encoded);
            }
            catch (FormatException)
            {
                throw new WireError("invalid_base64", "data_b64 is not valid base64");
            }
            if (data.Length > WireConstants.DataChunkBytes)
            {
                throw new WireError(
                    "chunk_too_large",
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "chunk of {0} bytes; maximum {1}",
                        data.Length,
                        WireConstants.DataChunkBytes));
            }
            return data;
        }

        /// <summary>
        /// Builds the standard frame shape and validates it, as Python's
        /// base_frame does. <paramref name="fields"/> is an alternating
        /// key/value list.
        /// </summary>
        public static IDictionary<string, object> BaseFrame(
            string linkId, string channel, string kind, params object[] fields)
        {
            IDictionary<string, object> frame = new Dictionary<string, object>();
            frame["v"] = WireConstants.ProtocolVersion;
            frame["channel"] = channel;
            frame["type"] = kind;
            frame["link_id"] = linkId;
            if (fields != null)
            {
                if (fields.Length % 2 != 0)
                {
                    throw new WireError("invalid_frame", "frame fields must be key/value pairs");
                }
                for (int index = 0; index < fields.Length; index += 2)
                {
                    frame[(string)fields[index]] = fields[index + 1];
                }
            }
            return ValidateFrame(frame, null);
        }
    }

    /// <summary>
    /// Bounded incremental parser: at most 4096 bytes per line, overflow
    /// discards up to the next LF and resynchronizes. Exactly wire.py:166-195.
    /// </summary>
    internal sealed class FrameParser
    {
        private readonly string _direction;
        private readonly bool _ignoreInvalid;
        private readonly byte[] _buffer;
        private readonly List<WireError> _errors;
        private int _length;
        private bool _discardUntilLf;

        public FrameParser(string direction)
            : this(direction, true)
        {
        }

        public FrameParser(string direction, bool ignoreInvalid)
        {
            _direction = direction;
            _ignoreInvalid = ignoreInvalid;
            _buffer = new byte[WireConstants.MaxFrameBytes];
            _errors = new List<WireError>();
        }

        public IList<WireError> Errors
        {
            get { return _errors; }
        }

        private void Record(WireError error)
        {
            if (_errors.Count >= WireConstants.MaxParserErrors)
            {
                _errors.RemoveAt(0);
            }
            _errors.Add(error);
        }

        public IList<IDictionary<string, object>> Feed(byte[] chunk, int offset, int count)
        {
            List<IDictionary<string, object>> frames = new List<IDictionary<string, object>>();
            int end = offset + count;
            for (int position = offset; position < end; position++)
            {
                byte value = chunk[position];
                if (_discardUntilLf)
                {
                    if (value == 0x0A)
                    {
                        _discardUntilLf = false;
                        _length = 0;
                    }
                    continue;
                }
                if (value == 0x0A)
                {
                    byte[] raw = new byte[_length];
                    Array.Copy(_buffer, raw, _length);
                    _length = 0;
                    if (raw.Length == 0)
                    {
                        continue;
                    }
                    try
                    {
                        frames.Add(Wire.DecodeLine(raw, _direction));
                    }
                    catch (WireError error)
                    {
                        Record(error);
                        if (!_ignoreInvalid)
                        {
                            throw;
                        }
                    }
                    continue;
                }
                if (_length >= WireConstants.MaxFrameBytes)
                {
                    WireError error = new WireError(
                        "frame_too_large", "overflow; discarding up to LF");
                    Record(error);
                    _length = 0;
                    _discardUntilLf = true;
                    if (!_ignoreInvalid)
                    {
                        throw error;
                    }
                    continue;
                }
                _buffer[_length] = value;
                _length++;
            }
            return frames;
        }
    }

    /// <summary>Identity of one data block across a link, a session and a sequence.</summary>
    internal struct DedupKey : IEquatable<DedupKey>
    {
        private readonly string _linkId;
        private readonly string _sessionId;
        private readonly long _seq;

        public DedupKey(string linkId, string sessionId, long seq)
        {
            _linkId = linkId;
            _sessionId = sessionId;
            _seq = seq;
        }

        public bool Equals(DedupKey other)
        {
            return _seq == other._seq &&
                   string.Equals(_linkId, other._linkId, StringComparison.Ordinal) &&
                   string.Equals(_sessionId, other._sessionId, StringComparison.Ordinal);
        }

        public override bool Equals(object obj)
        {
            return obj is DedupKey && Equals((DedupKey)obj);
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + (_linkId == null ? 0 : _linkId.GetHashCode());
            hash = hash * 31 + (_sessionId == null ? 0 : _sessionId.GetHashCode());
            hash = hash * 31 + _seq.GetHashCode();
            return hash;
        }
    }

    /// <summary>
    /// Bounded FIFO window for (link_id, session_id, seq). Seen() never
    /// registers: the key is recorded only after the frame is accepted, so a
    /// rejected gap keeps being rejected and is never fake-acknowledged.
    /// </summary>
    internal sealed class Deduplicator
    {
        private readonly int _limit;
        private readonly Dictionary<DedupKey, LinkedListNode<DedupKey>> _seen;
        private readonly LinkedList<DedupKey> _order;

        public Deduplicator()
            : this(WireConstants.MaxDedupEntries)
        {
        }

        public Deduplicator(int limit)
        {
            if (limit < 1)
            {
                throw new ArgumentOutOfRangeException("limit", "limit must be positive");
            }
            _limit = limit;
            _seen = new Dictionary<DedupKey, LinkedListNode<DedupKey>>();
            _order = new LinkedList<DedupKey>();
        }

        private readonly object _gate = new object();

        public bool Add(DedupKey key)
        {
            lock (_gate)
            {
                if (_seen.ContainsKey(key))
                {
                    return false;
                }
                LinkedListNode<DedupKey> node = _order.AddLast(key);
                _seen[key] = node;
                if (_seen.Count > _limit)
                {
                    DedupKey oldest = _order.First.Value;
                    _order.RemoveFirst();
                    _seen.Remove(oldest);
                }
                return true;
            }
        }

        public bool Seen(DedupKey key)
        {
            lock (_gate)
            {
                return _seen.ContainsKey(key);
            }
        }
    }
}
